﻿namespace Movie_Ticket_Booking_system
{
    partial class BBTm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBTm3));
            this.Register5 = new System.Windows.Forms.Button();
            this.AddresstextBox5 = new System.Windows.Forms.TextBox();
            this.Addresslabel5 = new System.Windows.Forms.Label();
            this.TicketstextBox5 = new System.Windows.Forms.TextBox();
            this.Ticketslabel5 = new System.Windows.Forms.Label();
            this.NotextBox5 = new System.Windows.Forms.TextBox();
            this.Nolabel5 = new System.Windows.Forms.Label();
            this.EmailtextBox5 = new System.Windows.Forms.TextBox();
            this.Emaillabel5 = new System.Windows.Forms.Label();
            this.GendertextBox5 = new System.Windows.Forms.TextBox();
            this.Genderlabel5 = new System.Windows.Forms.Label();
            this.NametextBox5 = new System.Windows.Forms.TextBox();
            this.Namelabel5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Register5
            // 
            this.Register5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register5.Location = new System.Drawing.Point(480, 525);
            this.Register5.Name = "Register5";
            this.Register5.Size = new System.Drawing.Size(286, 83);
            this.Register5.TabIndex = 84;
            this.Register5.Text = "Register";
            this.Register5.UseVisualStyleBackColor = true;
            this.Register5.Click += new System.EventHandler(this.Register5_Click);
            // 
            // AddresstextBox5
            // 
            this.AddresstextBox5.Location = new System.Drawing.Point(421, 396);
            this.AddresstextBox5.Multiline = true;
            this.AddresstextBox5.Name = "AddresstextBox5";
            this.AddresstextBox5.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox5.TabIndex = 83;
            // 
            // Addresslabel5
            // 
            this.Addresslabel5.AutoSize = true;
            this.Addresslabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel5.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel5.Location = new System.Drawing.Point(313, 384);
            this.Addresslabel5.Name = "Addresslabel5";
            this.Addresslabel5.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel5.TabIndex = 82;
            this.Addresslabel5.Text = "Add";
            // 
            // TicketstextBox5
            // 
            this.TicketstextBox5.Location = new System.Drawing.Point(421, 340);
            this.TicketstextBox5.Name = "TicketstextBox5";
            this.TicketstextBox5.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox5.TabIndex = 81;
            // 
            // Ticketslabel5
            // 
            this.Ticketslabel5.AutoSize = true;
            this.Ticketslabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel5.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel5.Location = new System.Drawing.Point(313, 329);
            this.Ticketslabel5.Name = "Ticketslabel5";
            this.Ticketslabel5.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel5.TabIndex = 80;
            this.Ticketslabel5.Text = "Tickets";
            // 
            // NotextBox5
            // 
            this.NotextBox5.Location = new System.Drawing.Point(421, 178);
            this.NotextBox5.Name = "NotextBox5";
            this.NotextBox5.Size = new System.Drawing.Size(539, 20);
            this.NotextBox5.TabIndex = 79;
            // 
            // Nolabel5
            // 
            this.Nolabel5.AutoSize = true;
            this.Nolabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel5.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel5.Location = new System.Drawing.Point(313, 167);
            this.Nolabel5.Name = "Nolabel5";
            this.Nolabel5.Size = new System.Drawing.Size(49, 31);
            this.Nolabel5.TabIndex = 78;
            this.Nolabel5.Text = "No";
            // 
            // EmailtextBox5
            // 
            this.EmailtextBox5.Location = new System.Drawing.Point(421, 234);
            this.EmailtextBox5.Name = "EmailtextBox5";
            this.EmailtextBox5.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox5.TabIndex = 77;
            // 
            // Emaillabel5
            // 
            this.Emaillabel5.AutoSize = true;
            this.Emaillabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel5.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel5.Location = new System.Drawing.Point(313, 223);
            this.Emaillabel5.Name = "Emaillabel5";
            this.Emaillabel5.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel5.TabIndex = 76;
            this.Emaillabel5.Text = "Email";
            // 
            // GendertextBox5
            // 
            this.GendertextBox5.Location = new System.Drawing.Point(421, 286);
            this.GendertextBox5.Name = "GendertextBox5";
            this.GendertextBox5.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox5.TabIndex = 75;
            // 
            // Genderlabel5
            // 
            this.Genderlabel5.AutoSize = true;
            this.Genderlabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel5.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel5.Location = new System.Drawing.Point(313, 275);
            this.Genderlabel5.Name = "Genderlabel5";
            this.Genderlabel5.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel5.TabIndex = 74;
            this.Genderlabel5.Text = "Gender";
            // 
            // NametextBox5
            // 
            this.NametextBox5.Location = new System.Drawing.Point(421, 123);
            this.NametextBox5.Name = "NametextBox5";
            this.NametextBox5.Size = new System.Drawing.Size(539, 20);
            this.NametextBox5.TabIndex = 73;
            // 
            // Namelabel5
            // 
            this.Namelabel5.AutoSize = true;
            this.Namelabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel5.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel5.Location = new System.Drawing.Point(313, 112);
            this.Namelabel5.Name = "Namelabel5";
            this.Namelabel5.Size = new System.Drawing.Size(86, 31);
            this.Namelabel5.TabIndex = 72;
            this.Namelabel5.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 71;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1201, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 85;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // BBTm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1257, 704);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register5);
            this.Controls.Add(this.AddresstextBox5);
            this.Controls.Add(this.Addresslabel5);
            this.Controls.Add(this.TicketstextBox5);
            this.Controls.Add(this.Ticketslabel5);
            this.Controls.Add(this.NotextBox5);
            this.Controls.Add(this.Nolabel5);
            this.Controls.Add(this.EmailtextBox5);
            this.Controls.Add(this.Emaillabel5);
            this.Controls.Add(this.GendertextBox5);
            this.Controls.Add(this.Genderlabel5);
            this.Controls.Add(this.NametextBox5);
            this.Controls.Add(this.Namelabel5);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBTm3";
            this.Text = "BBTm3";
            this.Load += new System.EventHandler(this.BBTm3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Register5;
        private System.Windows.Forms.TextBox AddresstextBox5;
        private System.Windows.Forms.Label Addresslabel5;
        private System.Windows.Forms.TextBox TicketstextBox5;
        private System.Windows.Forms.Label Ticketslabel5;
        private System.Windows.Forms.TextBox NotextBox5;
        private System.Windows.Forms.Label Nolabel5;
        private System.Windows.Forms.TextBox EmailtextBox5;
        private System.Windows.Forms.Label Emaillabel5;
        private System.Windows.Forms.TextBox GendertextBox5;
        private System.Windows.Forms.Label Genderlabel5;
        private System.Windows.Forms.TextBox NametextBox5;
        private System.Windows.Forms.Label Namelabel5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}