﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Movie_Ticket_Booking_system
{
    public partial class Cancel_Registeration : Form
    {





        public static string name_copy;
        public static string No_copy;
        public static string email_copy;
        public static string gender_copy;
        public static int Tickets_copy;
        public static string address_copy;
        public static string Day_copy;
        public static string Movie_copy;
        public static int Amount_copy;
        public static int Total_copy;
        public static string timing_copy;
        public static string DT_copy;
        public static int Book_ID;
        public static int key;









        class identification
        {
            private int id;

            public void set_myid(int id)
            {
                this.id = id;
            }
            public int get_myid()
            {
                return id;
            }
        }



        class Registeration : identification
        {

            private string name;
            private string No;
            private string email;
            private string gender;
            private int Tickets;
            private string address;
            private string Day;
            private string Movie;
            private int Amount;
            private int Total;
            private string timing;
            private string DT;


            public void Set_name(string name)
            {
                this.name = name;
            }
            public void Set_No(string No)
            {
                this.No = No;
            }
            public void Set_Email(string email)
            {
                this.email = email;
            }
            public void Set_Gender(string gender)
            {
                this.gender = gender;
            }
            public void Set_Tickets(int Tickets)
            {
                this.Tickets = Tickets;
            }
            public void Set_Address(string address)
            {
                this.address = address;
            }
            public void Set_Day(string Day)
            {
                this.Day = Day;
            }
            public void Set_Movie(string Movie)
            {
                this.Movie = Movie;
            }
            public void Set_Amount(int Amount)
            {
                this.Amount = Amount;
            }

            public void Set_Total(int Total)
            {
                this.Total = Total;
            }

            public void Set_Time(string time)
            {
                this.timing = time;
            }
            public void Set_DateTime(string Dt)
            {
                this.DT = Dt;
            }

            public string Get_name()
            {
                return name;
            }
            public string Get_No()
            {
                return No;
            }
            public string Get_Email()
            {
                return email;
            }
            public string Get_Gender()
            {
                return gender;
            }
            public int Get_Tickets()
            {
                return Tickets;
            }
            public string Get_Address()
            {
                return address;
            }
            public string Get_Day()
            {
                return Day;
            }
            public string Get_Movie()
            {
                return Movie;
            }
            public int Get_Amount()
            {
                return Amount;
            }
            public int Get_Total()
            {
                return Total;
            }
            public string Get_Time()
            {
                return timing;
            }
            public string Get_DateTime()
            {
                return DT;
            }


        }



        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-UAV1AAR\SQLEXPRESS;Initial Catalog=OOPDATABASE;Integrated Security=True");



        public Cancel_Registeration()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(comboBox1.Text + textBox1.Text);
            Registeration customer = new Registeration();

            if (comboBox1.Text == "Hollywood")
            {
                key = 1;
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT ID, Name, No, Email, Gender, Tickets, Address, Day, Movie, Bill, Time, Date FROM HollywoodRegisterations WHERE ID = @id", con);
                cmd.Parameters.AddWithValue("@id", textBox1.Text);
                SqlDataReader SDR = cmd.ExecuteReader();
                while (SDR.Read())
                {
                    customer.set_myid(int.Parse(SDR.GetValue(0).ToString()));
                    customer.Set_name(SDR.GetValue(1).ToString());
                    customer.Set_No(SDR.GetValue(2).ToString());
                    customer.Set_Email(SDR.GetValue(3).ToString());
                    customer.Set_Gender(SDR.GetValue(4).ToString());
                    customer.Set_Tickets(int.Parse(SDR.GetValue(5).ToString()));
                    customer.Set_Address(SDR.GetValue(6).ToString());
                    customer.Set_Day(SDR.GetValue(7).ToString());
                    customer.Set_Movie(SDR.GetValue(8).ToString());
                    customer.Set_Total(int.Parse(SDR.GetValue(9).ToString()));
                    customer.Set_Time(SDR.GetValue(10).ToString());
                    customer.Set_DateTime(SDR.GetValue(11).ToString());
                }
                con.Close();
                MessageBox.Show(customer.Get_Total().ToString());
            }
            else if (comboBox1.Text == "Bollywood")
            {
                key = 2;
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT ID, Name, No, Email, Gender, Tickets, Address, Day, Movie, Bill, Time, Date FROM BollywoodRegisterations WHERE ID = @id", con);
                cmd.Parameters.AddWithValue("@id", textBox1.Text);
                SqlDataReader SDR = cmd.ExecuteReader();
                while (SDR.Read())
                {
                    customer.set_myid(int.Parse(SDR.GetValue(0).ToString()));
                    customer.Set_name(SDR.GetValue(1).ToString());
                    customer.Set_No(SDR.GetValue(2).ToString());
                    customer.Set_Email(SDR.GetValue(3).ToString());
                    customer.Set_Gender(SDR.GetValue(4).ToString());
                    customer.Set_Tickets(int.Parse(SDR.GetValue(5).ToString()));
                    customer.Set_Address(SDR.GetValue(6).ToString());
                    customer.Set_Day(SDR.GetValue(7).ToString());
                    customer.Set_Movie(SDR.GetValue(8).ToString());
                    customer.Set_Total(int.Parse(SDR.GetValue(9).ToString()));
                    customer.Set_Time(SDR.GetValue(10).ToString());
                    customer.Set_DateTime(SDR.GetValue(11).ToString());
                }
                con.Close();
            }
            else
            {
                MessageBox.Show("Kindly select relevant category");
            }


            name_copy = customer.Get_name();
            No_copy = customer.Get_No();
            email_copy = customer.Get_Email();
            gender_copy = customer.Get_Gender();
            Tickets_copy = customer.Get_Tickets();
            address_copy = customer.Get_Address();
            Day_copy = customer.Get_Day();
            Movie_copy = customer.Get_Movie();
            Amount_copy = customer.Get_Total();
            timing_copy = customer.Get_Time();
            DT_copy = customer.Get_DateTime();
            Book_ID = customer.get_myid();


            if (name_copy == null)
            {
                MessageBox.Show("couldnt locate your reservation \nEnter correct ID");
            }
            else
            {
                Cancel_Form C = new Cancel_Form();
                C.ShowDialog();
            }

        }

        private void Cancel_Registeration_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Hollywood");
            comboBox1.Items.Add("Bollywood");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Services S = new Services();
            S.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
