﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBSm1 : Form
    {
        public ShowReservation_BBSm1()
        {
            InitializeComponent();
        }

        private void ShowReservatio_BBSm1_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBSm1.Book_ID.ToString();
            textBox2.Text = BBSm1.name_copy;
            textBox3.Text = BBSm1.No_copy;
            textBox4.Text = BBSm1.email_copy;
            textBox5.Text = BBSm1.gender_copy;
            textBox6.Text = BBSm1.Tickets_copy.ToString();
            textBox7.Text = BBSm1.Day_copy;
            textBox8.Text = BBSm1.Movie_copy;
            textBox9.Text = BBSm1.Amount_copy.ToString();
            textBox10.Text = BBSm1.timing_copy;
            textBox11.Text = BBSm1.address_copy;
            textBox12.Text = BBSm1.DT_copy;
        }
    }
}
