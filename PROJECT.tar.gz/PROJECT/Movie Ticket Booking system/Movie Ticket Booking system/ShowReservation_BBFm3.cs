﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBFm3 : Form
    {
        public ShowReservation_BBFm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBFm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBFm3.Book_ID.ToString();
            textBox2.Text = BBFm3.name_copy;
            textBox3.Text = BBFm3.No_copy;
            textBox4.Text = BBFm3.email_copy;
            textBox5.Text = BBFm3.gender_copy;
            textBox6.Text = BBFm3.Tickets_copy.ToString();
            textBox7.Text = BBFm3.Day_copy;
            textBox8.Text = BBFm3.Movie_copy;
            textBox9.Text = BBFm3.Amount_copy.ToString();
            textBox10.Text = BBFm3.timing_copy;
            textBox11.Text = BBFm3.address_copy;
            textBox12.Text = BBFm3.DT_copy;
        }
    }
}
