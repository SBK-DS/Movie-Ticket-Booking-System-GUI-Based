﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Movie_Ticket_Booking_system
{
    public partial class Booking_Bollywood_Thursday : Form
    {
        public Booking_Bollywood_Thursday()
        {
            InitializeComponent();
        }


        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-UAV1AAR\SQLEXPRESS;Initial Catalog=OOPDATABASE;Integrated Security=True");




        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            BBTHm1 BBTHM1 = new BBTHm1();
            BBTHM1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            BBTHm2 BBTHM2 = new BBTHm2();
            BBTHM2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            BBTHm3 BBTHM3 = new BBTHm3();
            BBTHM3.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Bollywood B = new Booking_Bollywood();
            B.ShowDialog();
        }

        private void Booking_Bollywood_Thursday_Load(object sender, EventArgs e)
        {
            string name = null;
            int count = 0;
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Name FROM TicketsDetails WHERE Category = 1 and Day = 4 and Movie = 1", con);
            SqlDataReader sd = cmd.ExecuteReader();
            while (sd.Read())
            {
                name = sd.GetValue(0).ToString();
            }
            con.Close();
            button1.Text = name;

            con.Open();
            SqlCommand cmd1 = new SqlCommand("SELECT Tickets FROM TicketsDetails WHERE Category = 1 and Day = 4 and Movie = 1", con);
            SqlDataReader sd1 = cmd1.ExecuteReader();
            while (sd1.Read())
            {
                count = int.Parse(sd1.GetValue(0).ToString());
            }
            con.Close();
            label4.Text = count.ToString();





            string name1 = null;
            int count1 = 0;
            con.Open();
            SqlCommand cmd2 = new SqlCommand("SELECT Name FROM TicketsDetails WHERE Category = 1 and Day = 4 and Movie = 2", con);
            SqlDataReader sd2 = cmd2.ExecuteReader();
            while (sd2.Read())
            {
                name1 = sd2.GetValue(0).ToString();
            }
            con.Close();
            button2.Text = name1;

            con.Open();
            SqlCommand cmd3 = new SqlCommand("SELECT Tickets FROM TicketsDetails WHERE Category = 1 and Day = 4 and Movie = 2", con);
            SqlDataReader sd3 = cmd3.ExecuteReader();
            while (sd3.Read())
            {
                count1 = int.Parse(sd3.GetValue(0).ToString());
            }
            con.Close();
            label5.Text = count.ToString();





            string name2 = null;
            int count2 = 0;
            con.Open();
            SqlCommand cmd4 = new SqlCommand("SELECT Name FROM TicketsDetails WHERE Category = 1 and Day = 4 and Movie = 3", con);
            SqlDataReader sd4 = cmd4.ExecuteReader();
            while (sd4.Read())
            {
                name2 = sd4.GetValue(0).ToString();
            }
            con.Close();
            button3.Text = name2;

            con.Open();
            SqlCommand cmd5 = new SqlCommand("SELECT Tickets FROM TicketsDetails WHERE Category = 1 and Day = 4 and Movie = 3", con);
            SqlDataReader sd5 = cmd5.ExecuteReader();
            while (sd5.Read())
            {
                count2 = int.Parse(sd5.GetValue(0).ToString());
            }
            con.Close();
            label6.Text = count2.ToString();

        }
    }
}
