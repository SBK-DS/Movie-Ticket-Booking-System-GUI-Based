﻿namespace Movie_Ticket_Booking_system
{
    partial class BBTm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBTm1));
            this.Register3T = new System.Windows.Forms.Button();
            this.AddresstextBox3T = new System.Windows.Forms.TextBox();
            this.Addresslabel3T = new System.Windows.Forms.Label();
            this.TicketstextBox3T = new System.Windows.Forms.TextBox();
            this.Ticketslabel3T = new System.Windows.Forms.Label();
            this.NotextBox3T = new System.Windows.Forms.TextBox();
            this.Nolabel3T = new System.Windows.Forms.Label();
            this.EmailtextBox3T = new System.Windows.Forms.TextBox();
            this.Emaillabel3T = new System.Windows.Forms.Label();
            this.GendertextBox3T = new System.Windows.Forms.TextBox();
            this.Genderlabel3T = new System.Windows.Forms.Label();
            this.NametextBox3T = new System.Windows.Forms.TextBox();
            this.Namelabel3T = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Register3T
            // 
            this.Register3T.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register3T.Location = new System.Drawing.Point(480, 525);
            this.Register3T.Name = "Register3T";
            this.Register3T.Size = new System.Drawing.Size(286, 83);
            this.Register3T.TabIndex = 56;
            this.Register3T.Text = "Register";
            this.Register3T.UseVisualStyleBackColor = true;
            this.Register3T.Click += new System.EventHandler(this.Register3_Click);
            // 
            // AddresstextBox3T
            // 
            this.AddresstextBox3T.Location = new System.Drawing.Point(421, 396);
            this.AddresstextBox3T.Multiline = true;
            this.AddresstextBox3T.Name = "AddresstextBox3T";
            this.AddresstextBox3T.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox3T.TabIndex = 55;
            // 
            // Addresslabel3T
            // 
            this.Addresslabel3T.AutoSize = true;
            this.Addresslabel3T.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel3T.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel3T.Location = new System.Drawing.Point(313, 384);
            this.Addresslabel3T.Name = "Addresslabel3T";
            this.Addresslabel3T.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel3T.TabIndex = 54;
            this.Addresslabel3T.Text = "Add";
            // 
            // TicketstextBox3T
            // 
            this.TicketstextBox3T.Location = new System.Drawing.Point(421, 340);
            this.TicketstextBox3T.Name = "TicketstextBox3T";
            this.TicketstextBox3T.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox3T.TabIndex = 53;
            // 
            // Ticketslabel3T
            // 
            this.Ticketslabel3T.AutoSize = true;
            this.Ticketslabel3T.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel3T.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel3T.Location = new System.Drawing.Point(313, 329);
            this.Ticketslabel3T.Name = "Ticketslabel3T";
            this.Ticketslabel3T.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel3T.TabIndex = 52;
            this.Ticketslabel3T.Text = "Tickets";
            // 
            // NotextBox3T
            // 
            this.NotextBox3T.Location = new System.Drawing.Point(421, 178);
            this.NotextBox3T.Name = "NotextBox3T";
            this.NotextBox3T.Size = new System.Drawing.Size(539, 20);
            this.NotextBox3T.TabIndex = 51;
            // 
            // Nolabel3T
            // 
            this.Nolabel3T.AutoSize = true;
            this.Nolabel3T.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel3T.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel3T.Location = new System.Drawing.Point(313, 167);
            this.Nolabel3T.Name = "Nolabel3T";
            this.Nolabel3T.Size = new System.Drawing.Size(49, 31);
            this.Nolabel3T.TabIndex = 50;
            this.Nolabel3T.Text = "No";
            // 
            // EmailtextBox3T
            // 
            this.EmailtextBox3T.Location = new System.Drawing.Point(421, 234);
            this.EmailtextBox3T.Name = "EmailtextBox3T";
            this.EmailtextBox3T.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox3T.TabIndex = 49;
            // 
            // Emaillabel3T
            // 
            this.Emaillabel3T.AutoSize = true;
            this.Emaillabel3T.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel3T.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel3T.Location = new System.Drawing.Point(313, 223);
            this.Emaillabel3T.Name = "Emaillabel3T";
            this.Emaillabel3T.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel3T.TabIndex = 48;
            this.Emaillabel3T.Text = "Email";
            // 
            // GendertextBox3T
            // 
            this.GendertextBox3T.Location = new System.Drawing.Point(421, 286);
            this.GendertextBox3T.Name = "GendertextBox3T";
            this.GendertextBox3T.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox3T.TabIndex = 47;
            // 
            // Genderlabel3T
            // 
            this.Genderlabel3T.AutoSize = true;
            this.Genderlabel3T.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel3T.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel3T.Location = new System.Drawing.Point(313, 275);
            this.Genderlabel3T.Name = "Genderlabel3T";
            this.Genderlabel3T.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel3T.TabIndex = 46;
            this.Genderlabel3T.Text = "Gender";
            // 
            // NametextBox3T
            // 
            this.NametextBox3T.Location = new System.Drawing.Point(421, 123);
            this.NametextBox3T.Name = "NametextBox3T";
            this.NametextBox3T.Size = new System.Drawing.Size(539, 20);
            this.NametextBox3T.TabIndex = 45;
            this.NametextBox3T.TextChanged += new System.EventHandler(this.NametextBox2_TextChanged);
            // 
            // Namelabel3T
            // 
            this.Namelabel3T.AutoSize = true;
            this.Namelabel3T.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel3T.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel3T.Location = new System.Drawing.Point(313, 112);
            this.Namelabel3T.Name = "Namelabel3T";
            this.Namelabel3T.Size = new System.Drawing.Size(86, 31);
            this.Namelabel3T.TabIndex = 44;
            this.Namelabel3T.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1197, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 57;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // BBTm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1253, 705);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register3T);
            this.Controls.Add(this.AddresstextBox3T);
            this.Controls.Add(this.Addresslabel3T);
            this.Controls.Add(this.TicketstextBox3T);
            this.Controls.Add(this.Ticketslabel3T);
            this.Controls.Add(this.NotextBox3T);
            this.Controls.Add(this.Nolabel3T);
            this.Controls.Add(this.EmailtextBox3T);
            this.Controls.Add(this.Emaillabel3T);
            this.Controls.Add(this.GendertextBox3T);
            this.Controls.Add(this.Genderlabel3T);
            this.Controls.Add(this.NametextBox3T);
            this.Controls.Add(this.Namelabel3T);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBTm1";
            this.Text = "BBTm1";
            this.Load += new System.EventHandler(this.BBTm1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Register3T;
        private System.Windows.Forms.TextBox AddresstextBox3T;
        private System.Windows.Forms.Label Addresslabel3T;
        private System.Windows.Forms.TextBox TicketstextBox3T;
        private System.Windows.Forms.Label Ticketslabel3T;
        private System.Windows.Forms.TextBox NotextBox3T;
        private System.Windows.Forms.Label Nolabel3T;
        private System.Windows.Forms.TextBox EmailtextBox3T;
        private System.Windows.Forms.Label Emaillabel3T;
        private System.Windows.Forms.TextBox GendertextBox3T;
        private System.Windows.Forms.Label Genderlabel3T;
        private System.Windows.Forms.TextBox NametextBox3T;
        private System.Windows.Forms.Label Namelabel3T;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}