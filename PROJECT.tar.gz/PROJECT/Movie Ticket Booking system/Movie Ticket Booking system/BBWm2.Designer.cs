﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBWm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBWm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register7 = new System.Windows.Forms.Button();
            this.AddresstextBox7 = new System.Windows.Forms.TextBox();
            this.Addresslabel7 = new System.Windows.Forms.Label();
            this.TicketstextBox7 = new System.Windows.Forms.TextBox();
            this.Ticketslabel7 = new System.Windows.Forms.Label();
            this.NotextBox7 = new System.Windows.Forms.TextBox();
            this.Nolabel7 = new System.Windows.Forms.Label();
            this.EmailtextBox7 = new System.Windows.Forms.TextBox();
            this.Emaillabel7 = new System.Windows.Forms.Label();
            this.GendertextBox7 = new System.Windows.Forms.TextBox();
            this.Genderlabel7 = new System.Windows.Forms.Label();
            this.NametextBox7 = new System.Windows.Forms.TextBox();
            this.Namelabel7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1199, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 115;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register7
            // 
            this.Register7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register7.Location = new System.Drawing.Point(478, 523);
            this.Register7.Name = "Register7";
            this.Register7.Size = new System.Drawing.Size(286, 83);
            this.Register7.TabIndex = 114;
            this.Register7.Text = "Register";
            this.Register7.UseVisualStyleBackColor = true;
            this.Register7.Click += new System.EventHandler(this.Register7_Click);
            // 
            // AddresstextBox7
            // 
            this.AddresstextBox7.Location = new System.Drawing.Point(419, 394);
            this.AddresstextBox7.Multiline = true;
            this.AddresstextBox7.Name = "AddresstextBox7";
            this.AddresstextBox7.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox7.TabIndex = 113;
            // 
            // Addresslabel7
            // 
            this.Addresslabel7.AutoSize = true;
            this.Addresslabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel7.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel7.Location = new System.Drawing.Point(311, 382);
            this.Addresslabel7.Name = "Addresslabel7";
            this.Addresslabel7.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel7.TabIndex = 112;
            this.Addresslabel7.Text = "Add";
            // 
            // TicketstextBox7
            // 
            this.TicketstextBox7.Location = new System.Drawing.Point(419, 338);
            this.TicketstextBox7.Name = "TicketstextBox7";
            this.TicketstextBox7.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox7.TabIndex = 111;
            // 
            // Ticketslabel7
            // 
            this.Ticketslabel7.AutoSize = true;
            this.Ticketslabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel7.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel7.Location = new System.Drawing.Point(311, 327);
            this.Ticketslabel7.Name = "Ticketslabel7";
            this.Ticketslabel7.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel7.TabIndex = 110;
            this.Ticketslabel7.Text = "Tickets";
            // 
            // NotextBox7
            // 
            this.NotextBox7.Location = new System.Drawing.Point(419, 176);
            this.NotextBox7.Name = "NotextBox7";
            this.NotextBox7.Size = new System.Drawing.Size(539, 20);
            this.NotextBox7.TabIndex = 109;
            // 
            // Nolabel7
            // 
            this.Nolabel7.AutoSize = true;
            this.Nolabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel7.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel7.Location = new System.Drawing.Point(311, 165);
            this.Nolabel7.Name = "Nolabel7";
            this.Nolabel7.Size = new System.Drawing.Size(49, 31);
            this.Nolabel7.TabIndex = 108;
            this.Nolabel7.Text = "No";
            // 
            // EmailtextBox7
            // 
            this.EmailtextBox7.Location = new System.Drawing.Point(419, 232);
            this.EmailtextBox7.Name = "EmailtextBox7";
            this.EmailtextBox7.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox7.TabIndex = 107;
            // 
            // Emaillabel7
            // 
            this.Emaillabel7.AutoSize = true;
            this.Emaillabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel7.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel7.Location = new System.Drawing.Point(311, 221);
            this.Emaillabel7.Name = "Emaillabel7";
            this.Emaillabel7.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel7.TabIndex = 106;
            this.Emaillabel7.Text = "Email";
            // 
            // GendertextBox7
            // 
            this.GendertextBox7.Location = new System.Drawing.Point(419, 284);
            this.GendertextBox7.Name = "GendertextBox7";
            this.GendertextBox7.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox7.TabIndex = 105;
            // 
            // Genderlabel7
            // 
            this.Genderlabel7.AutoSize = true;
            this.Genderlabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel7.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel7.Location = new System.Drawing.Point(311, 273);
            this.Genderlabel7.Name = "Genderlabel7";
            this.Genderlabel7.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel7.TabIndex = 104;
            this.Genderlabel7.Text = "Gender";
            // 
            // NametextBox7
            // 
            this.NametextBox7.Location = new System.Drawing.Point(419, 121);
            this.NametextBox7.Name = "NametextBox7";
            this.NametextBox7.Size = new System.Drawing.Size(539, 20);
            this.NametextBox7.TabIndex = 103;
            // 
            // Namelabel7
            // 
            this.Namelabel7.AutoSize = true;
            this.Namelabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel7.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel7.Location = new System.Drawing.Point(311, 110);
            this.Namelabel7.Name = "Namelabel7";
            this.Namelabel7.Size = new System.Drawing.Size(86, 31);
            this.Namelabel7.TabIndex = 102;
            this.Namelabel7.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 101;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBWm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1255, 705);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register7);
            this.Controls.Add(this.AddresstextBox7);
            this.Controls.Add(this.Addresslabel7);
            this.Controls.Add(this.TicketstextBox7);
            this.Controls.Add(this.Ticketslabel7);
            this.Controls.Add(this.NotextBox7);
            this.Controls.Add(this.Nolabel7);
            this.Controls.Add(this.EmailtextBox7);
            this.Controls.Add(this.Emaillabel7);
            this.Controls.Add(this.GendertextBox7);
            this.Controls.Add(this.Genderlabel7);
            this.Controls.Add(this.NametextBox7);
            this.Controls.Add(this.Namelabel7);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBWm2";
            this.Text = "BBWm2";
            this.Load += new System.EventHandler(this.BBWm2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register7;
        private System.Windows.Forms.TextBox AddresstextBox7;
        private System.Windows.Forms.Label Addresslabel7;
        private System.Windows.Forms.TextBox TicketstextBox7;
        private System.Windows.Forms.Label Ticketslabel7;
        private System.Windows.Forms.TextBox NotextBox7;
        private System.Windows.Forms.Label Nolabel7;
        private System.Windows.Forms.TextBox EmailtextBox7;
        private System.Windows.Forms.Label Emaillabel7;
        private System.Windows.Forms.TextBox GendertextBox7;
        private System.Windows.Forms.Label Genderlabel7;
        private System.Windows.Forms.TextBox NametextBox7;
        private System.Windows.Forms.Label Namelabel7;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}