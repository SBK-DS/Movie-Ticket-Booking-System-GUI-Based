﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_Check : Form
    {
        public ShowReservation_Check()
        {
            InitializeComponent();
        }

        private void ShowReservation_Check_Load(object sender, EventArgs e)
        {
            textBox1.Text = Check_Reservation.Book_ID.ToString();
            textBox2.Text = Check_Reservation.name_copy;
            textBox3.Text = Check_Reservation.No_copy;
            textBox4.Text = Check_Reservation.email_copy;
            textBox5.Text = Check_Reservation.gender_copy;
            textBox6.Text = Check_Reservation.Tickets_copy.ToString();
            textBox7.Text = Check_Reservation.Day_copy;
            textBox8.Text = Check_Reservation.Movie_copy;
            textBox9.Text = Check_Reservation.Amount_copy.ToString();
            textBox10.Text = Check_Reservation.timing_copy;
            textBox11.Text = Check_Reservation.address_copy;
            textBox12.Text = Check_Reservation.DT_copy;
        }
    }
}
