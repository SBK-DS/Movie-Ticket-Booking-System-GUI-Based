﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBSUm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBSUm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register18 = new System.Windows.Forms.Button();
            this.AddresstextBox18 = new System.Windows.Forms.TextBox();
            this.Addresslabel18 = new System.Windows.Forms.Label();
            this.TicketstextBox18 = new System.Windows.Forms.TextBox();
            this.Ticketslabel18 = new System.Windows.Forms.Label();
            this.NotextBox18 = new System.Windows.Forms.TextBox();
            this.Nolabel18 = new System.Windows.Forms.Label();
            this.EmailtextBox18 = new System.Windows.Forms.TextBox();
            this.Emaillabel18 = new System.Windows.Forms.Label();
            this.GendertextBox18 = new System.Windows.Forms.TextBox();
            this.Genderlabel18 = new System.Windows.Forms.Label();
            this.NametextBox18 = new System.Windows.Forms.TextBox();
            this.Namelabel18 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1203, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 205;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register18
            // 
            this.Register18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register18.Location = new System.Drawing.Point(482, 523);
            this.Register18.Name = "Register18";
            this.Register18.Size = new System.Drawing.Size(286, 83);
            this.Register18.TabIndex = 204;
            this.Register18.Text = "Register";
            this.Register18.UseVisualStyleBackColor = true;
            this.Register18.Click += new System.EventHandler(this.Register18_Click);
            // 
            // AddresstextBox18
            // 
            this.AddresstextBox18.Location = new System.Drawing.Point(423, 394);
            this.AddresstextBox18.Multiline = true;
            this.AddresstextBox18.Name = "AddresstextBox18";
            this.AddresstextBox18.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox18.TabIndex = 203;
            // 
            // Addresslabel18
            // 
            this.Addresslabel18.AutoSize = true;
            this.Addresslabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel18.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel18.Location = new System.Drawing.Point(315, 382);
            this.Addresslabel18.Name = "Addresslabel18";
            this.Addresslabel18.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel18.TabIndex = 202;
            this.Addresslabel18.Text = "Add";
            // 
            // TicketstextBox18
            // 
            this.TicketstextBox18.Location = new System.Drawing.Point(423, 338);
            this.TicketstextBox18.Name = "TicketstextBox18";
            this.TicketstextBox18.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox18.TabIndex = 201;
            // 
            // Ticketslabel18
            // 
            this.Ticketslabel18.AutoSize = true;
            this.Ticketslabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel18.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel18.Location = new System.Drawing.Point(315, 327);
            this.Ticketslabel18.Name = "Ticketslabel18";
            this.Ticketslabel18.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel18.TabIndex = 200;
            this.Ticketslabel18.Text = "Tickets";
            // 
            // NotextBox18
            // 
            this.NotextBox18.Location = new System.Drawing.Point(423, 176);
            this.NotextBox18.Name = "NotextBox18";
            this.NotextBox18.Size = new System.Drawing.Size(539, 20);
            this.NotextBox18.TabIndex = 199;
            // 
            // Nolabel18
            // 
            this.Nolabel18.AutoSize = true;
            this.Nolabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel18.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel18.Location = new System.Drawing.Point(315, 165);
            this.Nolabel18.Name = "Nolabel18";
            this.Nolabel18.Size = new System.Drawing.Size(49, 31);
            this.Nolabel18.TabIndex = 198;
            this.Nolabel18.Text = "No";
            // 
            // EmailtextBox18
            // 
            this.EmailtextBox18.Location = new System.Drawing.Point(423, 232);
            this.EmailtextBox18.Name = "EmailtextBox18";
            this.EmailtextBox18.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox18.TabIndex = 197;
            // 
            // Emaillabel18
            // 
            this.Emaillabel18.AutoSize = true;
            this.Emaillabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel18.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel18.Location = new System.Drawing.Point(315, 221);
            this.Emaillabel18.Name = "Emaillabel18";
            this.Emaillabel18.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel18.TabIndex = 196;
            this.Emaillabel18.Text = "Email";
            // 
            // GendertextBox18
            // 
            this.GendertextBox18.Location = new System.Drawing.Point(423, 284);
            this.GendertextBox18.Name = "GendertextBox18";
            this.GendertextBox18.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox18.TabIndex = 195;
            // 
            // Genderlabel18
            // 
            this.Genderlabel18.AutoSize = true;
            this.Genderlabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel18.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel18.Location = new System.Drawing.Point(315, 273);
            this.Genderlabel18.Name = "Genderlabel18";
            this.Genderlabel18.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel18.TabIndex = 194;
            this.Genderlabel18.Text = "Gender";
            // 
            // NametextBox18
            // 
            this.NametextBox18.Location = new System.Drawing.Point(423, 121);
            this.NametextBox18.Name = "NametextBox18";
            this.NametextBox18.Size = new System.Drawing.Size(539, 20);
            this.NametextBox18.TabIndex = 193;
            // 
            // Namelabel18
            // 
            this.Namelabel18.AutoSize = true;
            this.Namelabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel18.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel18.Location = new System.Drawing.Point(315, 109);
            this.Namelabel18.Name = "Namelabel18";
            this.Namelabel18.Size = new System.Drawing.Size(86, 31);
            this.Namelabel18.TabIndex = 192;
            this.Namelabel18.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 191;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBSUm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1259, 703);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register18);
            this.Controls.Add(this.AddresstextBox18);
            this.Controls.Add(this.Addresslabel18);
            this.Controls.Add(this.TicketstextBox18);
            this.Controls.Add(this.Ticketslabel18);
            this.Controls.Add(this.NotextBox18);
            this.Controls.Add(this.Nolabel18);
            this.Controls.Add(this.EmailtextBox18);
            this.Controls.Add(this.Emaillabel18);
            this.Controls.Add(this.GendertextBox18);
            this.Controls.Add(this.Genderlabel18);
            this.Controls.Add(this.NametextBox18);
            this.Controls.Add(this.Namelabel18);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBSUm1";
            this.Text = "BBSUm1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register18;
        private System.Windows.Forms.TextBox AddresstextBox18;
        private System.Windows.Forms.Label Addresslabel18;
        private System.Windows.Forms.TextBox TicketstextBox18;
        private System.Windows.Forms.Label Ticketslabel18;
        private System.Windows.Forms.TextBox NotextBox18;
        private System.Windows.Forms.Label Nolabel18;
        private System.Windows.Forms.TextBox EmailtextBox18;
        private System.Windows.Forms.Label Emaillabel18;
        private System.Windows.Forms.TextBox GendertextBox18;
        private System.Windows.Forms.Label Genderlabel18;
        private System.Windows.Forms.TextBox NametextBox18;
        private System.Windows.Forms.Label Namelabel18;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}