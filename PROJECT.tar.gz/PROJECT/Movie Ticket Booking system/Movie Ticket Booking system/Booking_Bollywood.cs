﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class Booking_Bollywood : Form
    {
        public Booking_Bollywood()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Bollywood_Monday BBM = new Booking_Bollywood_Monday();
            BBM.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Bollywood_Tuesday BBT = new Booking_Bollywood_Tuesday();
            BBT.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Bollywood_Wednesday BBW = new Booking_Bollywood_Wednesday();
            BBW.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Bollywood_Thursday BBTH = new Booking_Bollywood_Thursday();
            BBTH.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Bollywood_Friday BBF = new Booking_Bollywood_Friday();
            BBF.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Bollywood_Saturday BBS = new Booking_Bollywood_Saturday();
            BBS.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Bollywood_Sunday BBSU = new Booking_Bollywood_Sunday();
            BBSU.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking B = new Booking();
            B.ShowDialog();
        }
    }
}
