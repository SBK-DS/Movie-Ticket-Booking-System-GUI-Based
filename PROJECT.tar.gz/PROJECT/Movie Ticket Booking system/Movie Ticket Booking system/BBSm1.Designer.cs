﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBSm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBSm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register15 = new System.Windows.Forms.Button();
            this.AddresstextBox15 = new System.Windows.Forms.TextBox();
            this.Addresslabel15 = new System.Windows.Forms.Label();
            this.TicketstextBox15 = new System.Windows.Forms.TextBox();
            this.Ticketslabel15 = new System.Windows.Forms.Label();
            this.NotextBox15 = new System.Windows.Forms.TextBox();
            this.Nolabel15 = new System.Windows.Forms.Label();
            this.EmailtextBox15 = new System.Windows.Forms.TextBox();
            this.Emaillabel15 = new System.Windows.Forms.Label();
            this.GendertextBox15 = new System.Windows.Forms.TextBox();
            this.Genderlabel15 = new System.Windows.Forms.Label();
            this.NametextBox15 = new System.Windows.Forms.TextBox();
            this.Namelabel15 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1202, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 205;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register15
            // 
            this.Register15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register15.Location = new System.Drawing.Point(481, 523);
            this.Register15.Name = "Register15";
            this.Register15.Size = new System.Drawing.Size(286, 83);
            this.Register15.TabIndex = 204;
            this.Register15.Text = "Register";
            this.Register15.UseVisualStyleBackColor = true;
            this.Register15.Click += new System.EventHandler(this.Register15_Click);
            // 
            // AddresstextBox15
            // 
            this.AddresstextBox15.Location = new System.Drawing.Point(422, 394);
            this.AddresstextBox15.Multiline = true;
            this.AddresstextBox15.Name = "AddresstextBox15";
            this.AddresstextBox15.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox15.TabIndex = 203;
            // 
            // Addresslabel15
            // 
            this.Addresslabel15.AutoSize = true;
            this.Addresslabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel15.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel15.Location = new System.Drawing.Point(314, 382);
            this.Addresslabel15.Name = "Addresslabel15";
            this.Addresslabel15.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel15.TabIndex = 202;
            this.Addresslabel15.Text = "Add";
            // 
            // TicketstextBox15
            // 
            this.TicketstextBox15.Location = new System.Drawing.Point(422, 338);
            this.TicketstextBox15.Name = "TicketstextBox15";
            this.TicketstextBox15.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox15.TabIndex = 201;
            // 
            // Ticketslabel15
            // 
            this.Ticketslabel15.AutoSize = true;
            this.Ticketslabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel15.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel15.Location = new System.Drawing.Point(314, 327);
            this.Ticketslabel15.Name = "Ticketslabel15";
            this.Ticketslabel15.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel15.TabIndex = 200;
            this.Ticketslabel15.Text = "Tickets";
            // 
            // NotextBox15
            // 
            this.NotextBox15.Location = new System.Drawing.Point(422, 176);
            this.NotextBox15.Name = "NotextBox15";
            this.NotextBox15.Size = new System.Drawing.Size(539, 20);
            this.NotextBox15.TabIndex = 199;
            // 
            // Nolabel15
            // 
            this.Nolabel15.AutoSize = true;
            this.Nolabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel15.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel15.Location = new System.Drawing.Point(314, 165);
            this.Nolabel15.Name = "Nolabel15";
            this.Nolabel15.Size = new System.Drawing.Size(49, 31);
            this.Nolabel15.TabIndex = 198;
            this.Nolabel15.Text = "No";
            // 
            // EmailtextBox15
            // 
            this.EmailtextBox15.Location = new System.Drawing.Point(422, 232);
            this.EmailtextBox15.Name = "EmailtextBox15";
            this.EmailtextBox15.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox15.TabIndex = 197;
            // 
            // Emaillabel15
            // 
            this.Emaillabel15.AutoSize = true;
            this.Emaillabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel15.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel15.Location = new System.Drawing.Point(314, 221);
            this.Emaillabel15.Name = "Emaillabel15";
            this.Emaillabel15.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel15.TabIndex = 196;
            this.Emaillabel15.Text = "Email";
            // 
            // GendertextBox15
            // 
            this.GendertextBox15.Location = new System.Drawing.Point(422, 284);
            this.GendertextBox15.Name = "GendertextBox15";
            this.GendertextBox15.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox15.TabIndex = 195;
            // 
            // Genderlabel15
            // 
            this.Genderlabel15.AutoSize = true;
            this.Genderlabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel15.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel15.Location = new System.Drawing.Point(314, 273);
            this.Genderlabel15.Name = "Genderlabel15";
            this.Genderlabel15.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel15.TabIndex = 194;
            this.Genderlabel15.Text = "Gender";
            // 
            // NametextBox15
            // 
            this.NametextBox15.Location = new System.Drawing.Point(422, 121);
            this.NametextBox15.Name = "NametextBox15";
            this.NametextBox15.Size = new System.Drawing.Size(539, 20);
            this.NametextBox15.TabIndex = 193;
            // 
            // Namelabel15
            // 
            this.Namelabel15.AutoSize = true;
            this.Namelabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel15.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel15.Location = new System.Drawing.Point(314, 109);
            this.Namelabel15.Name = "Namelabel15";
            this.Namelabel15.Size = new System.Drawing.Size(86, 31);
            this.Namelabel15.TabIndex = 192;
            this.Namelabel15.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 191;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBSm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1258, 702);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register15);
            this.Controls.Add(this.AddresstextBox15);
            this.Controls.Add(this.Addresslabel15);
            this.Controls.Add(this.TicketstextBox15);
            this.Controls.Add(this.Ticketslabel15);
            this.Controls.Add(this.NotextBox15);
            this.Controls.Add(this.Nolabel15);
            this.Controls.Add(this.EmailtextBox15);
            this.Controls.Add(this.Emaillabel15);
            this.Controls.Add(this.GendertextBox15);
            this.Controls.Add(this.Genderlabel15);
            this.Controls.Add(this.NametextBox15);
            this.Controls.Add(this.Namelabel15);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBSm1";
            this.Text = "BBSm1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register15;
        private System.Windows.Forms.TextBox AddresstextBox15;
        private System.Windows.Forms.Label Addresslabel15;
        private System.Windows.Forms.TextBox TicketstextBox15;
        private System.Windows.Forms.Label Ticketslabel15;
        private System.Windows.Forms.TextBox NotextBox15;
        private System.Windows.Forms.Label Nolabel15;
        private System.Windows.Forms.TextBox EmailtextBox15;
        private System.Windows.Forms.Label Emaillabel15;
        private System.Windows.Forms.TextBox GendertextBox15;
        private System.Windows.Forms.Label Genderlabel15;
        private System.Windows.Forms.TextBox NametextBox15;
        private System.Windows.Forms.Label Namelabel15;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}