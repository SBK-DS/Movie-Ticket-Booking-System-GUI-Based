﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHFm2 : Form
    {
        public ShowReservation_BHFm2()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHFm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHFm2.Book_ID.ToString();
            textBox2.Text = BHFm2.name_copy;
            textBox3.Text = BHFm2.No_copy;
            textBox4.Text = BHFm2.email_copy;
            textBox5.Text = BHFm2.gender_copy;
            textBox6.Text = BHFm2.Tickets_copy.ToString();
            textBox7.Text = BHFm2.Day_copy;
            textBox8.Text = BHFm2.Movie_copy;
            textBox9.Text = BHFm2.Amount_copy.ToString();
            textBox10.Text = BHFm2.timing_copy;
            textBox11.Text = BHFm2.address_copy;
            textBox12.Text = BHFm2.DT_copy;
        }
    }
}
