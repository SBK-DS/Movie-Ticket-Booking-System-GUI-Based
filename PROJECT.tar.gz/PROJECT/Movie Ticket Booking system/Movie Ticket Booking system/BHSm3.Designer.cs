﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHSm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHSm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH18 = new System.Windows.Forms.Button();
            this.AddresstextBoxH18 = new System.Windows.Forms.TextBox();
            this.AddresslabelH18 = new System.Windows.Forms.Label();
            this.TicketstextBoxH18 = new System.Windows.Forms.TextBox();
            this.TicketslabelH18 = new System.Windows.Forms.Label();
            this.NotextBoxH18 = new System.Windows.Forms.TextBox();
            this.NolabelH18 = new System.Windows.Forms.Label();
            this.EmailtextBoxH18 = new System.Windows.Forms.TextBox();
            this.EmaillabelH18 = new System.Windows.Forms.Label();
            this.GendertextBoxH18 = new System.Windows.Forms.TextBox();
            this.GenderlabelH18 = new System.Windows.Forms.Label();
            this.NametextBoxH18 = new System.Windows.Forms.TextBox();
            this.NamelabelH18 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1195, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 133;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH18
            // 
            this.RegisterH18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH18.Location = new System.Drawing.Point(472, 523);
            this.RegisterH18.Name = "RegisterH18";
            this.RegisterH18.Size = new System.Drawing.Size(286, 83);
            this.RegisterH18.TabIndex = 132;
            this.RegisterH18.Text = "Register";
            this.RegisterH18.UseVisualStyleBackColor = true;
            this.RegisterH18.Click += new System.EventHandler(this.RegisterH18_Click);
            // 
            // AddresstextBoxH18
            // 
            this.AddresstextBoxH18.Location = new System.Drawing.Point(413, 394);
            this.AddresstextBoxH18.Multiline = true;
            this.AddresstextBoxH18.Name = "AddresstextBoxH18";
            this.AddresstextBoxH18.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH18.TabIndex = 131;
            // 
            // AddresslabelH18
            // 
            this.AddresslabelH18.AutoSize = true;
            this.AddresslabelH18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH18.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH18.Location = new System.Drawing.Point(305, 382);
            this.AddresslabelH18.Name = "AddresslabelH18";
            this.AddresslabelH18.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH18.TabIndex = 130;
            this.AddresslabelH18.Text = "Add";
            // 
            // TicketstextBoxH18
            // 
            this.TicketstextBoxH18.Location = new System.Drawing.Point(413, 338);
            this.TicketstextBoxH18.Name = "TicketstextBoxH18";
            this.TicketstextBoxH18.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH18.TabIndex = 129;
            // 
            // TicketslabelH18
            // 
            this.TicketslabelH18.AutoSize = true;
            this.TicketslabelH18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH18.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH18.Location = new System.Drawing.Point(305, 327);
            this.TicketslabelH18.Name = "TicketslabelH18";
            this.TicketslabelH18.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH18.TabIndex = 128;
            this.TicketslabelH18.Text = "Tickets";
            // 
            // NotextBoxH18
            // 
            this.NotextBoxH18.Location = new System.Drawing.Point(413, 176);
            this.NotextBoxH18.Name = "NotextBoxH18";
            this.NotextBoxH18.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH18.TabIndex = 127;
            // 
            // NolabelH18
            // 
            this.NolabelH18.AutoSize = true;
            this.NolabelH18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH18.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH18.Location = new System.Drawing.Point(305, 165);
            this.NolabelH18.Name = "NolabelH18";
            this.NolabelH18.Size = new System.Drawing.Size(49, 31);
            this.NolabelH18.TabIndex = 126;
            this.NolabelH18.Text = "No";
            // 
            // EmailtextBoxH18
            // 
            this.EmailtextBoxH18.Location = new System.Drawing.Point(413, 232);
            this.EmailtextBoxH18.Name = "EmailtextBoxH18";
            this.EmailtextBoxH18.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH18.TabIndex = 125;
            // 
            // EmaillabelH18
            // 
            this.EmaillabelH18.AutoSize = true;
            this.EmaillabelH18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH18.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH18.Location = new System.Drawing.Point(305, 221);
            this.EmaillabelH18.Name = "EmaillabelH18";
            this.EmaillabelH18.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH18.TabIndex = 124;
            this.EmaillabelH18.Text = "Email";
            // 
            // GendertextBoxH18
            // 
            this.GendertextBoxH18.Location = new System.Drawing.Point(413, 284);
            this.GendertextBoxH18.Name = "GendertextBoxH18";
            this.GendertextBoxH18.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH18.TabIndex = 123;
            // 
            // GenderlabelH18
            // 
            this.GenderlabelH18.AutoSize = true;
            this.GenderlabelH18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH18.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH18.Location = new System.Drawing.Point(305, 273);
            this.GenderlabelH18.Name = "GenderlabelH18";
            this.GenderlabelH18.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH18.TabIndex = 122;
            this.GenderlabelH18.Text = "Gender";
            // 
            // NametextBoxH18
            // 
            this.NametextBoxH18.Location = new System.Drawing.Point(413, 121);
            this.NametextBoxH18.Name = "NametextBoxH18";
            this.NametextBoxH18.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH18.TabIndex = 121;
            // 
            // NamelabelH18
            // 
            this.NamelabelH18.AutoSize = true;
            this.NamelabelH18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH18.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH18.Location = new System.Drawing.Point(305, 110);
            this.NamelabelH18.Name = "NamelabelH18";
            this.NamelabelH18.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH18.TabIndex = 120;
            this.NamelabelH18.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 119;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHSm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1251, 698);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH18);
            this.Controls.Add(this.AddresstextBoxH18);
            this.Controls.Add(this.AddresslabelH18);
            this.Controls.Add(this.TicketstextBoxH18);
            this.Controls.Add(this.TicketslabelH18);
            this.Controls.Add(this.NotextBoxH18);
            this.Controls.Add(this.NolabelH18);
            this.Controls.Add(this.EmailtextBoxH18);
            this.Controls.Add(this.EmaillabelH18);
            this.Controls.Add(this.GendertextBoxH18);
            this.Controls.Add(this.GenderlabelH18);
            this.Controls.Add(this.NametextBoxH18);
            this.Controls.Add(this.NamelabelH18);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHSm3";
            this.Text = "BHSm3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH18;
        private System.Windows.Forms.TextBox AddresstextBoxH18;
        private System.Windows.Forms.Label AddresslabelH18;
        private System.Windows.Forms.TextBox TicketstextBoxH18;
        private System.Windows.Forms.Label TicketslabelH18;
        private System.Windows.Forms.TextBox NotextBoxH18;
        private System.Windows.Forms.Label NolabelH18;
        private System.Windows.Forms.TextBox EmailtextBoxH18;
        private System.Windows.Forms.Label EmaillabelH18;
        private System.Windows.Forms.TextBox GendertextBoxH18;
        private System.Windows.Forms.Label GenderlabelH18;
        private System.Windows.Forms.TextBox NametextBoxH18;
        private System.Windows.Forms.Label NamelabelH18;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}