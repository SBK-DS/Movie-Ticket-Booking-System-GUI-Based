﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Movie_Ticket_Booking_system
{
    public partial class Portal_update : Form
    {

        class ADD
        {
            private string new_pass;

            public void set_newpass(string st)
            {
                this.new_pass = st;
            }
            public string get_newpass()
            {
                return new_pass;
            }

        }



        class Manage : ADD
        {
            private string ID;
            private string Password;


            public void set_pass(string Password)
            {
                this.Password = Password;
            }
            public string get_pass()
            {
                return Password;
            }
        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-UAV1AAR\SQLEXPRESS;Initial Catalog=OOPDATABASE;Integrated Security=True");



        public Portal_update()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Manage MG = new Manage();
            con.Open();
            SqlCommand sd = new SqlCommand("SELECT * FROM Manage", con);
            SqlDataReader SD = sd.ExecuteReader();
            while (SD.Read())
            {
                MG.set_pass(SD.GetValue(0).ToString());
            }
            con.Close();
            MessageBox.Show(MG.get_pass());

            if(textBox2.Text != MG.get_pass())
            {
                MessageBox.Show("New Password can not be same as previous");
            }
            else if(textBox1.Text == string.Empty || textBox2.Text == string.Empty)
            {
                MessageBox.Show("Kindly fill the boxes correctly");
            }
            else if(textBox1.Text == textBox2.Text)
            {
                MessageBox.Show("New Password Can not be same as previous");
            }
            else
            {
                MG.set_newpass(textBox1.Text);
                con.Open();
                SqlCommand sd1 = new SqlCommand("UPDATE Manage SET Pass = @set", con);
                sd1.Parameters.AddWithValue("@set", MG.get_newpass());
                sd1.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Password has been updated");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Management_portal mp = new Management_portal();
            mp.ShowDialog();
        }
    }
}
