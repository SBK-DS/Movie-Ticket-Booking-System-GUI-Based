﻿using System;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class Booking_Hollywood : Form
    {
        public Booking_Hollywood()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Hollywood_Monday BHM = new Booking_Hollywood_Monday();
            BHM.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Hollywood_Tuesday BHT = new Booking_Hollywood_Tuesday();
            BHT.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Hollywood_Wednesday BHW = new Booking_Hollywood_Wednesday();
            BHW.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Hollywood_Thursday BHTH = new Booking_Hollywood_Thursday();
            BHTH.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Hollywood_Friday BHF = new Booking_Hollywood_Friday();
            BHF.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Hollywood_Saturday BHS = new Booking_Hollywood_Saturday();
            BHS.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Hollywood_Sunday BHSU = new Booking_Hollywood_Sunday();
            BHSU.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking B = new Booking();
            B.ShowDialog();
        }
    }
}
