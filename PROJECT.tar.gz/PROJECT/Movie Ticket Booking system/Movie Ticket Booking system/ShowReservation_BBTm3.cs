﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBTm3 : Form
    {
        public ShowReservation_BBTm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBTm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBTm3.Book_ID.ToString();
            textBox2.Text = BBTm3.name_copy;
            textBox3.Text = BBTm3.No_copy;
            textBox4.Text = BBTm3.email_copy;
            textBox5.Text = BBTm3.gender_copy;
            textBox6.Text = BBTm3.Tickets_copy.ToString();
            textBox7.Text = BBTm3.Day_copy;
            textBox8.Text = BBTm3.Movie_copy;
            textBox9.Text = BBTm3.Amount_copy.ToString();
            textBox10.Text = BBTm3.timing_copy;
            textBox11.Text = BBTm3.address_copy;
            textBox12.Text = BBTm3.DT_copy;
        }
    }
}
