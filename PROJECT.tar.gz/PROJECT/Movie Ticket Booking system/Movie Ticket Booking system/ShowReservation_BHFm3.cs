﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHFm3 : Form
    {
        public ShowReservation_BHFm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHFm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHFm3.Book_ID.ToString();
            textBox2.Text = BHFm3.name_copy;
            textBox3.Text = BHFm3.No_copy;
            textBox4.Text = BHFm3.email_copy;
            textBox5.Text = BHFm3.gender_copy;
            textBox6.Text = BHFm3.Tickets_copy.ToString();
            textBox7.Text = BHFm3.Day_copy;
            textBox8.Text = BHFm3.Movie_copy;
            textBox9.Text = BHFm3.Amount_copy.ToString();
            textBox10.Text = BHFm3.timing_copy;
            textBox11.Text = BHFm3.address_copy;
            textBox12.Text = BHFm3.DT_copy;
        }
    }
}
