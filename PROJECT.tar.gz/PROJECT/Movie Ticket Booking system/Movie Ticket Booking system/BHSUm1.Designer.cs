﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHSUm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHSUm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH19 = new System.Windows.Forms.Button();
            this.AddresstextBoxH19 = new System.Windows.Forms.TextBox();
            this.AddresslabelH19 = new System.Windows.Forms.Label();
            this.TicketstextBoxH19 = new System.Windows.Forms.TextBox();
            this.TicketslabelH19 = new System.Windows.Forms.Label();
            this.NotextBoxH19 = new System.Windows.Forms.TextBox();
            this.NolabelH19 = new System.Windows.Forms.Label();
            this.EmailtextBoxH19 = new System.Windows.Forms.TextBox();
            this.EmaillabelH19 = new System.Windows.Forms.Label();
            this.GendertextBoxH19 = new System.Windows.Forms.TextBox();
            this.GenderlabelH19 = new System.Windows.Forms.Label();
            this.NametextBoxH19 = new System.Windows.Forms.TextBox();
            this.NamelabelH19 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1195, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 148;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH19
            // 
            this.RegisterH19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH19.Location = new System.Drawing.Point(472, 523);
            this.RegisterH19.Name = "RegisterH19";
            this.RegisterH19.Size = new System.Drawing.Size(286, 83);
            this.RegisterH19.TabIndex = 147;
            this.RegisterH19.Text = "Register";
            this.RegisterH19.UseVisualStyleBackColor = true;
            this.RegisterH19.Click += new System.EventHandler(this.RegisterH19_Click);
            // 
            // AddresstextBoxH19
            // 
            this.AddresstextBoxH19.Location = new System.Drawing.Point(413, 394);
            this.AddresstextBoxH19.Multiline = true;
            this.AddresstextBoxH19.Name = "AddresstextBoxH19";
            this.AddresstextBoxH19.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH19.TabIndex = 146;
            // 
            // AddresslabelH19
            // 
            this.AddresslabelH19.AutoSize = true;
            this.AddresslabelH19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH19.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH19.Location = new System.Drawing.Point(305, 382);
            this.AddresslabelH19.Name = "AddresslabelH19";
            this.AddresslabelH19.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH19.TabIndex = 145;
            this.AddresslabelH19.Text = "Add";
            // 
            // TicketstextBoxH19
            // 
            this.TicketstextBoxH19.Location = new System.Drawing.Point(413, 338);
            this.TicketstextBoxH19.Name = "TicketstextBoxH19";
            this.TicketstextBoxH19.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH19.TabIndex = 144;
            // 
            // TicketslabelH19
            // 
            this.TicketslabelH19.AutoSize = true;
            this.TicketslabelH19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH19.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH19.Location = new System.Drawing.Point(305, 327);
            this.TicketslabelH19.Name = "TicketslabelH19";
            this.TicketslabelH19.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH19.TabIndex = 143;
            this.TicketslabelH19.Text = "Tickets";
            // 
            // NotextBoxH19
            // 
            this.NotextBoxH19.Location = new System.Drawing.Point(413, 176);
            this.NotextBoxH19.Name = "NotextBoxH19";
            this.NotextBoxH19.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH19.TabIndex = 142;
            // 
            // NolabelH19
            // 
            this.NolabelH19.AutoSize = true;
            this.NolabelH19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH19.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH19.Location = new System.Drawing.Point(305, 165);
            this.NolabelH19.Name = "NolabelH19";
            this.NolabelH19.Size = new System.Drawing.Size(49, 31);
            this.NolabelH19.TabIndex = 141;
            this.NolabelH19.Text = "No";
            // 
            // EmailtextBoxH19
            // 
            this.EmailtextBoxH19.Location = new System.Drawing.Point(413, 232);
            this.EmailtextBoxH19.Name = "EmailtextBoxH19";
            this.EmailtextBoxH19.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH19.TabIndex = 140;
            // 
            // EmaillabelH19
            // 
            this.EmaillabelH19.AutoSize = true;
            this.EmaillabelH19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH19.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH19.Location = new System.Drawing.Point(305, 221);
            this.EmaillabelH19.Name = "EmaillabelH19";
            this.EmaillabelH19.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH19.TabIndex = 139;
            this.EmaillabelH19.Text = "Email";
            // 
            // GendertextBoxH19
            // 
            this.GendertextBoxH19.Location = new System.Drawing.Point(413, 284);
            this.GendertextBoxH19.Name = "GendertextBoxH19";
            this.GendertextBoxH19.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH19.TabIndex = 138;
            // 
            // GenderlabelH19
            // 
            this.GenderlabelH19.AutoSize = true;
            this.GenderlabelH19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH19.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH19.Location = new System.Drawing.Point(305, 273);
            this.GenderlabelH19.Name = "GenderlabelH19";
            this.GenderlabelH19.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH19.TabIndex = 137;
            this.GenderlabelH19.Text = "Gender";
            // 
            // NametextBoxH19
            // 
            this.NametextBoxH19.Location = new System.Drawing.Point(413, 121);
            this.NametextBoxH19.Name = "NametextBoxH19";
            this.NametextBoxH19.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH19.TabIndex = 136;
            // 
            // NamelabelH19
            // 
            this.NamelabelH19.AutoSize = true;
            this.NamelabelH19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH19.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH19.Location = new System.Drawing.Point(305, 110);
            this.NamelabelH19.Name = "NamelabelH19";
            this.NamelabelH19.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH19.TabIndex = 135;
            this.NamelabelH19.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 134;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHSUm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1251, 699);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH19);
            this.Controls.Add(this.AddresstextBoxH19);
            this.Controls.Add(this.AddresslabelH19);
            this.Controls.Add(this.TicketstextBoxH19);
            this.Controls.Add(this.TicketslabelH19);
            this.Controls.Add(this.NotextBoxH19);
            this.Controls.Add(this.NolabelH19);
            this.Controls.Add(this.EmailtextBoxH19);
            this.Controls.Add(this.EmaillabelH19);
            this.Controls.Add(this.GendertextBoxH19);
            this.Controls.Add(this.GenderlabelH19);
            this.Controls.Add(this.NametextBoxH19);
            this.Controls.Add(this.NamelabelH19);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHSUm1";
            this.Text = "BHSUm1";
            this.Load += new System.EventHandler(this.BHSUm1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH19;
        private System.Windows.Forms.TextBox AddresstextBoxH19;
        private System.Windows.Forms.Label AddresslabelH19;
        private System.Windows.Forms.TextBox TicketstextBoxH19;
        private System.Windows.Forms.Label TicketslabelH19;
        private System.Windows.Forms.TextBox NotextBoxH19;
        private System.Windows.Forms.Label NolabelH19;
        private System.Windows.Forms.TextBox EmailtextBoxH19;
        private System.Windows.Forms.Label EmaillabelH19;
        private System.Windows.Forms.TextBox GendertextBoxH19;
        private System.Windows.Forms.Label GenderlabelH19;
        private System.Windows.Forms.TextBox NametextBoxH19;
        private System.Windows.Forms.Label NamelabelH19;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}