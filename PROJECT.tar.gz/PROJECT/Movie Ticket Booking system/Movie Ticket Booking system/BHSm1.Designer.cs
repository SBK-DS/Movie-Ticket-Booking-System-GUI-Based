﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHSm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHSm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH16 = new System.Windows.Forms.Button();
            this.AddresstextBoxH16 = new System.Windows.Forms.TextBox();
            this.AddresslabelH16 = new System.Windows.Forms.Label();
            this.TicketstextBoxH16 = new System.Windows.Forms.TextBox();
            this.TicketslabelH16 = new System.Windows.Forms.Label();
            this.NotextBoxH16 = new System.Windows.Forms.TextBox();
            this.NolabelH16 = new System.Windows.Forms.Label();
            this.EmailtextBoxH16 = new System.Windows.Forms.TextBox();
            this.EmaillabelH16 = new System.Windows.Forms.Label();
            this.GendertextBoxH16 = new System.Windows.Forms.TextBox();
            this.GenderlabelH16 = new System.Windows.Forms.Label();
            this.NametextBoxH16 = new System.Windows.Forms.TextBox();
            this.NamelabelH16 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1196, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 133;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH16
            // 
            this.RegisterH16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH16.Location = new System.Drawing.Point(473, 523);
            this.RegisterH16.Name = "RegisterH16";
            this.RegisterH16.Size = new System.Drawing.Size(286, 83);
            this.RegisterH16.TabIndex = 132;
            this.RegisterH16.Text = "Register";
            this.RegisterH16.UseVisualStyleBackColor = true;
            this.RegisterH16.Click += new System.EventHandler(this.RegisterH16_Click);
            // 
            // AddresstextBoxH16
            // 
            this.AddresstextBoxH16.Location = new System.Drawing.Point(414, 394);
            this.AddresstextBoxH16.Multiline = true;
            this.AddresstextBoxH16.Name = "AddresstextBoxH16";
            this.AddresstextBoxH16.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH16.TabIndex = 131;
            // 
            // AddresslabelH16
            // 
            this.AddresslabelH16.AutoSize = true;
            this.AddresslabelH16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH16.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH16.Location = new System.Drawing.Point(306, 382);
            this.AddresslabelH16.Name = "AddresslabelH16";
            this.AddresslabelH16.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH16.TabIndex = 130;
            this.AddresslabelH16.Text = "Add";
            // 
            // TicketstextBoxH16
            // 
            this.TicketstextBoxH16.Location = new System.Drawing.Point(414, 338);
            this.TicketstextBoxH16.Name = "TicketstextBoxH16";
            this.TicketstextBoxH16.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH16.TabIndex = 129;
            // 
            // TicketslabelH16
            // 
            this.TicketslabelH16.AutoSize = true;
            this.TicketslabelH16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH16.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH16.Location = new System.Drawing.Point(306, 327);
            this.TicketslabelH16.Name = "TicketslabelH16";
            this.TicketslabelH16.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH16.TabIndex = 128;
            this.TicketslabelH16.Text = "Tickets";
            // 
            // NotextBoxH16
            // 
            this.NotextBoxH16.Location = new System.Drawing.Point(414, 176);
            this.NotextBoxH16.Name = "NotextBoxH16";
            this.NotextBoxH16.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH16.TabIndex = 127;
            // 
            // NolabelH16
            // 
            this.NolabelH16.AutoSize = true;
            this.NolabelH16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH16.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH16.Location = new System.Drawing.Point(306, 165);
            this.NolabelH16.Name = "NolabelH16";
            this.NolabelH16.Size = new System.Drawing.Size(49, 31);
            this.NolabelH16.TabIndex = 126;
            this.NolabelH16.Text = "No";
            // 
            // EmailtextBoxH16
            // 
            this.EmailtextBoxH16.Location = new System.Drawing.Point(414, 232);
            this.EmailtextBoxH16.Name = "EmailtextBoxH16";
            this.EmailtextBoxH16.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH16.TabIndex = 125;
            // 
            // EmaillabelH16
            // 
            this.EmaillabelH16.AutoSize = true;
            this.EmaillabelH16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH16.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH16.Location = new System.Drawing.Point(306, 221);
            this.EmaillabelH16.Name = "EmaillabelH16";
            this.EmaillabelH16.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH16.TabIndex = 124;
            this.EmaillabelH16.Text = "Email";
            // 
            // GendertextBoxH16
            // 
            this.GendertextBoxH16.Location = new System.Drawing.Point(414, 284);
            this.GendertextBoxH16.Name = "GendertextBoxH16";
            this.GendertextBoxH16.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH16.TabIndex = 123;
            // 
            // GenderlabelH16
            // 
            this.GenderlabelH16.AutoSize = true;
            this.GenderlabelH16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH16.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH16.Location = new System.Drawing.Point(306, 273);
            this.GenderlabelH16.Name = "GenderlabelH16";
            this.GenderlabelH16.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH16.TabIndex = 122;
            this.GenderlabelH16.Text = "Gender";
            // 
            // NametextBoxH16
            // 
            this.NametextBoxH16.Location = new System.Drawing.Point(414, 121);
            this.NametextBoxH16.Name = "NametextBoxH16";
            this.NametextBoxH16.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH16.TabIndex = 121;
            // 
            // NamelabelH16
            // 
            this.NamelabelH16.AutoSize = true;
            this.NamelabelH16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH16.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH16.Location = new System.Drawing.Point(306, 110);
            this.NamelabelH16.Name = "NamelabelH16";
            this.NamelabelH16.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH16.TabIndex = 120;
            this.NamelabelH16.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(5, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 119;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHSm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1252, 698);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH16);
            this.Controls.Add(this.AddresstextBoxH16);
            this.Controls.Add(this.AddresslabelH16);
            this.Controls.Add(this.TicketstextBoxH16);
            this.Controls.Add(this.TicketslabelH16);
            this.Controls.Add(this.NotextBoxH16);
            this.Controls.Add(this.NolabelH16);
            this.Controls.Add(this.EmailtextBoxH16);
            this.Controls.Add(this.EmaillabelH16);
            this.Controls.Add(this.GendertextBoxH16);
            this.Controls.Add(this.GenderlabelH16);
            this.Controls.Add(this.NametextBoxH16);
            this.Controls.Add(this.NamelabelH16);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHSm1";
            this.Text = "BHSm1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH16;
        private System.Windows.Forms.TextBox AddresstextBoxH16;
        private System.Windows.Forms.Label AddresslabelH16;
        private System.Windows.Forms.TextBox TicketstextBoxH16;
        private System.Windows.Forms.Label TicketslabelH16;
        private System.Windows.Forms.TextBox NotextBoxH16;
        private System.Windows.Forms.Label NolabelH16;
        private System.Windows.Forms.TextBox EmailtextBoxH16;
        private System.Windows.Forms.Label EmaillabelH16;
        private System.Windows.Forms.TextBox GendertextBoxH16;
        private System.Windows.Forms.Label GenderlabelH16;
        private System.Windows.Forms.TextBox NametextBoxH16;
        private System.Windows.Forms.Label NamelabelH16;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}