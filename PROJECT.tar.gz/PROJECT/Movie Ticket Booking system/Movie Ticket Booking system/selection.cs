﻿using System;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class selection : Form
    {
        public selection()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking B = new Booking();
            B.ShowDialog();
        }

        private void selection_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            introduction I = new introduction();
            I.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Services S = new Services();
            S.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Management M = new Management();
            M.ShowDialog();
        }
    }
}
