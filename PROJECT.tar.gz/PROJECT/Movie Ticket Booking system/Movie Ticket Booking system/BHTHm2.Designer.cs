﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHTHm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHTHm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH11 = new System.Windows.Forms.Button();
            this.AddresstextBoxH11 = new System.Windows.Forms.TextBox();
            this.AddresslabelH11 = new System.Windows.Forms.Label();
            this.TicketstextBoxH11 = new System.Windows.Forms.TextBox();
            this.TicketslabelH11 = new System.Windows.Forms.Label();
            this.NotextBoxH11 = new System.Windows.Forms.TextBox();
            this.NolabelH11 = new System.Windows.Forms.Label();
            this.EmailtextBoxH11 = new System.Windows.Forms.TextBox();
            this.EmaillabelH1 = new System.Windows.Forms.Label();
            this.GendertextBoxH11 = new System.Windows.Forms.TextBox();
            this.GenderlabelH11 = new System.Windows.Forms.Label();
            this.NametextBoxH11 = new System.Windows.Forms.TextBox();
            this.NamelabelH11 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1203, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 118;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH11
            // 
            this.RegisterH11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH11.Location = new System.Drawing.Point(480, 523);
            this.RegisterH11.Name = "RegisterH11";
            this.RegisterH11.Size = new System.Drawing.Size(286, 83);
            this.RegisterH11.TabIndex = 117;
            this.RegisterH11.Text = "Register";
            this.RegisterH11.UseVisualStyleBackColor = true;
            this.RegisterH11.Click += new System.EventHandler(this.RegisterH11_Click);
            // 
            // AddresstextBoxH11
            // 
            this.AddresstextBoxH11.Location = new System.Drawing.Point(421, 394);
            this.AddresstextBoxH11.Multiline = true;
            this.AddresstextBoxH11.Name = "AddresstextBoxH11";
            this.AddresstextBoxH11.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH11.TabIndex = 116;
            // 
            // AddresslabelH11
            // 
            this.AddresslabelH11.AutoSize = true;
            this.AddresslabelH11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH11.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH11.Location = new System.Drawing.Point(313, 382);
            this.AddresslabelH11.Name = "AddresslabelH11";
            this.AddresslabelH11.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH11.TabIndex = 115;
            this.AddresslabelH11.Text = "Add";
            // 
            // TicketstextBoxH11
            // 
            this.TicketstextBoxH11.Location = new System.Drawing.Point(421, 338);
            this.TicketstextBoxH11.Name = "TicketstextBoxH11";
            this.TicketstextBoxH11.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH11.TabIndex = 114;
            // 
            // TicketslabelH11
            // 
            this.TicketslabelH11.AutoSize = true;
            this.TicketslabelH11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH11.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH11.Location = new System.Drawing.Point(313, 327);
            this.TicketslabelH11.Name = "TicketslabelH11";
            this.TicketslabelH11.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH11.TabIndex = 113;
            this.TicketslabelH11.Text = "Tickets";
            // 
            // NotextBoxH11
            // 
            this.NotextBoxH11.Location = new System.Drawing.Point(421, 176);
            this.NotextBoxH11.Name = "NotextBoxH11";
            this.NotextBoxH11.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH11.TabIndex = 112;
            // 
            // NolabelH11
            // 
            this.NolabelH11.AutoSize = true;
            this.NolabelH11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH11.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH11.Location = new System.Drawing.Point(313, 165);
            this.NolabelH11.Name = "NolabelH11";
            this.NolabelH11.Size = new System.Drawing.Size(49, 31);
            this.NolabelH11.TabIndex = 111;
            this.NolabelH11.Text = "No";
            // 
            // EmailtextBoxH11
            // 
            this.EmailtextBoxH11.Location = new System.Drawing.Point(421, 232);
            this.EmailtextBoxH11.Name = "EmailtextBoxH11";
            this.EmailtextBoxH11.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH11.TabIndex = 110;
            // 
            // EmaillabelH1
            // 
            this.EmaillabelH1.AutoSize = true;
            this.EmaillabelH1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH1.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH1.Location = new System.Drawing.Point(313, 221);
            this.EmaillabelH1.Name = "EmaillabelH1";
            this.EmaillabelH1.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH1.TabIndex = 109;
            this.EmaillabelH1.Text = "Email";
            // 
            // GendertextBoxH11
            // 
            this.GendertextBoxH11.Location = new System.Drawing.Point(421, 284);
            this.GendertextBoxH11.Name = "GendertextBoxH11";
            this.GendertextBoxH11.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH11.TabIndex = 108;
            // 
            // GenderlabelH11
            // 
            this.GenderlabelH11.AutoSize = true;
            this.GenderlabelH11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH11.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH11.Location = new System.Drawing.Point(313, 273);
            this.GenderlabelH11.Name = "GenderlabelH11";
            this.GenderlabelH11.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH11.TabIndex = 107;
            this.GenderlabelH11.Text = "Gender";
            // 
            // NametextBoxH11
            // 
            this.NametextBoxH11.Location = new System.Drawing.Point(421, 121);
            this.NametextBoxH11.Name = "NametextBoxH11";
            this.NametextBoxH11.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH11.TabIndex = 106;
            // 
            // NamelabelH11
            // 
            this.NamelabelH11.AutoSize = true;
            this.NamelabelH11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH11.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH11.Location = new System.Drawing.Point(313, 110);
            this.NamelabelH11.Name = "NamelabelH11";
            this.NamelabelH11.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH11.TabIndex = 105;
            this.NamelabelH11.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 104;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHTHm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1259, 703);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH11);
            this.Controls.Add(this.AddresstextBoxH11);
            this.Controls.Add(this.AddresslabelH11);
            this.Controls.Add(this.TicketstextBoxH11);
            this.Controls.Add(this.TicketslabelH11);
            this.Controls.Add(this.NotextBoxH11);
            this.Controls.Add(this.NolabelH11);
            this.Controls.Add(this.EmailtextBoxH11);
            this.Controls.Add(this.EmaillabelH1);
            this.Controls.Add(this.GendertextBoxH11);
            this.Controls.Add(this.GenderlabelH11);
            this.Controls.Add(this.NametextBoxH11);
            this.Controls.Add(this.NamelabelH11);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHTHm2";
            this.Text = "BHTHm2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH11;
        private System.Windows.Forms.TextBox AddresstextBoxH11;
        private System.Windows.Forms.Label AddresslabelH11;
        private System.Windows.Forms.TextBox TicketstextBoxH11;
        private System.Windows.Forms.Label TicketslabelH11;
        private System.Windows.Forms.TextBox NotextBoxH11;
        private System.Windows.Forms.Label NolabelH11;
        private System.Windows.Forms.TextBox EmailtextBoxH11;
        private System.Windows.Forms.Label EmaillabelH1;
        private System.Windows.Forms.TextBox GendertextBoxH11;
        private System.Windows.Forms.Label GenderlabelH11;
        private System.Windows.Forms.TextBox NametextBoxH11;
        private System.Windows.Forms.Label NamelabelH11;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}