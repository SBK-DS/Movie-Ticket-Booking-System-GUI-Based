﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBSUm2 : Form
    {
        public ShowReservation_BBSUm2()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBSUm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBSUm2.Book_ID.ToString();
            textBox2.Text = BBSUm2.name_copy;
            textBox3.Text = BBSUm2.No_copy;
            textBox4.Text = BBSUm2.email_copy;
            textBox5.Text = BBSUm2.gender_copy;
            textBox6.Text = BBSUm2.Tickets_copy.ToString();
            textBox7.Text = BBSUm2.Day_copy;
            textBox8.Text = BBSUm2.Movie_copy;
            textBox9.Text = BBSUm2.Amount_copy.ToString();
            textBox10.Text = BBSUm2.timing_copy;
            textBox11.Text = BBSUm2.address_copy;
            textBox12.Text = BBSUm2.DT_copy;
        }
    }
}
