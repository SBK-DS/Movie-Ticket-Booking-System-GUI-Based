﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Movie_Ticket_Booking_system
{
    public partial class Cancel_Form : Form
    {
        public static int get_key;
        public Cancel_Form()
        {
            InitializeComponent();
        }

        private void Cancel_Form_Load(object sender, EventArgs e)
        {
            textBox1.Text = Cancel_Registeration.Book_ID.ToString();
            textBox2.Text = Cancel_Registeration.name_copy;
            textBox3.Text = Cancel_Registeration.No_copy;
            textBox4.Text = Cancel_Registeration.email_copy;
            textBox5.Text = Cancel_Registeration.gender_copy;
            textBox6.Text = Cancel_Registeration.Tickets_copy.ToString();
            textBox7.Text = Cancel_Registeration.Day_copy;
            textBox8.Text = Cancel_Registeration.Movie_copy;
            textBox9.Text = Cancel_Registeration.Amount_copy.ToString();
            textBox10.Text = Cancel_Registeration.timing_copy;
            textBox11.Text = Cancel_Registeration.address_copy;
            textBox12.Text = Cancel_Registeration.DT_copy;
            get_key = Cancel_Registeration.key;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-UAV1AAR\SQLEXPRESS;Initial Catalog=OOPDATABASE;Integrated Security=True");

            if(get_key == 1)
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM HollywoodRegisterations WHERE ID = @id", con);
                cmd.Parameters.AddWithValue("@id", textBox1.Text);
                SqlDataReader sdr = cmd.ExecuteReader();
                MessageBox.Show("Your registration has been canceled :(");
                con.Close();
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM BollywoodRegisterations WHERE ID = @id", con);
                cmd.Parameters.AddWithValue("@id", textBox1.Text);
                SqlDataReader sdr = cmd.ExecuteReader();
                MessageBox.Show("Your registration has been canceled :(");
                con.Close();
            }



        }
    }
}
