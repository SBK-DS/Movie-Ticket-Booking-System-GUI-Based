﻿using System;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBMm1 : Form
    {
        public ShowReservation_BBMm1()
        {
            InitializeComponent();
        }

        private void ShowReservation_Load(object sender, EventArgs e)
        {

            textBox1.Text = BBMm1.Book_ID.ToString();
            textBox2.Text = BBMm1.name_copy;
            textBox3.Text = BBMm1.No_copy;
            textBox4.Text = BBMm1.email_copy;
            textBox5.Text = BBMm1.gender_copy;
            textBox6.Text = BBMm1.Tickets_copy.ToString();
            textBox7.Text = BBMm1.Day_copy;
            textBox8.Text = BBMm1.Movie_copy;
            textBox9.Text = BBMm1.Amount_copy.ToString();
            textBox10.Text = BBMm1.timing_copy;
            textBox11.Text = BBMm1.address_copy;
            textBox12.Text = BBMm1.DT_copy;




        }
    }
}
