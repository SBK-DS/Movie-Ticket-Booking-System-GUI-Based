﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBSm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBSm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register17 = new System.Windows.Forms.Button();
            this.AddresstextBox17 = new System.Windows.Forms.TextBox();
            this.Addresslabel17 = new System.Windows.Forms.Label();
            this.TicketstextBox17 = new System.Windows.Forms.TextBox();
            this.Ticketslabel17 = new System.Windows.Forms.Label();
            this.NotextBox17 = new System.Windows.Forms.TextBox();
            this.Nolabel17 = new System.Windows.Forms.Label();
            this.EmailtextBox17 = new System.Windows.Forms.TextBox();
            this.Emaillabel17 = new System.Windows.Forms.Label();
            this.GendertextBox17 = new System.Windows.Forms.TextBox();
            this.Genderlabel17 = new System.Windows.Forms.Label();
            this.NametextBox17 = new System.Windows.Forms.TextBox();
            this.Namelabel17 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1203, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 205;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register17
            // 
            this.Register17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register17.Location = new System.Drawing.Point(482, 523);
            this.Register17.Name = "Register17";
            this.Register17.Size = new System.Drawing.Size(286, 83);
            this.Register17.TabIndex = 204;
            this.Register17.Text = "Register";
            this.Register17.UseVisualStyleBackColor = true;
            this.Register17.Click += new System.EventHandler(this.Register17_Click);
            // 
            // AddresstextBox17
            // 
            this.AddresstextBox17.Location = new System.Drawing.Point(423, 394);
            this.AddresstextBox17.Multiline = true;
            this.AddresstextBox17.Name = "AddresstextBox17";
            this.AddresstextBox17.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox17.TabIndex = 203;
            // 
            // Addresslabel17
            // 
            this.Addresslabel17.AutoSize = true;
            this.Addresslabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel17.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel17.Location = new System.Drawing.Point(315, 382);
            this.Addresslabel17.Name = "Addresslabel17";
            this.Addresslabel17.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel17.TabIndex = 202;
            this.Addresslabel17.Text = "Add";
            // 
            // TicketstextBox17
            // 
            this.TicketstextBox17.Location = new System.Drawing.Point(423, 338);
            this.TicketstextBox17.Name = "TicketstextBox17";
            this.TicketstextBox17.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox17.TabIndex = 201;
            // 
            // Ticketslabel17
            // 
            this.Ticketslabel17.AutoSize = true;
            this.Ticketslabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel17.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel17.Location = new System.Drawing.Point(315, 327);
            this.Ticketslabel17.Name = "Ticketslabel17";
            this.Ticketslabel17.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel17.TabIndex = 200;
            this.Ticketslabel17.Text = "Tickets";
            // 
            // NotextBox17
            // 
            this.NotextBox17.Location = new System.Drawing.Point(423, 176);
            this.NotextBox17.Name = "NotextBox17";
            this.NotextBox17.Size = new System.Drawing.Size(539, 20);
            this.NotextBox17.TabIndex = 199;
            // 
            // Nolabel17
            // 
            this.Nolabel17.AutoSize = true;
            this.Nolabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel17.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel17.Location = new System.Drawing.Point(315, 165);
            this.Nolabel17.Name = "Nolabel17";
            this.Nolabel17.Size = new System.Drawing.Size(49, 31);
            this.Nolabel17.TabIndex = 198;
            this.Nolabel17.Text = "No";
            // 
            // EmailtextBox17
            // 
            this.EmailtextBox17.Location = new System.Drawing.Point(423, 232);
            this.EmailtextBox17.Name = "EmailtextBox17";
            this.EmailtextBox17.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox17.TabIndex = 197;
            // 
            // Emaillabel17
            // 
            this.Emaillabel17.AutoSize = true;
            this.Emaillabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel17.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel17.Location = new System.Drawing.Point(315, 221);
            this.Emaillabel17.Name = "Emaillabel17";
            this.Emaillabel17.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel17.TabIndex = 196;
            this.Emaillabel17.Text = "Email";
            // 
            // GendertextBox17
            // 
            this.GendertextBox17.Location = new System.Drawing.Point(423, 284);
            this.GendertextBox17.Name = "GendertextBox17";
            this.GendertextBox17.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox17.TabIndex = 195;
            // 
            // Genderlabel17
            // 
            this.Genderlabel17.AutoSize = true;
            this.Genderlabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel17.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel17.Location = new System.Drawing.Point(315, 273);
            this.Genderlabel17.Name = "Genderlabel17";
            this.Genderlabel17.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel17.TabIndex = 194;
            this.Genderlabel17.Text = "Gender";
            // 
            // NametextBox17
            // 
            this.NametextBox17.Location = new System.Drawing.Point(423, 121);
            this.NametextBox17.Name = "NametextBox17";
            this.NametextBox17.Size = new System.Drawing.Size(539, 20);
            this.NametextBox17.TabIndex = 193;
            // 
            // Namelabel17
            // 
            this.Namelabel17.AutoSize = true;
            this.Namelabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel17.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel17.Location = new System.Drawing.Point(315, 109);
            this.Namelabel17.Name = "Namelabel17";
            this.Namelabel17.Size = new System.Drawing.Size(86, 31);
            this.Namelabel17.TabIndex = 192;
            this.Namelabel17.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 191;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBSm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1259, 705);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register17);
            this.Controls.Add(this.AddresstextBox17);
            this.Controls.Add(this.Addresslabel17);
            this.Controls.Add(this.TicketstextBox17);
            this.Controls.Add(this.Ticketslabel17);
            this.Controls.Add(this.NotextBox17);
            this.Controls.Add(this.Nolabel17);
            this.Controls.Add(this.EmailtextBox17);
            this.Controls.Add(this.Emaillabel17);
            this.Controls.Add(this.GendertextBox17);
            this.Controls.Add(this.Genderlabel17);
            this.Controls.Add(this.NametextBox17);
            this.Controls.Add(this.Namelabel17);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBSm3";
            this.Text = "BBSm3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register17;
        private System.Windows.Forms.TextBox AddresstextBox17;
        private System.Windows.Forms.Label Addresslabel17;
        private System.Windows.Forms.TextBox TicketstextBox17;
        private System.Windows.Forms.Label Ticketslabel17;
        private System.Windows.Forms.TextBox NotextBox17;
        private System.Windows.Forms.Label Nolabel17;
        private System.Windows.Forms.TextBox EmailtextBox17;
        private System.Windows.Forms.Label Emaillabel17;
        private System.Windows.Forms.TextBox GendertextBox17;
        private System.Windows.Forms.Label Genderlabel17;
        private System.Windows.Forms.TextBox NametextBox17;
        private System.Windows.Forms.Label Namelabel17;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}