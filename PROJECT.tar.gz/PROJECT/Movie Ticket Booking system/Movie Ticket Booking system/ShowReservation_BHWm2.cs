﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHWm2 : Form
    {
        public ShowReservation_BHWm2()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHWm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHWm2.Book_ID.ToString();
            textBox2.Text = BHWm2.name_copy;
            textBox3.Text = BHWm2.No_copy;
            textBox4.Text = BHWm2.email_copy;
            textBox5.Text = BHWm2.gender_copy;
            textBox6.Text = BHWm2.Tickets_copy.ToString();
            textBox7.Text = BHWm2.Day_copy;
            textBox8.Text = BHWm2.Movie_copy;
            textBox9.Text = BHWm2.Amount_copy.ToString();
            textBox10.Text = BHWm2.timing_copy;
            textBox11.Text = BHWm2.address_copy;
            textBox12.Text = BHWm2.DT_copy;
        }
    }
}
