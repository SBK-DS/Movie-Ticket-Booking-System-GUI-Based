﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBSm3 : Form
    {
        public ShowReservation_BBSm3()
        {
            InitializeComponent();
        }

        private void ShowReservatio_BBSm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBSm3.Book_ID.ToString();
            textBox2.Text = BBSm3.name_copy;
            textBox3.Text = BBSm3.No_copy;
            textBox4.Text = BBSm3.email_copy;
            textBox5.Text = BBSm3.gender_copy;
            textBox6.Text = BBSm3.Tickets_copy.ToString();
            textBox7.Text = BBSm3.Day_copy;
            textBox8.Text = BBSm3.Movie_copy;
            textBox9.Text = BBSm3.Amount_copy.ToString();
            textBox10.Text = BBSm3.timing_copy;
            textBox11.Text = BBSm3.address_copy;
            textBox12.Text = BBSm3.DT_copy;
        }
    }
}
