﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHSm1 : Form
    {
        public ShowReservation_BHSm1()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHSm1_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHSm1.Book_ID.ToString();
            textBox2.Text = BHSm1.name_copy;
            textBox3.Text = BHSm1.No_copy;
            textBox4.Text = BHSm1.email_copy;
            textBox5.Text = BHSm1.gender_copy;
            textBox6.Text = BHSm1.Tickets_copy.ToString();
            textBox7.Text = BHSm1.Day_copy;
            textBox8.Text = BHSm1.Movie_copy;
            textBox9.Text = BHSm1.Amount_copy.ToString();
            textBox10.Text = BHSm1.timing_copy;
            textBox11.Text = BHSm1.address_copy;
            textBox12.Text = BHSm1.DT_copy;
        }
    }
}
