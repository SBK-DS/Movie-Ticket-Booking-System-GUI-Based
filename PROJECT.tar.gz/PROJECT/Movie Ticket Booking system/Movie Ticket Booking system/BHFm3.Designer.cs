﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHFm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHFm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH15 = new System.Windows.Forms.Button();
            this.AddresstextBoxH15 = new System.Windows.Forms.TextBox();
            this.AddresslabelH15 = new System.Windows.Forms.Label();
            this.TicketstextBoxH15 = new System.Windows.Forms.TextBox();
            this.TicketslabelH15 = new System.Windows.Forms.Label();
            this.NotextBoxH15 = new System.Windows.Forms.TextBox();
            this.NolabelH15 = new System.Windows.Forms.Label();
            this.EmailtextBoxH15 = new System.Windows.Forms.TextBox();
            this.EmaillabelH15 = new System.Windows.Forms.Label();
            this.GendertextBoxH15 = new System.Windows.Forms.TextBox();
            this.GenderlabelH15 = new System.Windows.Forms.Label();
            this.NametextBoxH15 = new System.Windows.Forms.TextBox();
            this.NamelabelH15 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1199, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 133;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH15
            // 
            this.RegisterH15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH15.Location = new System.Drawing.Point(476, 523);
            this.RegisterH15.Name = "RegisterH15";
            this.RegisterH15.Size = new System.Drawing.Size(286, 83);
            this.RegisterH15.TabIndex = 132;
            this.RegisterH15.Text = "Register";
            this.RegisterH15.UseVisualStyleBackColor = true;
            this.RegisterH15.Click += new System.EventHandler(this.RegisterH15_Click);
            // 
            // AddresstextBoxH15
            // 
            this.AddresstextBoxH15.Location = new System.Drawing.Point(417, 394);
            this.AddresstextBoxH15.Multiline = true;
            this.AddresstextBoxH15.Name = "AddresstextBoxH15";
            this.AddresstextBoxH15.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH15.TabIndex = 131;
            // 
            // AddresslabelH15
            // 
            this.AddresslabelH15.AutoSize = true;
            this.AddresslabelH15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH15.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH15.Location = new System.Drawing.Point(309, 382);
            this.AddresslabelH15.Name = "AddresslabelH15";
            this.AddresslabelH15.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH15.TabIndex = 130;
            this.AddresslabelH15.Text = "Add";
            // 
            // TicketstextBoxH15
            // 
            this.TicketstextBoxH15.Location = new System.Drawing.Point(417, 338);
            this.TicketstextBoxH15.Name = "TicketstextBoxH15";
            this.TicketstextBoxH15.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH15.TabIndex = 129;
            // 
            // TicketslabelH15
            // 
            this.TicketslabelH15.AutoSize = true;
            this.TicketslabelH15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH15.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH15.Location = new System.Drawing.Point(309, 327);
            this.TicketslabelH15.Name = "TicketslabelH15";
            this.TicketslabelH15.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH15.TabIndex = 128;
            this.TicketslabelH15.Text = "Tickets";
            // 
            // NotextBoxH15
            // 
            this.NotextBoxH15.Location = new System.Drawing.Point(417, 176);
            this.NotextBoxH15.Name = "NotextBoxH15";
            this.NotextBoxH15.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH15.TabIndex = 127;
            // 
            // NolabelH15
            // 
            this.NolabelH15.AutoSize = true;
            this.NolabelH15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH15.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH15.Location = new System.Drawing.Point(309, 165);
            this.NolabelH15.Name = "NolabelH15";
            this.NolabelH15.Size = new System.Drawing.Size(49, 31);
            this.NolabelH15.TabIndex = 126;
            this.NolabelH15.Text = "No";
            // 
            // EmailtextBoxH15
            // 
            this.EmailtextBoxH15.Location = new System.Drawing.Point(417, 232);
            this.EmailtextBoxH15.Name = "EmailtextBoxH15";
            this.EmailtextBoxH15.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH15.TabIndex = 125;
            // 
            // EmaillabelH15
            // 
            this.EmaillabelH15.AutoSize = true;
            this.EmaillabelH15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH15.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH15.Location = new System.Drawing.Point(309, 221);
            this.EmaillabelH15.Name = "EmaillabelH15";
            this.EmaillabelH15.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH15.TabIndex = 124;
            this.EmaillabelH15.Text = "Email";
            // 
            // GendertextBoxH15
            // 
            this.GendertextBoxH15.Location = new System.Drawing.Point(417, 284);
            this.GendertextBoxH15.Name = "GendertextBoxH15";
            this.GendertextBoxH15.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH15.TabIndex = 123;
            // 
            // GenderlabelH15
            // 
            this.GenderlabelH15.AutoSize = true;
            this.GenderlabelH15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH15.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH15.Location = new System.Drawing.Point(309, 273);
            this.GenderlabelH15.Name = "GenderlabelH15";
            this.GenderlabelH15.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH15.TabIndex = 122;
            this.GenderlabelH15.Text = "Gender";
            // 
            // NametextBoxH15
            // 
            this.NametextBoxH15.Location = new System.Drawing.Point(417, 121);
            this.NametextBoxH15.Name = "NametextBoxH15";
            this.NametextBoxH15.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH15.TabIndex = 121;
            // 
            // NamelabelH15
            // 
            this.NamelabelH15.AutoSize = true;
            this.NamelabelH15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH15.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH15.Location = new System.Drawing.Point(309, 110);
            this.NamelabelH15.Name = "NamelabelH15";
            this.NamelabelH15.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH15.TabIndex = 120;
            this.NamelabelH15.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(8, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 119;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHFm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1255, 699);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH15);
            this.Controls.Add(this.AddresstextBoxH15);
            this.Controls.Add(this.AddresslabelH15);
            this.Controls.Add(this.TicketstextBoxH15);
            this.Controls.Add(this.TicketslabelH15);
            this.Controls.Add(this.NotextBoxH15);
            this.Controls.Add(this.NolabelH15);
            this.Controls.Add(this.EmailtextBoxH15);
            this.Controls.Add(this.EmaillabelH15);
            this.Controls.Add(this.GendertextBoxH15);
            this.Controls.Add(this.GenderlabelH15);
            this.Controls.Add(this.NametextBoxH15);
            this.Controls.Add(this.NamelabelH15);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHFm3";
            this.Text = "BHFm3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH15;
        private System.Windows.Forms.TextBox AddresstextBoxH15;
        private System.Windows.Forms.Label AddresslabelH15;
        private System.Windows.Forms.TextBox TicketstextBoxH15;
        private System.Windows.Forms.Label TicketslabelH15;
        private System.Windows.Forms.TextBox NotextBoxH15;
        private System.Windows.Forms.Label NolabelH15;
        private System.Windows.Forms.TextBox EmailtextBoxH15;
        private System.Windows.Forms.Label EmaillabelH15;
        private System.Windows.Forms.TextBox GendertextBoxH15;
        private System.Windows.Forms.Label GenderlabelH15;
        private System.Windows.Forms.TextBox NametextBoxH15;
        private System.Windows.Forms.Label NamelabelH15;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}