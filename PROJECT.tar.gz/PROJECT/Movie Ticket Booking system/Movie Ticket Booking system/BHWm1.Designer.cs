﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHWm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHWm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH7 = new System.Windows.Forms.Button();
            this.AddresstextBoxH7 = new System.Windows.Forms.TextBox();
            this.AddresslabelH7 = new System.Windows.Forms.Label();
            this.TicketstextBoxH7 = new System.Windows.Forms.TextBox();
            this.TicketslabelH7 = new System.Windows.Forms.Label();
            this.NotextBoxH7 = new System.Windows.Forms.TextBox();
            this.NolabelH7 = new System.Windows.Forms.Label();
            this.EmailtextBoxH7 = new System.Windows.Forms.TextBox();
            this.EmaillabelH7 = new System.Windows.Forms.Label();
            this.GendertextBoxH7 = new System.Windows.Forms.TextBox();
            this.GenderlabelH7 = new System.Windows.Forms.Label();
            this.NametextBoxH7 = new System.Windows.Forms.TextBox();
            this.NamelabelH7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1204, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 103;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH7
            // 
            this.RegisterH7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH7.Location = new System.Drawing.Point(481, 523);
            this.RegisterH7.Name = "RegisterH7";
            this.RegisterH7.Size = new System.Drawing.Size(286, 83);
            this.RegisterH7.TabIndex = 102;
            this.RegisterH7.Text = "Register";
            this.RegisterH7.UseVisualStyleBackColor = true;
            this.RegisterH7.Click += new System.EventHandler(this.RegisterH7_Click);
            // 
            // AddresstextBoxH7
            // 
            this.AddresstextBoxH7.Location = new System.Drawing.Point(422, 394);
            this.AddresstextBoxH7.Multiline = true;
            this.AddresstextBoxH7.Name = "AddresstextBoxH7";
            this.AddresstextBoxH7.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH7.TabIndex = 101;
            // 
            // AddresslabelH7
            // 
            this.AddresslabelH7.AutoSize = true;
            this.AddresslabelH7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH7.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH7.Location = new System.Drawing.Point(314, 382);
            this.AddresslabelH7.Name = "AddresslabelH7";
            this.AddresslabelH7.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH7.TabIndex = 100;
            this.AddresslabelH7.Text = "Add";
            // 
            // TicketstextBoxH7
            // 
            this.TicketstextBoxH7.Location = new System.Drawing.Point(422, 338);
            this.TicketstextBoxH7.Name = "TicketstextBoxH7";
            this.TicketstextBoxH7.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH7.TabIndex = 99;
            // 
            // TicketslabelH7
            // 
            this.TicketslabelH7.AutoSize = true;
            this.TicketslabelH7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH7.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH7.Location = new System.Drawing.Point(314, 327);
            this.TicketslabelH7.Name = "TicketslabelH7";
            this.TicketslabelH7.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH7.TabIndex = 98;
            this.TicketslabelH7.Text = "Tickets";
            // 
            // NotextBoxH7
            // 
            this.NotextBoxH7.Location = new System.Drawing.Point(422, 176);
            this.NotextBoxH7.Name = "NotextBoxH7";
            this.NotextBoxH7.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH7.TabIndex = 97;
            // 
            // NolabelH7
            // 
            this.NolabelH7.AutoSize = true;
            this.NolabelH7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH7.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH7.Location = new System.Drawing.Point(314, 165);
            this.NolabelH7.Name = "NolabelH7";
            this.NolabelH7.Size = new System.Drawing.Size(49, 31);
            this.NolabelH7.TabIndex = 96;
            this.NolabelH7.Text = "No";
            // 
            // EmailtextBoxH7
            // 
            this.EmailtextBoxH7.Location = new System.Drawing.Point(422, 232);
            this.EmailtextBoxH7.Name = "EmailtextBoxH7";
            this.EmailtextBoxH7.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH7.TabIndex = 95;
            // 
            // EmaillabelH7
            // 
            this.EmaillabelH7.AutoSize = true;
            this.EmaillabelH7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH7.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH7.Location = new System.Drawing.Point(314, 221);
            this.EmaillabelH7.Name = "EmaillabelH7";
            this.EmaillabelH7.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH7.TabIndex = 94;
            this.EmaillabelH7.Text = "Email";
            // 
            // GendertextBoxH7
            // 
            this.GendertextBoxH7.Location = new System.Drawing.Point(422, 284);
            this.GendertextBoxH7.Name = "GendertextBoxH7";
            this.GendertextBoxH7.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH7.TabIndex = 93;
            // 
            // GenderlabelH7
            // 
            this.GenderlabelH7.AutoSize = true;
            this.GenderlabelH7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH7.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH7.Location = new System.Drawing.Point(314, 273);
            this.GenderlabelH7.Name = "GenderlabelH7";
            this.GenderlabelH7.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH7.TabIndex = 92;
            this.GenderlabelH7.Text = "Gender";
            // 
            // NametextBoxH7
            // 
            this.NametextBoxH7.Location = new System.Drawing.Point(422, 121);
            this.NametextBoxH7.Name = "NametextBoxH7";
            this.NametextBoxH7.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH7.TabIndex = 91;
            // 
            // NamelabelH7
            // 
            this.NamelabelH7.AutoSize = true;
            this.NamelabelH7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH7.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH7.Location = new System.Drawing.Point(314, 110);
            this.NamelabelH7.Name = "NamelabelH7";
            this.NamelabelH7.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH7.TabIndex = 90;
            this.NamelabelH7.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHWm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1260, 703);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH7);
            this.Controls.Add(this.AddresstextBoxH7);
            this.Controls.Add(this.AddresslabelH7);
            this.Controls.Add(this.TicketstextBoxH7);
            this.Controls.Add(this.TicketslabelH7);
            this.Controls.Add(this.NotextBoxH7);
            this.Controls.Add(this.NolabelH7);
            this.Controls.Add(this.EmailtextBoxH7);
            this.Controls.Add(this.EmaillabelH7);
            this.Controls.Add(this.GendertextBoxH7);
            this.Controls.Add(this.GenderlabelH7);
            this.Controls.Add(this.NametextBoxH7);
            this.Controls.Add(this.NamelabelH7);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHWm1";
            this.Text = "BHWm1";
            this.Load += new System.EventHandler(this.BHWm1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH7;
        private System.Windows.Forms.TextBox AddresstextBoxH7;
        private System.Windows.Forms.Label AddresslabelH7;
        private System.Windows.Forms.TextBox TicketstextBoxH7;
        private System.Windows.Forms.Label TicketslabelH7;
        private System.Windows.Forms.TextBox NotextBoxH7;
        private System.Windows.Forms.Label NolabelH7;
        private System.Windows.Forms.TextBox EmailtextBoxH7;
        private System.Windows.Forms.Label EmaillabelH7;
        private System.Windows.Forms.TextBox GendertextBoxH7;
        private System.Windows.Forms.Label GenderlabelH7;
        private System.Windows.Forms.TextBox NametextBoxH7;
        private System.Windows.Forms.Label NamelabelH7;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}