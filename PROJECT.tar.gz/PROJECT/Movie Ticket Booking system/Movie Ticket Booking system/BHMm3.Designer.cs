﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHMm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHMm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH3 = new System.Windows.Forms.Button();
            this.AddresstextBoxH3 = new System.Windows.Forms.TextBox();
            this.AddresslabelH3 = new System.Windows.Forms.Label();
            this.TicketstextBoxH3 = new System.Windows.Forms.TextBox();
            this.TicketslabelH3 = new System.Windows.Forms.Label();
            this.NotextBoxH3 = new System.Windows.Forms.TextBox();
            this.NolabelH3 = new System.Windows.Forms.Label();
            this.EmailtextBoxH3 = new System.Windows.Forms.TextBox();
            this.EmaillabelH3 = new System.Windows.Forms.Label();
            this.GendertextBoxH3 = new System.Windows.Forms.TextBox();
            this.GenderlabelH3 = new System.Windows.Forms.Label();
            this.NametextBoxH3 = new System.Windows.Forms.TextBox();
            this.NamelabelH3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1204, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 88;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH3
            // 
            this.RegisterH3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH3.Location = new System.Drawing.Point(481, 523);
            this.RegisterH3.Name = "RegisterH3";
            this.RegisterH3.Size = new System.Drawing.Size(286, 83);
            this.RegisterH3.TabIndex = 87;
            this.RegisterH3.Text = "Register";
            this.RegisterH3.UseVisualStyleBackColor = true;
            this.RegisterH3.Click += new System.EventHandler(this.RegisterH3_Click);
            // 
            // AddresstextBoxH3
            // 
            this.AddresstextBoxH3.Location = new System.Drawing.Point(422, 394);
            this.AddresstextBoxH3.Multiline = true;
            this.AddresstextBoxH3.Name = "AddresstextBoxH3";
            this.AddresstextBoxH3.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH3.TabIndex = 86;
            // 
            // AddresslabelH3
            // 
            this.AddresslabelH3.AutoSize = true;
            this.AddresslabelH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH3.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH3.Location = new System.Drawing.Point(314, 382);
            this.AddresslabelH3.Name = "AddresslabelH3";
            this.AddresslabelH3.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH3.TabIndex = 85;
            this.AddresslabelH3.Text = "Add";
            // 
            // TicketstextBoxH3
            // 
            this.TicketstextBoxH3.Location = new System.Drawing.Point(422, 338);
            this.TicketstextBoxH3.Name = "TicketstextBoxH3";
            this.TicketstextBoxH3.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH3.TabIndex = 84;
            // 
            // TicketslabelH3
            // 
            this.TicketslabelH3.AutoSize = true;
            this.TicketslabelH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH3.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH3.Location = new System.Drawing.Point(314, 327);
            this.TicketslabelH3.Name = "TicketslabelH3";
            this.TicketslabelH3.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH3.TabIndex = 83;
            this.TicketslabelH3.Text = "Tickets";
            // 
            // NotextBoxH3
            // 
            this.NotextBoxH3.Location = new System.Drawing.Point(422, 176);
            this.NotextBoxH3.Name = "NotextBoxH3";
            this.NotextBoxH3.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH3.TabIndex = 82;
            // 
            // NolabelH3
            // 
            this.NolabelH3.AutoSize = true;
            this.NolabelH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH3.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH3.Location = new System.Drawing.Point(314, 165);
            this.NolabelH3.Name = "NolabelH3";
            this.NolabelH3.Size = new System.Drawing.Size(49, 31);
            this.NolabelH3.TabIndex = 81;
            this.NolabelH3.Text = "No";
            // 
            // EmailtextBoxH3
            // 
            this.EmailtextBoxH3.Location = new System.Drawing.Point(422, 232);
            this.EmailtextBoxH3.Name = "EmailtextBoxH3";
            this.EmailtextBoxH3.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH3.TabIndex = 80;
            // 
            // EmaillabelH3
            // 
            this.EmaillabelH3.AutoSize = true;
            this.EmaillabelH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH3.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH3.Location = new System.Drawing.Point(314, 221);
            this.EmaillabelH3.Name = "EmaillabelH3";
            this.EmaillabelH3.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH3.TabIndex = 79;
            this.EmaillabelH3.Text = "Email";
            // 
            // GendertextBoxH3
            // 
            this.GendertextBoxH3.Location = new System.Drawing.Point(422, 284);
            this.GendertextBoxH3.Name = "GendertextBoxH3";
            this.GendertextBoxH3.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH3.TabIndex = 78;
            // 
            // GenderlabelH3
            // 
            this.GenderlabelH3.AutoSize = true;
            this.GenderlabelH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH3.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH3.Location = new System.Drawing.Point(314, 273);
            this.GenderlabelH3.Name = "GenderlabelH3";
            this.GenderlabelH3.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH3.TabIndex = 77;
            this.GenderlabelH3.Text = "Gender";
            // 
            // NametextBoxH3
            // 
            this.NametextBoxH3.Location = new System.Drawing.Point(422, 121);
            this.NametextBoxH3.Name = "NametextBoxH3";
            this.NametextBoxH3.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH3.TabIndex = 76;
            // 
            // NamelabelH3
            // 
            this.NamelabelH3.AutoSize = true;
            this.NamelabelH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH3.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH3.Location = new System.Drawing.Point(314, 110);
            this.NamelabelH3.Name = "NamelabelH3";
            this.NamelabelH3.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH3.TabIndex = 75;
            this.NamelabelH3.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 74;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHMm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1260, 705);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH3);
            this.Controls.Add(this.AddresstextBoxH3);
            this.Controls.Add(this.AddresslabelH3);
            this.Controls.Add(this.TicketstextBoxH3);
            this.Controls.Add(this.TicketslabelH3);
            this.Controls.Add(this.NotextBoxH3);
            this.Controls.Add(this.NolabelH3);
            this.Controls.Add(this.EmailtextBoxH3);
            this.Controls.Add(this.EmaillabelH3);
            this.Controls.Add(this.GendertextBoxH3);
            this.Controls.Add(this.GenderlabelH3);
            this.Controls.Add(this.NametextBoxH3);
            this.Controls.Add(this.NamelabelH3);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHMm3";
            this.Text = "HBMm3";
            this.Load += new System.EventHandler(this.BHMm3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH3;
        private System.Windows.Forms.TextBox AddresstextBoxH3;
        private System.Windows.Forms.Label AddresslabelH3;
        private System.Windows.Forms.TextBox TicketstextBoxH3;
        private System.Windows.Forms.Label TicketslabelH3;
        private System.Windows.Forms.TextBox NotextBoxH3;
        private System.Windows.Forms.Label NolabelH3;
        private System.Windows.Forms.TextBox EmailtextBoxH3;
        private System.Windows.Forms.Label EmaillabelH3;
        private System.Windows.Forms.TextBox GendertextBoxH3;
        private System.Windows.Forms.Label GenderlabelH3;
        private System.Windows.Forms.TextBox NametextBoxH3;
        private System.Windows.Forms.Label NamelabelH3;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}