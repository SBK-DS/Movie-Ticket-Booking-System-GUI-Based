﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHFm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHFm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH14 = new System.Windows.Forms.Button();
            this.AddresstextBoxH14 = new System.Windows.Forms.TextBox();
            this.AddresslabelH14 = new System.Windows.Forms.Label();
            this.TicketstextBoxH14 = new System.Windows.Forms.TextBox();
            this.TicketslabelH14 = new System.Windows.Forms.Label();
            this.NotextBoxH14 = new System.Windows.Forms.TextBox();
            this.NolabelH14 = new System.Windows.Forms.Label();
            this.EmailtextBoxH14 = new System.Windows.Forms.TextBox();
            this.EmaillabelH14 = new System.Windows.Forms.Label();
            this.GendertextBoxH14 = new System.Windows.Forms.TextBox();
            this.GenderlabelH14 = new System.Windows.Forms.Label();
            this.NametextBoxH14 = new System.Windows.Forms.TextBox();
            this.NamelabelH14 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1201, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 133;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH14
            // 
            this.RegisterH14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH14.Location = new System.Drawing.Point(478, 523);
            this.RegisterH14.Name = "RegisterH14";
            this.RegisterH14.Size = new System.Drawing.Size(286, 83);
            this.RegisterH14.TabIndex = 132;
            this.RegisterH14.Text = "Register";
            this.RegisterH14.UseVisualStyleBackColor = true;
            this.RegisterH14.Click += new System.EventHandler(this.RegisterH14_Click);
            // 
            // AddresstextBoxH14
            // 
            this.AddresstextBoxH14.Location = new System.Drawing.Point(419, 394);
            this.AddresstextBoxH14.Multiline = true;
            this.AddresstextBoxH14.Name = "AddresstextBoxH14";
            this.AddresstextBoxH14.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH14.TabIndex = 131;
            // 
            // AddresslabelH14
            // 
            this.AddresslabelH14.AutoSize = true;
            this.AddresslabelH14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH14.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH14.Location = new System.Drawing.Point(311, 382);
            this.AddresslabelH14.Name = "AddresslabelH14";
            this.AddresslabelH14.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH14.TabIndex = 130;
            this.AddresslabelH14.Text = "Add";
            // 
            // TicketstextBoxH14
            // 
            this.TicketstextBoxH14.Location = new System.Drawing.Point(419, 338);
            this.TicketstextBoxH14.Name = "TicketstextBoxH14";
            this.TicketstextBoxH14.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH14.TabIndex = 129;
            // 
            // TicketslabelH14
            // 
            this.TicketslabelH14.AutoSize = true;
            this.TicketslabelH14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH14.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH14.Location = new System.Drawing.Point(311, 327);
            this.TicketslabelH14.Name = "TicketslabelH14";
            this.TicketslabelH14.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH14.TabIndex = 128;
            this.TicketslabelH14.Text = "Tickets";
            // 
            // NotextBoxH14
            // 
            this.NotextBoxH14.Location = new System.Drawing.Point(419, 176);
            this.NotextBoxH14.Name = "NotextBoxH14";
            this.NotextBoxH14.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH14.TabIndex = 127;
            // 
            // NolabelH14
            // 
            this.NolabelH14.AutoSize = true;
            this.NolabelH14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH14.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH14.Location = new System.Drawing.Point(311, 165);
            this.NolabelH14.Name = "NolabelH14";
            this.NolabelH14.Size = new System.Drawing.Size(49, 31);
            this.NolabelH14.TabIndex = 126;
            this.NolabelH14.Text = "No";
            // 
            // EmailtextBoxH14
            // 
            this.EmailtextBoxH14.Location = new System.Drawing.Point(419, 232);
            this.EmailtextBoxH14.Name = "EmailtextBoxH14";
            this.EmailtextBoxH14.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH14.TabIndex = 125;
            // 
            // EmaillabelH14
            // 
            this.EmaillabelH14.AutoSize = true;
            this.EmaillabelH14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH14.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH14.Location = new System.Drawing.Point(311, 221);
            this.EmaillabelH14.Name = "EmaillabelH14";
            this.EmaillabelH14.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH14.TabIndex = 124;
            this.EmaillabelH14.Text = "Email";
            // 
            // GendertextBoxH14
            // 
            this.GendertextBoxH14.Location = new System.Drawing.Point(419, 284);
            this.GendertextBoxH14.Name = "GendertextBoxH14";
            this.GendertextBoxH14.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH14.TabIndex = 123;
            // 
            // GenderlabelH14
            // 
            this.GenderlabelH14.AutoSize = true;
            this.GenderlabelH14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH14.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH14.Location = new System.Drawing.Point(311, 273);
            this.GenderlabelH14.Name = "GenderlabelH14";
            this.GenderlabelH14.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH14.TabIndex = 122;
            this.GenderlabelH14.Text = "Gender";
            // 
            // NametextBoxH14
            // 
            this.NametextBoxH14.Location = new System.Drawing.Point(419, 121);
            this.NametextBoxH14.Name = "NametextBoxH14";
            this.NametextBoxH14.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH14.TabIndex = 121;
            // 
            // NamelabelH14
            // 
            this.NamelabelH14.AutoSize = true;
            this.NamelabelH14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH14.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH14.Location = new System.Drawing.Point(311, 110);
            this.NamelabelH14.Name = "NamelabelH14";
            this.NamelabelH14.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH14.TabIndex = 120;
            this.NamelabelH14.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 119;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHFm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1257, 700);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH14);
            this.Controls.Add(this.AddresstextBoxH14);
            this.Controls.Add(this.AddresslabelH14);
            this.Controls.Add(this.TicketstextBoxH14);
            this.Controls.Add(this.TicketslabelH14);
            this.Controls.Add(this.NotextBoxH14);
            this.Controls.Add(this.NolabelH14);
            this.Controls.Add(this.EmailtextBoxH14);
            this.Controls.Add(this.EmaillabelH14);
            this.Controls.Add(this.GendertextBoxH14);
            this.Controls.Add(this.GenderlabelH14);
            this.Controls.Add(this.NametextBoxH14);
            this.Controls.Add(this.NamelabelH14);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHFm2";
            this.Text = "BHFm2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH14;
        private System.Windows.Forms.TextBox AddresstextBoxH14;
        private System.Windows.Forms.Label AddresslabelH14;
        private System.Windows.Forms.TextBox TicketstextBoxH14;
        private System.Windows.Forms.Label TicketslabelH14;
        private System.Windows.Forms.TextBox NotextBoxH14;
        private System.Windows.Forms.Label NolabelH14;
        private System.Windows.Forms.TextBox EmailtextBoxH14;
        private System.Windows.Forms.Label EmaillabelH14;
        private System.Windows.Forms.TextBox GendertextBoxH14;
        private System.Windows.Forms.Label GenderlabelH14;
        private System.Windows.Forms.TextBox NametextBoxH14;
        private System.Windows.Forms.Label NamelabelH14;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}