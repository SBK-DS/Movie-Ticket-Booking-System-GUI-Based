﻿namespace Movie_Ticket_Booking_system
{
    partial class Booking_Bollywood_Monday_movie1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBMm2));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Namelabel = new System.Windows.Forms.Label();
            this.NametextBox = new System.Windows.Forms.TextBox();
            this.NotextBox = new System.Windows.Forms.TextBox();
            this.Nolabel = new System.Windows.Forms.Label();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            this.Emaillabel = new System.Windows.Forms.Label();
            this.GendertextBox = new System.Windows.Forms.TextBox();
            this.Genderlabel = new System.Windows.Forms.Label();
            this.Ticketslabel = new System.Windows.Forms.Label();
            this.TicketstextBox = new System.Windows.Forms.TextBox();
            this.AddresstextBox = new System.Windows.Forms.TextBox();
            this.Addresslabel = new System.Windows.Forms.Label();
            this.RegisterButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Namelabel
            // 
            this.Namelabel.AccessibleName = "Cust_name";
            this.Namelabel.AutoSize = true;
            this.Namelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel.Location = new System.Drawing.Point(242, 132);
            this.Namelabel.Name = "Namelabel";
            this.Namelabel.Size = new System.Drawing.Size(86, 31);
            this.Namelabel.TabIndex = 3;
            this.Namelabel.Text = "Name";
            // 
            // NametextBox
            // 
            this.NametextBox.AccessibleName = "Cust_name_txt";
            this.NametextBox.Location = new System.Drawing.Point(406, 140);
            this.NametextBox.Name = "NametextBox";
            this.NametextBox.Size = new System.Drawing.Size(631, 20);
            this.NametextBox.TabIndex = 4;
            // 
            // NotextBox
            // 
            this.NotextBox.AccessibleName = "Cust_no_txt";
            this.NotextBox.Location = new System.Drawing.Point(406, 199);
            this.NotextBox.Name = "NotextBox";
            this.NotextBox.Size = new System.Drawing.Size(631, 20);
            this.NotextBox.TabIndex = 6;
            // 
            // Nolabel
            // 
            this.Nolabel.AccessibleName = "Cust_no";
            this.Nolabel.AutoSize = true;
            this.Nolabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel.Location = new System.Drawing.Point(242, 191);
            this.Nolabel.Name = "Nolabel";
            this.Nolabel.Size = new System.Drawing.Size(49, 31);
            this.Nolabel.TabIndex = 5;
            this.Nolabel.Text = "No";
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.AccessibleName = "Cust_email_txt";
            this.EmailtextBox.Location = new System.Drawing.Point(406, 261);
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(631, 20);
            this.EmailtextBox.TabIndex = 8;
            // 
            // Emaillabel
            // 
            this.Emaillabel.AccessibleName = "Cust_email";
            this.Emaillabel.AutoSize = true;
            this.Emaillabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel.Location = new System.Drawing.Point(242, 253);
            this.Emaillabel.Name = "Emaillabel";
            this.Emaillabel.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel.TabIndex = 7;
            this.Emaillabel.Text = "Email";
            // 
            // GendertextBox
            // 
            this.GendertextBox.AccessibleName = "Cust_gender_txt";
            this.GendertextBox.Location = new System.Drawing.Point(406, 325);
            this.GendertextBox.Name = "GendertextBox";
            this.GendertextBox.Size = new System.Drawing.Size(631, 20);
            this.GendertextBox.TabIndex = 10;
            // 
            // Genderlabel
            // 
            this.Genderlabel.AccessibleName = "Cust_gender";
            this.Genderlabel.AutoSize = true;
            this.Genderlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel.Location = new System.Drawing.Point(242, 317);
            this.Genderlabel.Name = "Genderlabel";
            this.Genderlabel.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel.TabIndex = 9;
            this.Genderlabel.Text = "Gender";
            // 
            // Ticketslabel
            // 
            this.Ticketslabel.AccessibleName = "Cust_tickets";
            this.Ticketslabel.AutoSize = true;
            this.Ticketslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel.Location = new System.Drawing.Point(242, 378);
            this.Ticketslabel.Name = "Ticketslabel";
            this.Ticketslabel.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel.TabIndex = 11;
            this.Ticketslabel.Text = "Tickets";
            // 
            // TicketstextBox
            // 
            this.TicketstextBox.AccessibleName = "Cust_tickets_txt";
            this.TicketstextBox.Location = new System.Drawing.Point(406, 389);
            this.TicketstextBox.Name = "TicketstextBox";
            this.TicketstextBox.Size = new System.Drawing.Size(631, 20);
            this.TicketstextBox.TabIndex = 12;
            // 
            // AddresstextBox
            // 
            this.AddresstextBox.AccessibleName = "Cust_address_txt";
            this.AddresstextBox.Location = new System.Drawing.Point(406, 450);
            this.AddresstextBox.Multiline = true;
            this.AddresstextBox.Name = "AddresstextBox";
            this.AddresstextBox.Size = new System.Drawing.Size(631, 121);
            this.AddresstextBox.TabIndex = 14;
            // 
            // Addresslabel
            // 
            this.Addresslabel.AccessibleName = "Cust_address";
            this.Addresslabel.AutoSize = true;
            this.Addresslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel.Location = new System.Drawing.Point(242, 439);
            this.Addresslabel.Name = "Addresslabel";
            this.Addresslabel.Size = new System.Drawing.Size(114, 31);
            this.Addresslabel.TabIndex = 13;
            this.Addresslabel.Text = "Address";
            // 
            // RegisterButton
            // 
            this.RegisterButton.Location = new System.Drawing.Point(630, 622);
            this.RegisterButton.Name = "RegisterButton";
            this.RegisterButton.Size = new System.Drawing.Size(154, 48);
            this.RegisterButton.TabIndex = 15;
            this.RegisterButton.Text = "register";
            this.RegisterButton.UseVisualStyleBackColor = true;
        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Namelabel;
        private System.Windows.Forms.TextBox NametextBox;
        private System.Windows.Forms.TextBox NotextBox;
        private System.Windows.Forms.Label Nolabel;
        private System.Windows.Forms.TextBox EmailtextBox;
        private System.Windows.Forms.Label Emaillabel;
        private System.Windows.Forms.TextBox GendertextBox;
        private System.Windows.Forms.Label Genderlabel;
        private System.Windows.Forms.Label Ticketslabel;
        private System.Windows.Forms.TextBox TicketstextBox;
        private System.Windows.Forms.TextBox AddresstextBox;
        private System.Windows.Forms.Label Addresslabel;
        private System.Windows.Forms.Button RegisterButton;
    }
}