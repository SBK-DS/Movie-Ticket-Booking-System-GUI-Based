﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBWm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBWm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register6 = new System.Windows.Forms.Button();
            this.AddresstextBox6 = new System.Windows.Forms.TextBox();
            this.Addresslabel6 = new System.Windows.Forms.Label();
            this.TicketstextBox6 = new System.Windows.Forms.TextBox();
            this.Ticketslabel6 = new System.Windows.Forms.Label();
            this.NotextBox6 = new System.Windows.Forms.TextBox();
            this.Nolabel6 = new System.Windows.Forms.Label();
            this.EmailtextBox6 = new System.Windows.Forms.TextBox();
            this.Emaillabel6 = new System.Windows.Forms.Label();
            this.GendertextBox6 = new System.Windows.Forms.TextBox();
            this.Genderlabel6 = new System.Windows.Forms.Label();
            this.NametextBox6 = new System.Windows.Forms.TextBox();
            this.Namelabel6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1200, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 100;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register6
            // 
            this.Register6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register6.Location = new System.Drawing.Point(479, 523);
            this.Register6.Name = "Register6";
            this.Register6.Size = new System.Drawing.Size(286, 83);
            this.Register6.TabIndex = 99;
            this.Register6.Text = "Register";
            this.Register6.UseVisualStyleBackColor = true;
            this.Register6.Click += new System.EventHandler(this.Register6_Click);
            // 
            // AddresstextBox6
            // 
            this.AddresstextBox6.Location = new System.Drawing.Point(420, 394);
            this.AddresstextBox6.Multiline = true;
            this.AddresstextBox6.Name = "AddresstextBox6";
            this.AddresstextBox6.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox6.TabIndex = 98;
            // 
            // Addresslabel6
            // 
            this.Addresslabel6.AutoSize = true;
            this.Addresslabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel6.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel6.Location = new System.Drawing.Point(312, 382);
            this.Addresslabel6.Name = "Addresslabel6";
            this.Addresslabel6.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel6.TabIndex = 97;
            this.Addresslabel6.Text = "Add";
            // 
            // TicketstextBox6
            // 
            this.TicketstextBox6.Location = new System.Drawing.Point(420, 338);
            this.TicketstextBox6.Name = "TicketstextBox6";
            this.TicketstextBox6.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox6.TabIndex = 96;
            // 
            // Ticketslabel6
            // 
            this.Ticketslabel6.AutoSize = true;
            this.Ticketslabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel6.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel6.Location = new System.Drawing.Point(312, 327);
            this.Ticketslabel6.Name = "Ticketslabel6";
            this.Ticketslabel6.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel6.TabIndex = 95;
            this.Ticketslabel6.Text = "Tickets";
            // 
            // NotextBox6
            // 
            this.NotextBox6.Location = new System.Drawing.Point(420, 176);
            this.NotextBox6.Name = "NotextBox6";
            this.NotextBox6.Size = new System.Drawing.Size(539, 20);
            this.NotextBox6.TabIndex = 94;
            // 
            // Nolabel6
            // 
            this.Nolabel6.AutoSize = true;
            this.Nolabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel6.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel6.Location = new System.Drawing.Point(312, 165);
            this.Nolabel6.Name = "Nolabel6";
            this.Nolabel6.Size = new System.Drawing.Size(49, 31);
            this.Nolabel6.TabIndex = 93;
            this.Nolabel6.Text = "No";
            // 
            // EmailtextBox6
            // 
            this.EmailtextBox6.Location = new System.Drawing.Point(420, 232);
            this.EmailtextBox6.Name = "EmailtextBox6";
            this.EmailtextBox6.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox6.TabIndex = 92;
            // 
            // Emaillabel6
            // 
            this.Emaillabel6.AutoSize = true;
            this.Emaillabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel6.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel6.Location = new System.Drawing.Point(312, 221);
            this.Emaillabel6.Name = "Emaillabel6";
            this.Emaillabel6.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel6.TabIndex = 91;
            this.Emaillabel6.Text = "Email";
            // 
            // GendertextBox6
            // 
            this.GendertextBox6.Location = new System.Drawing.Point(420, 284);
            this.GendertextBox6.Name = "GendertextBox6";
            this.GendertextBox6.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox6.TabIndex = 90;
            // 
            // Genderlabel6
            // 
            this.Genderlabel6.AutoSize = true;
            this.Genderlabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel6.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel6.Location = new System.Drawing.Point(312, 273);
            this.Genderlabel6.Name = "Genderlabel6";
            this.Genderlabel6.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel6.TabIndex = 89;
            this.Genderlabel6.Text = "Gender";
            // 
            // NametextBox6
            // 
            this.NametextBox6.Location = new System.Drawing.Point(420, 121);
            this.NametextBox6.Name = "NametextBox6";
            this.NametextBox6.Size = new System.Drawing.Size(539, 20);
            this.NametextBox6.TabIndex = 88;
            // 
            // Namelabel6
            // 
            this.Namelabel6.AutoSize = true;
            this.Namelabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel6.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel6.Location = new System.Drawing.Point(312, 110);
            this.Namelabel6.Name = "Namelabel6";
            this.Namelabel6.Size = new System.Drawing.Size(86, 31);
            this.Namelabel6.TabIndex = 87;
            this.Namelabel6.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 86;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBWm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1256, 704);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register6);
            this.Controls.Add(this.AddresstextBox6);
            this.Controls.Add(this.Addresslabel6);
            this.Controls.Add(this.TicketstextBox6);
            this.Controls.Add(this.Ticketslabel6);
            this.Controls.Add(this.NotextBox6);
            this.Controls.Add(this.Nolabel6);
            this.Controls.Add(this.EmailtextBox6);
            this.Controls.Add(this.Emaillabel6);
            this.Controls.Add(this.GendertextBox6);
            this.Controls.Add(this.Genderlabel6);
            this.Controls.Add(this.NametextBox6);
            this.Controls.Add(this.Namelabel6);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBWm1";
            this.Text = "BBWm1";
            this.Load += new System.EventHandler(this.BBWm1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register6;
        private System.Windows.Forms.TextBox AddresstextBox6;
        private System.Windows.Forms.Label Addresslabel6;
        private System.Windows.Forms.TextBox TicketstextBox6;
        private System.Windows.Forms.Label Ticketslabel6;
        private System.Windows.Forms.TextBox NotextBox6;
        private System.Windows.Forms.Label Nolabel6;
        private System.Windows.Forms.TextBox EmailtextBox6;
        private System.Windows.Forms.Label Emaillabel6;
        private System.Windows.Forms.TextBox GendertextBox6;
        private System.Windows.Forms.Label Genderlabel6;
        private System.Windows.Forms.TextBox NametextBox6;
        private System.Windows.Forms.Label Namelabel6;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}