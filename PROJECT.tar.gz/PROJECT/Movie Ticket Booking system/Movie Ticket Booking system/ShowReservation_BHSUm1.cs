﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHSUm1 : Form
    {
        public ShowReservation_BHSUm1()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHSUm1_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHSUm1.Book_ID.ToString();
            textBox2.Text = BHSUm1.name_copy;
            textBox3.Text = BHSUm1.No_copy;
            textBox4.Text = BHSUm1.email_copy;
            textBox5.Text = BHSUm1.gender_copy;
            textBox6.Text = BHSUm1.Tickets_copy.ToString();
            textBox7.Text = BHSUm1.Day_copy;
            textBox8.Text = BHSUm1.Movie_copy;
            textBox9.Text = BHSUm1.Amount_copy.ToString();
            textBox10.Text = BHSUm1.timing_copy;
            textBox11.Text = BHSUm1.address_copy;
            textBox12.Text = BHSUm1.DT_copy;
        }
    }
}
