﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHMm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHMm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH1 = new System.Windows.Forms.Button();
            this.AddresstextBoxH1 = new System.Windows.Forms.TextBox();
            this.AddresslabelH1 = new System.Windows.Forms.Label();
            this.TicketstextBoxH1 = new System.Windows.Forms.TextBox();
            this.TicketslabelH1 = new System.Windows.Forms.Label();
            this.NotextBoxH1 = new System.Windows.Forms.TextBox();
            this.NolabelH1 = new System.Windows.Forms.Label();
            this.EmailtextBoxH1 = new System.Windows.Forms.TextBox();
            this.EmaillabelH1 = new System.Windows.Forms.Label();
            this.GendertextBoxH1 = new System.Windows.Forms.TextBox();
            this.GenderlabelH1 = new System.Windows.Forms.Label();
            this.NametextBoxH1 = new System.Windows.Forms.TextBox();
            this.NamelabelH1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1203, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 58;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH1
            // 
            this.RegisterH1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH1.Location = new System.Drawing.Point(480, 523);
            this.RegisterH1.Name = "RegisterH1";
            this.RegisterH1.Size = new System.Drawing.Size(286, 83);
            this.RegisterH1.TabIndex = 57;
            this.RegisterH1.Text = "Register";
            this.RegisterH1.UseVisualStyleBackColor = true;
            this.RegisterH1.Click += new System.EventHandler(this.RegisterH1_Click);
            // 
            // AddresstextBoxH1
            // 
            this.AddresstextBoxH1.Location = new System.Drawing.Point(421, 394);
            this.AddresstextBoxH1.Multiline = true;
            this.AddresstextBoxH1.Name = "AddresstextBoxH1";
            this.AddresstextBoxH1.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH1.TabIndex = 56;
            // 
            // AddresslabelH1
            // 
            this.AddresslabelH1.AutoSize = true;
            this.AddresslabelH1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH1.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH1.Location = new System.Drawing.Point(313, 382);
            this.AddresslabelH1.Name = "AddresslabelH1";
            this.AddresslabelH1.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH1.TabIndex = 55;
            this.AddresslabelH1.Text = "Add";
            // 
            // TicketstextBoxH1
            // 
            this.TicketstextBoxH1.Location = new System.Drawing.Point(421, 338);
            this.TicketstextBoxH1.Name = "TicketstextBoxH1";
            this.TicketstextBoxH1.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH1.TabIndex = 54;
            // 
            // TicketslabelH1
            // 
            this.TicketslabelH1.AutoSize = true;
            this.TicketslabelH1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH1.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH1.Location = new System.Drawing.Point(313, 327);
            this.TicketslabelH1.Name = "TicketslabelH1";
            this.TicketslabelH1.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH1.TabIndex = 53;
            this.TicketslabelH1.Text = "Tickets";
            // 
            // NotextBoxH1
            // 
            this.NotextBoxH1.Location = new System.Drawing.Point(421, 176);
            this.NotextBoxH1.Name = "NotextBoxH1";
            this.NotextBoxH1.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH1.TabIndex = 52;
            // 
            // NolabelH1
            // 
            this.NolabelH1.AutoSize = true;
            this.NolabelH1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH1.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH1.Location = new System.Drawing.Point(313, 165);
            this.NolabelH1.Name = "NolabelH1";
            this.NolabelH1.Size = new System.Drawing.Size(49, 31);
            this.NolabelH1.TabIndex = 51;
            this.NolabelH1.Text = "No";
            // 
            // EmailtextBoxH1
            // 
            this.EmailtextBoxH1.Location = new System.Drawing.Point(421, 232);
            this.EmailtextBoxH1.Name = "EmailtextBoxH1";
            this.EmailtextBoxH1.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH1.TabIndex = 50;
            // 
            // EmaillabelH1
            // 
            this.EmaillabelH1.AutoSize = true;
            this.EmaillabelH1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH1.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH1.Location = new System.Drawing.Point(313, 221);
            this.EmaillabelH1.Name = "EmaillabelH1";
            this.EmaillabelH1.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH1.TabIndex = 49;
            this.EmaillabelH1.Text = "Email";
            // 
            // GendertextBoxH1
            // 
            this.GendertextBoxH1.Location = new System.Drawing.Point(421, 284);
            this.GendertextBoxH1.Name = "GendertextBoxH1";
            this.GendertextBoxH1.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH1.TabIndex = 48;
            // 
            // GenderlabelH1
            // 
            this.GenderlabelH1.AutoSize = true;
            this.GenderlabelH1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH1.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH1.Location = new System.Drawing.Point(313, 273);
            this.GenderlabelH1.Name = "GenderlabelH1";
            this.GenderlabelH1.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH1.TabIndex = 47;
            this.GenderlabelH1.Text = "Gender";
            // 
            // NametextBoxH1
            // 
            this.NametextBoxH1.Location = new System.Drawing.Point(421, 121);
            this.NametextBoxH1.Name = "NametextBoxH1";
            this.NametextBoxH1.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH1.TabIndex = 46;
            // 
            // NamelabelH1
            // 
            this.NamelabelH1.AutoSize = true;
            this.NamelabelH1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH1.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH1.Location = new System.Drawing.Point(313, 110);
            this.NamelabelH1.Name = "NamelabelH1";
            this.NamelabelH1.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH1.TabIndex = 45;
            this.NamelabelH1.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHMm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1259, 706);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH1);
            this.Controls.Add(this.AddresstextBoxH1);
            this.Controls.Add(this.AddresslabelH1);
            this.Controls.Add(this.TicketstextBoxH1);
            this.Controls.Add(this.TicketslabelH1);
            this.Controls.Add(this.NotextBoxH1);
            this.Controls.Add(this.NolabelH1);
            this.Controls.Add(this.EmailtextBoxH1);
            this.Controls.Add(this.EmaillabelH1);
            this.Controls.Add(this.GendertextBoxH1);
            this.Controls.Add(this.GenderlabelH1);
            this.Controls.Add(this.NametextBoxH1);
            this.Controls.Add(this.NamelabelH1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHMm1";
            this.Text = "HBMm1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH1;
        private System.Windows.Forms.TextBox AddresstextBoxH1;
        private System.Windows.Forms.Label AddresslabelH1;
        private System.Windows.Forms.TextBox TicketstextBoxH1;
        private System.Windows.Forms.Label TicketslabelH1;
        private System.Windows.Forms.TextBox NotextBoxH1;
        private System.Windows.Forms.Label NolabelH1;
        private System.Windows.Forms.TextBox EmailtextBoxH1;
        private System.Windows.Forms.Label EmaillabelH1;
        private System.Windows.Forms.TextBox GendertextBoxH1;
        private System.Windows.Forms.Label GenderlabelH1;
        private System.Windows.Forms.TextBox NametextBoxH1;
        private System.Windows.Forms.Label NamelabelH1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}