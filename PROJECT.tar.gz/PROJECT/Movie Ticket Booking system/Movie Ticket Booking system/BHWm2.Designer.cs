﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHWm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHWm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH8 = new System.Windows.Forms.Button();
            this.AddresstextBoxH8 = new System.Windows.Forms.TextBox();
            this.AddresslabelH8 = new System.Windows.Forms.Label();
            this.TicketstextBoxH8 = new System.Windows.Forms.TextBox();
            this.TicketslabelH8 = new System.Windows.Forms.Label();
            this.NotextBoxH8 = new System.Windows.Forms.TextBox();
            this.NolabelH8 = new System.Windows.Forms.Label();
            this.EmailtextBoxH8 = new System.Windows.Forms.TextBox();
            this.EmaillabelH8 = new System.Windows.Forms.Label();
            this.GendertextBoxH8 = new System.Windows.Forms.TextBox();
            this.GenderlabelH8 = new System.Windows.Forms.Label();
            this.NametextBoxH8 = new System.Windows.Forms.TextBox();
            this.NamelabelH8 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1204, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 103;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH8
            // 
            this.RegisterH8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH8.Location = new System.Drawing.Point(481, 523);
            this.RegisterH8.Name = "RegisterH8";
            this.RegisterH8.Size = new System.Drawing.Size(286, 83);
            this.RegisterH8.TabIndex = 102;
            this.RegisterH8.Text = "Register";
            this.RegisterH8.UseVisualStyleBackColor = true;
            this.RegisterH8.Click += new System.EventHandler(this.RegisterH8_Click);
            // 
            // AddresstextBoxH8
            // 
            this.AddresstextBoxH8.Location = new System.Drawing.Point(422, 394);
            this.AddresstextBoxH8.Multiline = true;
            this.AddresstextBoxH8.Name = "AddresstextBoxH8";
            this.AddresstextBoxH8.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH8.TabIndex = 101;
            // 
            // AddresslabelH8
            // 
            this.AddresslabelH8.AutoSize = true;
            this.AddresslabelH8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH8.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH8.Location = new System.Drawing.Point(314, 382);
            this.AddresslabelH8.Name = "AddresslabelH8";
            this.AddresslabelH8.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH8.TabIndex = 100;
            this.AddresslabelH8.Text = "Add";
            // 
            // TicketstextBoxH8
            // 
            this.TicketstextBoxH8.Location = new System.Drawing.Point(422, 338);
            this.TicketstextBoxH8.Name = "TicketstextBoxH8";
            this.TicketstextBoxH8.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH8.TabIndex = 99;
            // 
            // TicketslabelH8
            // 
            this.TicketslabelH8.AutoSize = true;
            this.TicketslabelH8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH8.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH8.Location = new System.Drawing.Point(314, 327);
            this.TicketslabelH8.Name = "TicketslabelH8";
            this.TicketslabelH8.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH8.TabIndex = 98;
            this.TicketslabelH8.Text = "Tickets";
            // 
            // NotextBoxH8
            // 
            this.NotextBoxH8.Location = new System.Drawing.Point(422, 176);
            this.NotextBoxH8.Name = "NotextBoxH8";
            this.NotextBoxH8.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH8.TabIndex = 97;
            // 
            // NolabelH8
            // 
            this.NolabelH8.AutoSize = true;
            this.NolabelH8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH8.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH8.Location = new System.Drawing.Point(314, 165);
            this.NolabelH8.Name = "NolabelH8";
            this.NolabelH8.Size = new System.Drawing.Size(49, 31);
            this.NolabelH8.TabIndex = 96;
            this.NolabelH8.Text = "No";
            // 
            // EmailtextBoxH8
            // 
            this.EmailtextBoxH8.Location = new System.Drawing.Point(422, 232);
            this.EmailtextBoxH8.Name = "EmailtextBoxH8";
            this.EmailtextBoxH8.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH8.TabIndex = 95;
            // 
            // EmaillabelH8
            // 
            this.EmaillabelH8.AutoSize = true;
            this.EmaillabelH8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH8.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH8.Location = new System.Drawing.Point(314, 221);
            this.EmaillabelH8.Name = "EmaillabelH8";
            this.EmaillabelH8.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH8.TabIndex = 94;
            this.EmaillabelH8.Text = "Email";
            // 
            // GendertextBoxH8
            // 
            this.GendertextBoxH8.Location = new System.Drawing.Point(422, 284);
            this.GendertextBoxH8.Name = "GendertextBoxH8";
            this.GendertextBoxH8.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH8.TabIndex = 93;
            // 
            // GenderlabelH8
            // 
            this.GenderlabelH8.AutoSize = true;
            this.GenderlabelH8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH8.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH8.Location = new System.Drawing.Point(314, 273);
            this.GenderlabelH8.Name = "GenderlabelH8";
            this.GenderlabelH8.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH8.TabIndex = 92;
            this.GenderlabelH8.Text = "Gender";
            // 
            // NametextBoxH8
            // 
            this.NametextBoxH8.Location = new System.Drawing.Point(422, 121);
            this.NametextBoxH8.Name = "NametextBoxH8";
            this.NametextBoxH8.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH8.TabIndex = 91;
            // 
            // NamelabelH8
            // 
            this.NamelabelH8.AutoSize = true;
            this.NamelabelH8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH8.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH8.Location = new System.Drawing.Point(314, 110);
            this.NamelabelH8.Name = "NamelabelH8";
            this.NamelabelH8.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH8.TabIndex = 90;
            this.NamelabelH8.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHWm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1260, 702);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH8);
            this.Controls.Add(this.AddresstextBoxH8);
            this.Controls.Add(this.AddresslabelH8);
            this.Controls.Add(this.TicketstextBoxH8);
            this.Controls.Add(this.TicketslabelH8);
            this.Controls.Add(this.NotextBoxH8);
            this.Controls.Add(this.NolabelH8);
            this.Controls.Add(this.EmailtextBoxH8);
            this.Controls.Add(this.EmaillabelH8);
            this.Controls.Add(this.GendertextBoxH8);
            this.Controls.Add(this.GenderlabelH8);
            this.Controls.Add(this.NametextBoxH8);
            this.Controls.Add(this.NamelabelH8);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHWm2";
            this.Text = "BHWm2";
            this.Load += new System.EventHandler(this.BHWm2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH8;
        private System.Windows.Forms.TextBox AddresstextBoxH8;
        private System.Windows.Forms.Label AddresslabelH8;
        private System.Windows.Forms.TextBox TicketstextBoxH8;
        private System.Windows.Forms.Label TicketslabelH8;
        private System.Windows.Forms.TextBox NotextBoxH8;
        private System.Windows.Forms.Label NolabelH8;
        private System.Windows.Forms.TextBox EmailtextBoxH8;
        private System.Windows.Forms.Label EmaillabelH8;
        private System.Windows.Forms.TextBox GendertextBoxH8;
        private System.Windows.Forms.Label GenderlabelH8;
        private System.Windows.Forms.TextBox NametextBoxH8;
        private System.Windows.Forms.Label NamelabelH8;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}