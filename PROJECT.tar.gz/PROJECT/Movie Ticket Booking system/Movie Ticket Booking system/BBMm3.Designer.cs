﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBMm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBMm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register2 = new System.Windows.Forms.Button();
            this.AddresstextBox2 = new System.Windows.Forms.TextBox();
            this.Addresslabel2 = new System.Windows.Forms.Label();
            this.TicketstextBox2 = new System.Windows.Forms.TextBox();
            this.Ticketslabel2 = new System.Windows.Forms.Label();
            this.NotextBox2 = new System.Windows.Forms.TextBox();
            this.Nolabel2 = new System.Windows.Forms.Label();
            this.EmailtextBox2 = new System.Windows.Forms.TextBox();
            this.Emaillabel2 = new System.Windows.Forms.Label();
            this.GendertextBox2 = new System.Windows.Forms.TextBox();
            this.Genderlabel2 = new System.Windows.Forms.Label();
            this.NametextBox2 = new System.Windows.Forms.TextBox();
            this.Namelabel2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1203, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 44;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register2
            // 
            this.Register2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register2.Location = new System.Drawing.Point(483, 525);
            this.Register2.Name = "Register2";
            this.Register2.Size = new System.Drawing.Size(286, 83);
            this.Register2.TabIndex = 43;
            this.Register2.Text = "Register";
            this.Register2.UseVisualStyleBackColor = true;
            this.Register2.Click += new System.EventHandler(this.Register2_Click);
            // 
            // AddresstextBox2
            // 
            this.AddresstextBox2.Location = new System.Drawing.Point(424, 396);
            this.AddresstextBox2.Multiline = true;
            this.AddresstextBox2.Name = "AddresstextBox2";
            this.AddresstextBox2.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox2.TabIndex = 42;
            // 
            // Addresslabel2
            // 
            this.Addresslabel2.AutoSize = true;
            this.Addresslabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel2.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel2.Location = new System.Drawing.Point(316, 384);
            this.Addresslabel2.Name = "Addresslabel2";
            this.Addresslabel2.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel2.TabIndex = 41;
            this.Addresslabel2.Text = "Add";
            // 
            // TicketstextBox2
            // 
            this.TicketstextBox2.Location = new System.Drawing.Point(424, 340);
            this.TicketstextBox2.Name = "TicketstextBox2";
            this.TicketstextBox2.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox2.TabIndex = 40;
            // 
            // Ticketslabel2
            // 
            this.Ticketslabel2.AutoSize = true;
            this.Ticketslabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel2.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel2.Location = new System.Drawing.Point(316, 329);
            this.Ticketslabel2.Name = "Ticketslabel2";
            this.Ticketslabel2.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel2.TabIndex = 39;
            this.Ticketslabel2.Text = "Tickets";
            // 
            // NotextBox2
            // 
            this.NotextBox2.Location = new System.Drawing.Point(424, 178);
            this.NotextBox2.Name = "NotextBox2";
            this.NotextBox2.Size = new System.Drawing.Size(539, 20);
            this.NotextBox2.TabIndex = 38;
            // 
            // Nolabel2
            // 
            this.Nolabel2.AutoSize = true;
            this.Nolabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel2.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel2.Location = new System.Drawing.Point(316, 167);
            this.Nolabel2.Name = "Nolabel2";
            this.Nolabel2.Size = new System.Drawing.Size(49, 31);
            this.Nolabel2.TabIndex = 37;
            this.Nolabel2.Text = "No";
            // 
            // EmailtextBox2
            // 
            this.EmailtextBox2.Location = new System.Drawing.Point(424, 234);
            this.EmailtextBox2.Name = "EmailtextBox2";
            this.EmailtextBox2.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox2.TabIndex = 36;
            // 
            // Emaillabel2
            // 
            this.Emaillabel2.AutoSize = true;
            this.Emaillabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel2.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel2.Location = new System.Drawing.Point(316, 223);
            this.Emaillabel2.Name = "Emaillabel2";
            this.Emaillabel2.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel2.TabIndex = 35;
            this.Emaillabel2.Text = "Email";
            // 
            // GendertextBox2
            // 
            this.GendertextBox2.Location = new System.Drawing.Point(424, 286);
            this.GendertextBox2.Name = "GendertextBox2";
            this.GendertextBox2.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox2.TabIndex = 34;
            // 
            // Genderlabel2
            // 
            this.Genderlabel2.AutoSize = true;
            this.Genderlabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel2.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel2.Location = new System.Drawing.Point(316, 275);
            this.Genderlabel2.Name = "Genderlabel2";
            this.Genderlabel2.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel2.TabIndex = 33;
            this.Genderlabel2.Text = "Gender";
            // 
            // NametextBox2
            // 
            this.NametextBox2.Location = new System.Drawing.Point(424, 123);
            this.NametextBox2.Name = "NametextBox2";
            this.NametextBox2.Size = new System.Drawing.Size(539, 20);
            this.NametextBox2.TabIndex = 32;
            // 
            // Namelabel2
            // 
            this.Namelabel2.AutoSize = true;
            this.Namelabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel2.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel2.Location = new System.Drawing.Point(316, 112);
            this.Namelabel2.Name = "Namelabel2";
            this.Namelabel2.Size = new System.Drawing.Size(86, 31);
            this.Namelabel2.TabIndex = 31;
            this.Namelabel2.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 45;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBMm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1259, 666);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register2);
            this.Controls.Add(this.AddresstextBox2);
            this.Controls.Add(this.Addresslabel2);
            this.Controls.Add(this.TicketstextBox2);
            this.Controls.Add(this.Ticketslabel2);
            this.Controls.Add(this.NotextBox2);
            this.Controls.Add(this.Nolabel2);
            this.Controls.Add(this.EmailtextBox2);
            this.Controls.Add(this.Emaillabel2);
            this.Controls.Add(this.GendertextBox2);
            this.Controls.Add(this.Genderlabel2);
            this.Controls.Add(this.NametextBox2);
            this.Controls.Add(this.Namelabel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBMm3";
            this.Text = "BBMm3";
            this.Load += new System.EventHandler(this.BBMm3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register2;
        private System.Windows.Forms.TextBox AddresstextBox2;
        private System.Windows.Forms.Label Addresslabel2;
        private System.Windows.Forms.TextBox TicketstextBox2;
        private System.Windows.Forms.Label Ticketslabel2;
        private System.Windows.Forms.TextBox NotextBox2;
        private System.Windows.Forms.Label Nolabel2;
        private System.Windows.Forms.TextBox EmailtextBox2;
        private System.Windows.Forms.Label Emaillabel2;
        private System.Windows.Forms.TextBox GendertextBox2;
        private System.Windows.Forms.Label Genderlabel2;
        private System.Windows.Forms.TextBox NametextBox2;
        private System.Windows.Forms.Label Namelabel2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}