﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHWm3 : Form
    {
        public ShowReservation_BHWm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHWm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHWm3.Book_ID.ToString();
            textBox2.Text = BHWm3.name_copy;
            textBox3.Text = BHWm3.No_copy;
            textBox4.Text = BHWm3.email_copy;
            textBox5.Text = BHWm3.gender_copy;
            textBox6.Text = BHWm3.Tickets_copy.ToString();
            textBox7.Text = BHWm3.Day_copy;
            textBox8.Text = BHWm3.Movie_copy;
            textBox9.Text = BHWm3.Amount_copy.ToString();
            textBox10.Text = BHWm3.timing_copy;
            textBox11.Text = BHWm3.address_copy;
            textBox12.Text = BHWm3.DT_copy;
        }
    }
}
