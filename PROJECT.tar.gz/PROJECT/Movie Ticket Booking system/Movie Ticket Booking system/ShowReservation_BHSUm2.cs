﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHSUm2 : Form
    {
        public ShowReservation_BHSUm2()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHSUm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHSUm2.Book_ID.ToString();
            textBox2.Text = BHSUm2.name_copy;
            textBox3.Text = BHSUm2.No_copy;
            textBox4.Text = BHSUm2.email_copy;
            textBox5.Text = BHSUm2.gender_copy;
            textBox6.Text = BHSUm2.Tickets_copy.ToString();
            textBox7.Text = BHSUm2.Day_copy;
            textBox8.Text = BHSUm2.Movie_copy;
            textBox9.Text = BHSUm2.Amount_copy.ToString();
            textBox10.Text = BHSUm2.timing_copy;
            textBox11.Text = BHSUm2.address_copy;
            textBox12.Text = BHSUm2.DT_copy;
        }
    }
}
