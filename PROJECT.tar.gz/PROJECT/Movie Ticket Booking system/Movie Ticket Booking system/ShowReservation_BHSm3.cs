﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHSm3 : Form
    {
        public ShowReservation_BHSm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHSm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHSm3.Book_ID.ToString();
            textBox2.Text = BHSm3.name_copy;
            textBox3.Text = BHSm3.No_copy;
            textBox4.Text = BHSm3.email_copy;
            textBox5.Text = BHSm3.gender_copy;
            textBox6.Text = BHSm3.Tickets_copy.ToString();
            textBox7.Text = BHSm3.Day_copy;
            textBox8.Text = BHSm3.Movie_copy;
            textBox9.Text = BHSm3.Amount_copy.ToString();
            textBox10.Text = BHSm3.timing_copy;
            textBox11.Text = BHSm3.address_copy;
            textBox12.Text = BHSm3.DT_copy;
        }
    }
}
