﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Movie_Ticket_Booking_system
{
    public partial class Management : Form
    {



        class Manage
        {
            private string ID;
            private string Password;


            public void set_pass(string Password)
            {
                this.Password = Password;
            }
            public string get_pass()
            {
                return Password;
            }
        }






        public Management()
        {
            InitializeComponent();
        }

        private void Management_Load(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-UAV1AAR\SQLEXPRESS;Initial Catalog=OOPDATABASE;Integrated Security=True");


        private void button1_Click(object sender, EventArgs e)
        {
            Manage MG = new Manage();
            con.Open();
            SqlCommand sd = new SqlCommand("SELECT * FROM Manage", con);
            SqlDataReader SD = sd.ExecuteReader();
            while(SD.Read())
            {
                MG.set_pass(SD.GetValue(0).ToString());
            }
            con.Close();


            if(MG.get_pass() == textBox2.Text)
            {
                this.Hide();
                Management_portal MP = new Management_portal();
                MP.ShowDialog();
            }
            else
            {
                MessageBox.Show("Enter Correct Password");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            selection Sl = new selection();
            Sl.ShowDialog();
        }
    }
}
