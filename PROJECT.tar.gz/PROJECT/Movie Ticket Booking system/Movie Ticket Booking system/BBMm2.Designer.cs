﻿namespace Movie_Ticket_Booking_system
{
    partial class BBMm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBMm2));
            this.Register1 = new System.Windows.Forms.Button();
            this.AddresstextBox1 = new System.Windows.Forms.TextBox();
            this.Addresslabel1 = new System.Windows.Forms.Label();
            this.TicketstextBox1 = new System.Windows.Forms.TextBox();
            this.Ticketslabel1 = new System.Windows.Forms.Label();
            this.NotextBox1 = new System.Windows.Forms.TextBox();
            this.Nolabel1 = new System.Windows.Forms.Label();
            this.EmailtextBox1 = new System.Windows.Forms.TextBox();
            this.Emaillabel1 = new System.Windows.Forms.Label();
            this.GendertextBox1 = new System.Windows.Forms.TextBox();
            this.Genderlabel1 = new System.Windows.Forms.Label();
            this.NametextBox1 = new System.Windows.Forms.TextBox();
            this.Namelabel1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Register1
            // 
            this.Register1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register1.Location = new System.Drawing.Point(480, 525);
            this.Register1.Name = "Register1";
            this.Register1.Size = new System.Drawing.Size(286, 83);
            this.Register1.TabIndex = 28;
            this.Register1.Text = "Register";
            this.Register1.UseVisualStyleBackColor = true;
            this.Register1.Click += new System.EventHandler(this.Register2_Click);
            // 
            // AddresstextBox1
            // 
            this.AddresstextBox1.Location = new System.Drawing.Point(421, 396);
            this.AddresstextBox1.Multiline = true;
            this.AddresstextBox1.Name = "AddresstextBox1";
            this.AddresstextBox1.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox1.TabIndex = 27;
            // 
            // Addresslabel1
            // 
            this.Addresslabel1.AutoSize = true;
            this.Addresslabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel1.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel1.Location = new System.Drawing.Point(313, 384);
            this.Addresslabel1.Name = "Addresslabel1";
            this.Addresslabel1.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel1.TabIndex = 26;
            this.Addresslabel1.Text = "Add";
            // 
            // TicketstextBox1
            // 
            this.TicketstextBox1.Location = new System.Drawing.Point(421, 340);
            this.TicketstextBox1.Name = "TicketstextBox1";
            this.TicketstextBox1.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox1.TabIndex = 25;
            // 
            // Ticketslabel1
            // 
            this.Ticketslabel1.AutoSize = true;
            this.Ticketslabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel1.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel1.Location = new System.Drawing.Point(313, 329);
            this.Ticketslabel1.Name = "Ticketslabel1";
            this.Ticketslabel1.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel1.TabIndex = 24;
            this.Ticketslabel1.Text = "Tickets";
            // 
            // NotextBox1
            // 
            this.NotextBox1.Location = new System.Drawing.Point(421, 178);
            this.NotextBox1.Name = "NotextBox1";
            this.NotextBox1.Size = new System.Drawing.Size(539, 20);
            this.NotextBox1.TabIndex = 23;
            // 
            // Nolabel1
            // 
            this.Nolabel1.AutoSize = true;
            this.Nolabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel1.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel1.Location = new System.Drawing.Point(313, 167);
            this.Nolabel1.Name = "Nolabel1";
            this.Nolabel1.Size = new System.Drawing.Size(49, 31);
            this.Nolabel1.TabIndex = 22;
            this.Nolabel1.Text = "No";
            // 
            // EmailtextBox1
            // 
            this.EmailtextBox1.Location = new System.Drawing.Point(421, 234);
            this.EmailtextBox1.Name = "EmailtextBox1";
            this.EmailtextBox1.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox1.TabIndex = 21;
            // 
            // Emaillabel1
            // 
            this.Emaillabel1.AutoSize = true;
            this.Emaillabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel1.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel1.Location = new System.Drawing.Point(313, 223);
            this.Emaillabel1.Name = "Emaillabel1";
            this.Emaillabel1.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel1.TabIndex = 20;
            this.Emaillabel1.Text = "Email";
            // 
            // GendertextBox1
            // 
            this.GendertextBox1.Location = new System.Drawing.Point(421, 286);
            this.GendertextBox1.Name = "GendertextBox1";
            this.GendertextBox1.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox1.TabIndex = 19;
            // 
            // Genderlabel1
            // 
            this.Genderlabel1.AutoSize = true;
            this.Genderlabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel1.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel1.Location = new System.Drawing.Point(313, 275);
            this.Genderlabel1.Name = "Genderlabel1";
            this.Genderlabel1.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel1.TabIndex = 18;
            this.Genderlabel1.Text = "Gender";
            // 
            // NametextBox1
            // 
            this.NametextBox1.Location = new System.Drawing.Point(421, 123);
            this.NametextBox1.Name = "NametextBox1";
            this.NametextBox1.Size = new System.Drawing.Size(539, 20);
            this.NametextBox1.TabIndex = 17;
            // 
            // Namelabel1
            // 
            this.Namelabel1.AutoSize = true;
            this.Namelabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel1.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel1.Location = new System.Drawing.Point(313, 112);
            this.Namelabel1.Name = "Namelabel1";
            this.Namelabel1.Size = new System.Drawing.Size(86, 31);
            this.Namelabel1.TabIndex = 16;
            this.Namelabel1.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1200, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // BBMm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1256, 706);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register1);
            this.Controls.Add(this.AddresstextBox1);
            this.Controls.Add(this.Addresslabel1);
            this.Controls.Add(this.TicketstextBox1);
            this.Controls.Add(this.Ticketslabel1);
            this.Controls.Add(this.NotextBox1);
            this.Controls.Add(this.Nolabel1);
            this.Controls.Add(this.EmailtextBox1);
            this.Controls.Add(this.Emaillabel1);
            this.Controls.Add(this.GendertextBox1);
            this.Controls.Add(this.Genderlabel1);
            this.Controls.Add(this.NametextBox1);
            this.Controls.Add(this.Namelabel1);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBMm2";
            this.Text = "BBMm2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Register1;
        private System.Windows.Forms.TextBox AddresstextBox1;
        private System.Windows.Forms.Label Addresslabel1;
        private System.Windows.Forms.TextBox TicketstextBox1;
        private System.Windows.Forms.Label Ticketslabel1;
        private System.Windows.Forms.TextBox NotextBox1;
        private System.Windows.Forms.Label Nolabel1;
        private System.Windows.Forms.TextBox EmailtextBox1;
        private System.Windows.Forms.Label Emaillabel1;
        private System.Windows.Forms.TextBox GendertextBox1;
        private System.Windows.Forms.Label Genderlabel1;
        private System.Windows.Forms.TextBox NametextBox1;
        private System.Windows.Forms.Label Namelabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}