﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHTm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHTm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH6 = new System.Windows.Forms.Button();
            this.AddresstextBoxH6 = new System.Windows.Forms.TextBox();
            this.AddresslabelH6 = new System.Windows.Forms.Label();
            this.TicketstextBoxH6 = new System.Windows.Forms.TextBox();
            this.TicketslabelH6 = new System.Windows.Forms.Label();
            this.NotextBoxH6 = new System.Windows.Forms.TextBox();
            this.NolabelH6 = new System.Windows.Forms.Label();
            this.EmailtextBoxH6 = new System.Windows.Forms.TextBox();
            this.EmaillabelH6 = new System.Windows.Forms.Label();
            this.GendertextBoxH6 = new System.Windows.Forms.TextBox();
            this.GenderlabelH6 = new System.Windows.Forms.Label();
            this.NametextBoxH6 = new System.Windows.Forms.TextBox();
            this.NamelabelH6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1203, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 103;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH6
            // 
            this.RegisterH6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH6.Location = new System.Drawing.Point(480, 523);
            this.RegisterH6.Name = "RegisterH6";
            this.RegisterH6.Size = new System.Drawing.Size(286, 83);
            this.RegisterH6.TabIndex = 102;
            this.RegisterH6.Text = "Register";
            this.RegisterH6.UseVisualStyleBackColor = true;
            this.RegisterH6.Click += new System.EventHandler(this.RegisterH6_Click);
            // 
            // AddresstextBoxH6
            // 
            this.AddresstextBoxH6.Location = new System.Drawing.Point(421, 394);
            this.AddresstextBoxH6.Multiline = true;
            this.AddresstextBoxH6.Name = "AddresstextBoxH6";
            this.AddresstextBoxH6.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH6.TabIndex = 101;
            // 
            // AddresslabelH6
            // 
            this.AddresslabelH6.AutoSize = true;
            this.AddresslabelH6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH6.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH6.Location = new System.Drawing.Point(313, 382);
            this.AddresslabelH6.Name = "AddresslabelH6";
            this.AddresslabelH6.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH6.TabIndex = 100;
            this.AddresslabelH6.Text = "Add";
            // 
            // TicketstextBoxH6
            // 
            this.TicketstextBoxH6.Location = new System.Drawing.Point(421, 338);
            this.TicketstextBoxH6.Name = "TicketstextBoxH6";
            this.TicketstextBoxH6.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH6.TabIndex = 99;
            // 
            // TicketslabelH6
            // 
            this.TicketslabelH6.AutoSize = true;
            this.TicketslabelH6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH6.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH6.Location = new System.Drawing.Point(313, 327);
            this.TicketslabelH6.Name = "TicketslabelH6";
            this.TicketslabelH6.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH6.TabIndex = 98;
            this.TicketslabelH6.Text = "Tickets";
            // 
            // NotextBoxH6
            // 
            this.NotextBoxH6.Location = new System.Drawing.Point(421, 176);
            this.NotextBoxH6.Name = "NotextBoxH6";
            this.NotextBoxH6.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH6.TabIndex = 97;
            // 
            // NolabelH6
            // 
            this.NolabelH6.AutoSize = true;
            this.NolabelH6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH6.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH6.Location = new System.Drawing.Point(313, 165);
            this.NolabelH6.Name = "NolabelH6";
            this.NolabelH6.Size = new System.Drawing.Size(49, 31);
            this.NolabelH6.TabIndex = 96;
            this.NolabelH6.Text = "No";
            // 
            // EmailtextBoxH6
            // 
            this.EmailtextBoxH6.Location = new System.Drawing.Point(421, 232);
            this.EmailtextBoxH6.Name = "EmailtextBoxH6";
            this.EmailtextBoxH6.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH6.TabIndex = 95;
            // 
            // EmaillabelH6
            // 
            this.EmaillabelH6.AutoSize = true;
            this.EmaillabelH6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH6.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH6.Location = new System.Drawing.Point(313, 221);
            this.EmaillabelH6.Name = "EmaillabelH6";
            this.EmaillabelH6.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH6.TabIndex = 94;
            this.EmaillabelH6.Text = "Email";
            // 
            // GendertextBoxH6
            // 
            this.GendertextBoxH6.Location = new System.Drawing.Point(421, 284);
            this.GendertextBoxH6.Name = "GendertextBoxH6";
            this.GendertextBoxH6.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH6.TabIndex = 93;
            // 
            // GenderlabelH6
            // 
            this.GenderlabelH6.AutoSize = true;
            this.GenderlabelH6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH6.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH6.Location = new System.Drawing.Point(313, 273);
            this.GenderlabelH6.Name = "GenderlabelH6";
            this.GenderlabelH6.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH6.TabIndex = 92;
            this.GenderlabelH6.Text = "Gender";
            // 
            // NametextBoxH6
            // 
            this.NametextBoxH6.Location = new System.Drawing.Point(421, 121);
            this.NametextBoxH6.Name = "NametextBoxH6";
            this.NametextBoxH6.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH6.TabIndex = 91;
            // 
            // NamelabelH6
            // 
            this.NamelabelH6.AutoSize = true;
            this.NamelabelH6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH6.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH6.Location = new System.Drawing.Point(313, 110);
            this.NamelabelH6.Name = "NamelabelH6";
            this.NamelabelH6.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH6.TabIndex = 90;
            this.NamelabelH6.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHTm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1259, 700);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH6);
            this.Controls.Add(this.AddresstextBoxH6);
            this.Controls.Add(this.AddresslabelH6);
            this.Controls.Add(this.TicketstextBoxH6);
            this.Controls.Add(this.TicketslabelH6);
            this.Controls.Add(this.NotextBoxH6);
            this.Controls.Add(this.NolabelH6);
            this.Controls.Add(this.EmailtextBoxH6);
            this.Controls.Add(this.EmaillabelH6);
            this.Controls.Add(this.GendertextBoxH6);
            this.Controls.Add(this.GenderlabelH6);
            this.Controls.Add(this.NametextBoxH6);
            this.Controls.Add(this.NamelabelH6);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHTm3";
            this.Text = "HBTm3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH6;
        private System.Windows.Forms.TextBox AddresstextBoxH6;
        private System.Windows.Forms.Label AddresslabelH6;
        private System.Windows.Forms.TextBox TicketstextBoxH6;
        private System.Windows.Forms.Label TicketslabelH6;
        private System.Windows.Forms.TextBox NotextBoxH6;
        private System.Windows.Forms.Label NolabelH6;
        private System.Windows.Forms.TextBox EmailtextBoxH6;
        private System.Windows.Forms.Label EmaillabelH6;
        private System.Windows.Forms.TextBox GendertextBoxH6;
        private System.Windows.Forms.Label GenderlabelH6;
        private System.Windows.Forms.TextBox NametextBoxH6;
        private System.Windows.Forms.Label NamelabelH6;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}