﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Movie_Ticket_Booking_system
{
    public partial class Analytics : Form
    {

        public int C;
        int key = 1;
        int sum1 = 0;
        int sum2 = 0;

        public Analytics()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-UAV1AAR\SQLEXPRESS;Initial Catalog=OOPDATABASE;Integrated Security=True");


        private void Analytics_Load(object sender, EventArgs e)
        {
            Registerations();
            Registerations(key);
            Revenue();
            Revenue(key);
            Total();
        }

        public void Registerations()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT COUNT(ID) FROM BollywoodRegisterations", con);
            SqlDataReader sdr = cmd.ExecuteReader();
            while(sdr.Read())
            {
                C = int.Parse(sdr.GetValue(0).ToString());
            }
            label6.Text = C.ToString();
            con.Close();
        }
        public void Registerations(int k)
        {
            if(k==1)
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT COUNT(ID) FROM HollywoodRegisterations", con);
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    C = int.Parse(sdr.GetValue(0).ToString());
                }
                label7.Text = C.ToString();
                con.Close();
            }
        }

        public void Revenue()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT SUM(Bill) FROM BollywoodRegisterations", con);
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                C = int.Parse(sdr.GetValue(0).ToString());
            }
            sum1 += C;
            label8.Text = C.ToString();
            con.Close();
        }
        public void Revenue(int k)
        {
            if (k == 1)
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT SUM(Bill) FROM HollywoodRegisterations", con);
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    try
                    {
                        C = int.Parse(sdr.GetValue(0).ToString());
                    }
                    catch
                    {
                        C = 0;
                    }
                    
                }
                sum2 += C;
                label9.Text = C.ToString();
                con.Close();
            }
        }
        public void Total()
        {
            int total = 0;
            total += sum1 + sum2;
            label10.Text = total.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Management_portal MN = new Management_portal();
            MN.ShowDialog();
        }
    }
}
