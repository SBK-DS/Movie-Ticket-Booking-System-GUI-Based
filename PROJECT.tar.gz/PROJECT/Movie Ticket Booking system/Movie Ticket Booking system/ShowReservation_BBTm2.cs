﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBTm2 : Form
    {
        public ShowReservation_BBTm2()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBTm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBTm2.Book_ID.ToString();
            textBox2.Text = BBTm2.name_copy;
            textBox3.Text = BBTm2.No_copy;
            textBox4.Text = BBTm2.email_copy;
            textBox5.Text = BBTm2.gender_copy;
            textBox6.Text = BBTm2.Tickets_copy.ToString();
            textBox7.Text = BBTm2.Day_copy;
            textBox8.Text = BBTm2.Movie_copy;
            textBox9.Text = BBTm2.Amount_copy.ToString();
            textBox10.Text = BBTm2.timing_copy;
            textBox11.Text = BBTm2.address_copy;
            textBox12.Text = BBTm2.DT_copy;
        }
    }
}
