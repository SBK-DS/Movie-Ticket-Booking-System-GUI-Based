﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBTHm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBTHm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register11 = new System.Windows.Forms.Button();
            this.AddresstextBox11 = new System.Windows.Forms.TextBox();
            this.Addresslabel11 = new System.Windows.Forms.Label();
            this.TicketstextBox11 = new System.Windows.Forms.TextBox();
            this.Ticketslabel11 = new System.Windows.Forms.Label();
            this.NotextBox11 = new System.Windows.Forms.TextBox();
            this.Nolabel11 = new System.Windows.Forms.Label();
            this.EmailtextBox11 = new System.Windows.Forms.TextBox();
            this.Emaillabel11 = new System.Windows.Forms.Label();
            this.GendertextBox11 = new System.Windows.Forms.TextBox();
            this.Genderlabel11 = new System.Windows.Forms.Label();
            this.NametextBox11 = new System.Windows.Forms.TextBox();
            this.Namelabel11 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1198, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 145;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register11
            // 
            this.Register11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register11.Location = new System.Drawing.Point(477, 523);
            this.Register11.Name = "Register11";
            this.Register11.Size = new System.Drawing.Size(286, 83);
            this.Register11.TabIndex = 144;
            this.Register11.Text = "Register";
            this.Register11.UseVisualStyleBackColor = true;
            this.Register11.Click += new System.EventHandler(this.Register11_Click);
            // 
            // AddresstextBox11
            // 
            this.AddresstextBox11.Location = new System.Drawing.Point(418, 394);
            this.AddresstextBox11.Multiline = true;
            this.AddresstextBox11.Name = "AddresstextBox11";
            this.AddresstextBox11.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox11.TabIndex = 143;
            // 
            // Addresslabel11
            // 
            this.Addresslabel11.AutoSize = true;
            this.Addresslabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel11.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel11.Location = new System.Drawing.Point(310, 382);
            this.Addresslabel11.Name = "Addresslabel11";
            this.Addresslabel11.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel11.TabIndex = 142;
            this.Addresslabel11.Text = "Add";
            // 
            // TicketstextBox11
            // 
            this.TicketstextBox11.Location = new System.Drawing.Point(418, 338);
            this.TicketstextBox11.Name = "TicketstextBox11";
            this.TicketstextBox11.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox11.TabIndex = 141;
            // 
            // Ticketslabel11
            // 
            this.Ticketslabel11.AutoSize = true;
            this.Ticketslabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel11.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel11.Location = new System.Drawing.Point(310, 327);
            this.Ticketslabel11.Name = "Ticketslabel11";
            this.Ticketslabel11.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel11.TabIndex = 140;
            this.Ticketslabel11.Text = "Tickets";
            // 
            // NotextBox11
            // 
            this.NotextBox11.Location = new System.Drawing.Point(418, 176);
            this.NotextBox11.Name = "NotextBox11";
            this.NotextBox11.Size = new System.Drawing.Size(539, 20);
            this.NotextBox11.TabIndex = 139;
            // 
            // Nolabel11
            // 
            this.Nolabel11.AutoSize = true;
            this.Nolabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel11.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel11.Location = new System.Drawing.Point(310, 165);
            this.Nolabel11.Name = "Nolabel11";
            this.Nolabel11.Size = new System.Drawing.Size(49, 31);
            this.Nolabel11.TabIndex = 138;
            this.Nolabel11.Text = "No";
            // 
            // EmailtextBox11
            // 
            this.EmailtextBox11.Location = new System.Drawing.Point(418, 232);
            this.EmailtextBox11.Name = "EmailtextBox11";
            this.EmailtextBox11.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox11.TabIndex = 137;
            // 
            // Emaillabel11
            // 
            this.Emaillabel11.AutoSize = true;
            this.Emaillabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel11.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel11.Location = new System.Drawing.Point(310, 221);
            this.Emaillabel11.Name = "Emaillabel11";
            this.Emaillabel11.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel11.TabIndex = 136;
            this.Emaillabel11.Text = "Email";
            // 
            // GendertextBox11
            // 
            this.GendertextBox11.Location = new System.Drawing.Point(418, 284);
            this.GendertextBox11.Name = "GendertextBox11";
            this.GendertextBox11.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox11.TabIndex = 135;
            // 
            // Genderlabel11
            // 
            this.Genderlabel11.AutoSize = true;
            this.Genderlabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel11.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel11.Location = new System.Drawing.Point(310, 273);
            this.Genderlabel11.Name = "Genderlabel11";
            this.Genderlabel11.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel11.TabIndex = 134;
            this.Genderlabel11.Text = "Gender";
            // 
            // NametextBox11
            // 
            this.NametextBox11.Location = new System.Drawing.Point(418, 121);
            this.NametextBox11.Name = "NametextBox11";
            this.NametextBox11.Size = new System.Drawing.Size(539, 20);
            this.NametextBox11.TabIndex = 133;
            // 
            // Namelabel11
            // 
            this.Namelabel11.AutoSize = true;
            this.Namelabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel11.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel11.Location = new System.Drawing.Point(310, 109);
            this.Namelabel11.Name = "Namelabel11";
            this.Namelabel11.Size = new System.Drawing.Size(86, 31);
            this.Namelabel11.TabIndex = 132;
            this.Namelabel11.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(9, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 131;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBTHm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1254, 703);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register11);
            this.Controls.Add(this.AddresstextBox11);
            this.Controls.Add(this.Addresslabel11);
            this.Controls.Add(this.TicketstextBox11);
            this.Controls.Add(this.Ticketslabel11);
            this.Controls.Add(this.NotextBox11);
            this.Controls.Add(this.Nolabel11);
            this.Controls.Add(this.EmailtextBox11);
            this.Controls.Add(this.Emaillabel11);
            this.Controls.Add(this.GendertextBox11);
            this.Controls.Add(this.Genderlabel11);
            this.Controls.Add(this.NametextBox11);
            this.Controls.Add(this.Namelabel11);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBTHm3";
            this.Text = "BBTHm3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register11;
        private System.Windows.Forms.TextBox AddresstextBox11;
        private System.Windows.Forms.Label Addresslabel11;
        private System.Windows.Forms.TextBox TicketstextBox11;
        private System.Windows.Forms.Label Ticketslabel11;
        private System.Windows.Forms.TextBox NotextBox11;
        private System.Windows.Forms.Label Nolabel11;
        private System.Windows.Forms.TextBox EmailtextBox11;
        private System.Windows.Forms.Label Emaillabel11;
        private System.Windows.Forms.TextBox GendertextBox11;
        private System.Windows.Forms.Label Genderlabel11;
        private System.Windows.Forms.TextBox NametextBox11;
        private System.Windows.Forms.Label Namelabel11;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}