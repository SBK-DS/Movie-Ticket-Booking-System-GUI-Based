﻿namespace Movie_Ticket_Booking_system
{
    partial class BBMm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBMm1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Namelabel = new System.Windows.Forms.Label();
            this.NametextBox = new System.Windows.Forms.TextBox();
            this.GendertextBox = new System.Windows.Forms.TextBox();
            this.Genderlabel = new System.Windows.Forms.Label();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            this.Emaillabel = new System.Windows.Forms.Label();
            this.NotextBox = new System.Windows.Forms.TextBox();
            this.Nolabel = new System.Windows.Forms.Label();
            this.TicketstextBox = new System.Windows.Forms.TextBox();
            this.Ticketslabel = new System.Windows.Forms.Label();
            this.AddresstextBox = new System.Windows.Forms.TextBox();
            this.Addresslabel = new System.Windows.Forms.Label();
            this.Register = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Namelabel
            // 
            this.Namelabel.AutoSize = true;
            this.Namelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel.Location = new System.Drawing.Point(313, 112);
            this.Namelabel.Name = "Namelabel";
            this.Namelabel.Size = new System.Drawing.Size(86, 31);
            this.Namelabel.TabIndex = 2;
            this.Namelabel.Text = "Name";
            // 
            // NametextBox
            // 
            this.NametextBox.Location = new System.Drawing.Point(421, 123);
            this.NametextBox.Name = "NametextBox";
            this.NametextBox.Size = new System.Drawing.Size(539, 20);
            this.NametextBox.TabIndex = 3;
            // 
            // GendertextBox
            // 
            this.GendertextBox.Location = new System.Drawing.Point(421, 286);
            this.GendertextBox.Name = "GendertextBox";
            this.GendertextBox.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox.TabIndex = 5;
            // 
            // Genderlabel
            // 
            this.Genderlabel.AutoSize = true;
            this.Genderlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel.Location = new System.Drawing.Point(313, 275);
            this.Genderlabel.Name = "Genderlabel";
            this.Genderlabel.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel.TabIndex = 4;
            this.Genderlabel.Text = "Gender";
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.Location = new System.Drawing.Point(421, 234);
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox.TabIndex = 7;
            // 
            // Emaillabel
            // 
            this.Emaillabel.AutoSize = true;
            this.Emaillabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel.Location = new System.Drawing.Point(313, 223);
            this.Emaillabel.Name = "Emaillabel";
            this.Emaillabel.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel.TabIndex = 6;
            this.Emaillabel.Text = "Email";
            // 
            // NotextBox
            // 
            this.NotextBox.Location = new System.Drawing.Point(421, 178);
            this.NotextBox.Name = "NotextBox";
            this.NotextBox.Size = new System.Drawing.Size(539, 20);
            this.NotextBox.TabIndex = 9;
            // 
            // Nolabel
            // 
            this.Nolabel.AutoSize = true;
            this.Nolabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel.Location = new System.Drawing.Point(313, 167);
            this.Nolabel.Name = "Nolabel";
            this.Nolabel.Size = new System.Drawing.Size(49, 31);
            this.Nolabel.TabIndex = 8;
            this.Nolabel.Text = "No";
            // 
            // TicketstextBox
            // 
            this.TicketstextBox.Location = new System.Drawing.Point(421, 340);
            this.TicketstextBox.Name = "TicketstextBox";
            this.TicketstextBox.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox.TabIndex = 11;
            // 
            // Ticketslabel
            // 
            this.Ticketslabel.AutoSize = true;
            this.Ticketslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel.Location = new System.Drawing.Point(313, 329);
            this.Ticketslabel.Name = "Ticketslabel";
            this.Ticketslabel.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel.TabIndex = 10;
            this.Ticketslabel.Text = "Tickets";
            // 
            // AddresstextBox
            // 
            this.AddresstextBox.Location = new System.Drawing.Point(421, 396);
            this.AddresstextBox.Multiline = true;
            this.AddresstextBox.Name = "AddresstextBox";
            this.AddresstextBox.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox.TabIndex = 13;
            // 
            // Addresslabel
            // 
            this.Addresslabel.AutoSize = true;
            this.Addresslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel.Location = new System.Drawing.Point(313, 384);
            this.Addresslabel.Name = "Addresslabel";
            this.Addresslabel.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel.TabIndex = 12;
            this.Addresslabel.Text = "Add";
            // 
            // Register
            // 
            this.Register.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register.Location = new System.Drawing.Point(480, 525);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(286, 83);
            this.Register.TabIndex = 14;
            this.Register.Text = "Register";
            this.Register.UseVisualStyleBackColor = true;
            this.Register.Click += new System.EventHandler(this.Register_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1189, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // BBMm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1254, 707);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register);
            this.Controls.Add(this.AddresstextBox);
            this.Controls.Add(this.Addresslabel);
            this.Controls.Add(this.TicketstextBox);
            this.Controls.Add(this.Ticketslabel);
            this.Controls.Add(this.NotextBox);
            this.Controls.Add(this.Nolabel);
            this.Controls.Add(this.EmailtextBox);
            this.Controls.Add(this.Emaillabel);
            this.Controls.Add(this.GendertextBox);
            this.Controls.Add(this.Genderlabel);
            this.Controls.Add(this.NametextBox);
            this.Controls.Add(this.Namelabel);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBMm1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.BBMm1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Namelabel;
        private System.Windows.Forms.TextBox NametextBox;
        private System.Windows.Forms.TextBox GendertextBox;
        private System.Windows.Forms.Label Genderlabel;
        private System.Windows.Forms.TextBox EmailtextBox;
        private System.Windows.Forms.Label Emaillabel;
        private System.Windows.Forms.TextBox NotextBox;
        private System.Windows.Forms.Label Nolabel;
        private System.Windows.Forms.TextBox TicketstextBox;
        private System.Windows.Forms.Label Ticketslabel;
        private System.Windows.Forms.TextBox AddresstextBox;
        private System.Windows.Forms.Label Addresslabel;
        private System.Windows.Forms.Button Register;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}