﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBSUm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBSUm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register19 = new System.Windows.Forms.Button();
            this.AddresstextBox19 = new System.Windows.Forms.TextBox();
            this.Addresslabel19 = new System.Windows.Forms.Label();
            this.TicketstextBox19 = new System.Windows.Forms.TextBox();
            this.Ticketslabel19 = new System.Windows.Forms.Label();
            this.NotextBox19 = new System.Windows.Forms.TextBox();
            this.Nolabel19 = new System.Windows.Forms.Label();
            this.EmailtextBox19 = new System.Windows.Forms.TextBox();
            this.Emaillabel19 = new System.Windows.Forms.Label();
            this.GendertextBox19 = new System.Windows.Forms.TextBox();
            this.Genderlabel19 = new System.Windows.Forms.Label();
            this.NametextBox19 = new System.Windows.Forms.TextBox();
            this.Namelabel19 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1202, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 205;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register19
            // 
            this.Register19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register19.Location = new System.Drawing.Point(481, 523);
            this.Register19.Name = "Register19";
            this.Register19.Size = new System.Drawing.Size(286, 83);
            this.Register19.TabIndex = 204;
            this.Register19.Text = "Register";
            this.Register19.UseVisualStyleBackColor = true;
            this.Register19.Click += new System.EventHandler(this.Register19_Click);
            // 
            // AddresstextBox19
            // 
            this.AddresstextBox19.Location = new System.Drawing.Point(422, 394);
            this.AddresstextBox19.Multiline = true;
            this.AddresstextBox19.Name = "AddresstextBox19";
            this.AddresstextBox19.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox19.TabIndex = 203;
            // 
            // Addresslabel19
            // 
            this.Addresslabel19.AutoSize = true;
            this.Addresslabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel19.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel19.Location = new System.Drawing.Point(314, 382);
            this.Addresslabel19.Name = "Addresslabel19";
            this.Addresslabel19.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel19.TabIndex = 202;
            this.Addresslabel19.Text = "Add";
            // 
            // TicketstextBox19
            // 
            this.TicketstextBox19.Location = new System.Drawing.Point(422, 338);
            this.TicketstextBox19.Name = "TicketstextBox19";
            this.TicketstextBox19.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox19.TabIndex = 201;
            // 
            // Ticketslabel19
            // 
            this.Ticketslabel19.AutoSize = true;
            this.Ticketslabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel19.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel19.Location = new System.Drawing.Point(314, 327);
            this.Ticketslabel19.Name = "Ticketslabel19";
            this.Ticketslabel19.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel19.TabIndex = 200;
            this.Ticketslabel19.Text = "Tickets";
            // 
            // NotextBox19
            // 
            this.NotextBox19.Location = new System.Drawing.Point(422, 176);
            this.NotextBox19.Name = "NotextBox19";
            this.NotextBox19.Size = new System.Drawing.Size(539, 20);
            this.NotextBox19.TabIndex = 199;
            // 
            // Nolabel19
            // 
            this.Nolabel19.AutoSize = true;
            this.Nolabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel19.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel19.Location = new System.Drawing.Point(314, 165);
            this.Nolabel19.Name = "Nolabel19";
            this.Nolabel19.Size = new System.Drawing.Size(49, 31);
            this.Nolabel19.TabIndex = 198;
            this.Nolabel19.Text = "No";
            // 
            // EmailtextBox19
            // 
            this.EmailtextBox19.Location = new System.Drawing.Point(422, 232);
            this.EmailtextBox19.Name = "EmailtextBox19";
            this.EmailtextBox19.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox19.TabIndex = 197;
            // 
            // Emaillabel19
            // 
            this.Emaillabel19.AutoSize = true;
            this.Emaillabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel19.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel19.Location = new System.Drawing.Point(314, 221);
            this.Emaillabel19.Name = "Emaillabel19";
            this.Emaillabel19.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel19.TabIndex = 196;
            this.Emaillabel19.Text = "Email";
            // 
            // GendertextBox19
            // 
            this.GendertextBox19.Location = new System.Drawing.Point(422, 284);
            this.GendertextBox19.Name = "GendertextBox19";
            this.GendertextBox19.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox19.TabIndex = 195;
            // 
            // Genderlabel19
            // 
            this.Genderlabel19.AutoSize = true;
            this.Genderlabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel19.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel19.Location = new System.Drawing.Point(314, 273);
            this.Genderlabel19.Name = "Genderlabel19";
            this.Genderlabel19.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel19.TabIndex = 194;
            this.Genderlabel19.Text = "Gender";
            // 
            // NametextBox19
            // 
            this.NametextBox19.Location = new System.Drawing.Point(422, 121);
            this.NametextBox19.Name = "NametextBox19";
            this.NametextBox19.Size = new System.Drawing.Size(539, 20);
            this.NametextBox19.TabIndex = 193;
            // 
            // Namelabel19
            // 
            this.Namelabel19.AutoSize = true;
            this.Namelabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel19.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel19.Location = new System.Drawing.Point(314, 109);
            this.Namelabel19.Name = "Namelabel19";
            this.Namelabel19.Size = new System.Drawing.Size(86, 31);
            this.Namelabel19.TabIndex = 192;
            this.Namelabel19.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 191;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBSUm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1258, 706);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register19);
            this.Controls.Add(this.AddresstextBox19);
            this.Controls.Add(this.Addresslabel19);
            this.Controls.Add(this.TicketstextBox19);
            this.Controls.Add(this.Ticketslabel19);
            this.Controls.Add(this.NotextBox19);
            this.Controls.Add(this.Nolabel19);
            this.Controls.Add(this.EmailtextBox19);
            this.Controls.Add(this.Emaillabel19);
            this.Controls.Add(this.GendertextBox19);
            this.Controls.Add(this.Genderlabel19);
            this.Controls.Add(this.NametextBox19);
            this.Controls.Add(this.Namelabel19);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBSUm2";
            this.Text = "BBSUm2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register19;
        private System.Windows.Forms.TextBox AddresstextBox19;
        private System.Windows.Forms.Label Addresslabel19;
        private System.Windows.Forms.TextBox TicketstextBox19;
        private System.Windows.Forms.Label Ticketslabel19;
        private System.Windows.Forms.TextBox NotextBox19;
        private System.Windows.Forms.Label Nolabel19;
        private System.Windows.Forms.TextBox EmailtextBox19;
        private System.Windows.Forms.Label Emaillabel19;
        private System.Windows.Forms.TextBox GendertextBox19;
        private System.Windows.Forms.Label Genderlabel19;
        private System.Windows.Forms.TextBox NametextBox19;
        private System.Windows.Forms.Label Namelabel19;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}