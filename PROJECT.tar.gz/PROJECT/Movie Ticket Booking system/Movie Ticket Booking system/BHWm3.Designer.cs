﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHWm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHWm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH9 = new System.Windows.Forms.Button();
            this.AddresstextBoxH9 = new System.Windows.Forms.TextBox();
            this.AddresslabelH9 = new System.Windows.Forms.Label();
            this.TicketstextBoxH9 = new System.Windows.Forms.TextBox();
            this.TicketslabelH9 = new System.Windows.Forms.Label();
            this.NotextBoxH9 = new System.Windows.Forms.TextBox();
            this.NolabelH9 = new System.Windows.Forms.Label();
            this.EmailtextBoxH9 = new System.Windows.Forms.TextBox();
            this.EmaillabelH9 = new System.Windows.Forms.Label();
            this.GendertextBoxH9 = new System.Windows.Forms.TextBox();
            this.GenderlabelH9 = new System.Windows.Forms.Label();
            this.NametextBoxH9 = new System.Windows.Forms.TextBox();
            this.NamelabelH9 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1206, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 103;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH9
            // 
            this.RegisterH9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH9.Location = new System.Drawing.Point(483, 523);
            this.RegisterH9.Name = "RegisterH9";
            this.RegisterH9.Size = new System.Drawing.Size(286, 83);
            this.RegisterH9.TabIndex = 102;
            this.RegisterH9.Text = "Register";
            this.RegisterH9.UseVisualStyleBackColor = true;
            this.RegisterH9.Click += new System.EventHandler(this.RegisterH9_Click);
            // 
            // AddresstextBoxH9
            // 
            this.AddresstextBoxH9.Location = new System.Drawing.Point(424, 394);
            this.AddresstextBoxH9.Multiline = true;
            this.AddresstextBoxH9.Name = "AddresstextBoxH9";
            this.AddresstextBoxH9.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH9.TabIndex = 101;
            // 
            // AddresslabelH9
            // 
            this.AddresslabelH9.AutoSize = true;
            this.AddresslabelH9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH9.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH9.Location = new System.Drawing.Point(316, 382);
            this.AddresslabelH9.Name = "AddresslabelH9";
            this.AddresslabelH9.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH9.TabIndex = 100;
            this.AddresslabelH9.Text = "Add";
            // 
            // TicketstextBoxH9
            // 
            this.TicketstextBoxH9.Location = new System.Drawing.Point(424, 338);
            this.TicketstextBoxH9.Name = "TicketstextBoxH9";
            this.TicketstextBoxH9.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH9.TabIndex = 99;
            // 
            // TicketslabelH9
            // 
            this.TicketslabelH9.AutoSize = true;
            this.TicketslabelH9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH9.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH9.Location = new System.Drawing.Point(316, 327);
            this.TicketslabelH9.Name = "TicketslabelH9";
            this.TicketslabelH9.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH9.TabIndex = 98;
            this.TicketslabelH9.Text = "Tickets";
            // 
            // NotextBoxH9
            // 
            this.NotextBoxH9.Location = new System.Drawing.Point(424, 176);
            this.NotextBoxH9.Name = "NotextBoxH9";
            this.NotextBoxH9.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH9.TabIndex = 97;
            // 
            // NolabelH9
            // 
            this.NolabelH9.AutoSize = true;
            this.NolabelH9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH9.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH9.Location = new System.Drawing.Point(316, 165);
            this.NolabelH9.Name = "NolabelH9";
            this.NolabelH9.Size = new System.Drawing.Size(49, 31);
            this.NolabelH9.TabIndex = 96;
            this.NolabelH9.Text = "No";
            // 
            // EmailtextBoxH9
            // 
            this.EmailtextBoxH9.Location = new System.Drawing.Point(424, 232);
            this.EmailtextBoxH9.Name = "EmailtextBoxH9";
            this.EmailtextBoxH9.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH9.TabIndex = 95;
            // 
            // EmaillabelH9
            // 
            this.EmaillabelH9.AutoSize = true;
            this.EmaillabelH9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH9.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH9.Location = new System.Drawing.Point(316, 221);
            this.EmaillabelH9.Name = "EmaillabelH9";
            this.EmaillabelH9.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH9.TabIndex = 94;
            this.EmaillabelH9.Text = "Email";
            // 
            // GendertextBoxH9
            // 
            this.GendertextBoxH9.Location = new System.Drawing.Point(424, 284);
            this.GendertextBoxH9.Name = "GendertextBoxH9";
            this.GendertextBoxH9.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH9.TabIndex = 93;
            // 
            // GenderlabelH9
            // 
            this.GenderlabelH9.AutoSize = true;
            this.GenderlabelH9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH9.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH9.Location = new System.Drawing.Point(316, 273);
            this.GenderlabelH9.Name = "GenderlabelH9";
            this.GenderlabelH9.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH9.TabIndex = 92;
            this.GenderlabelH9.Text = "Gender";
            // 
            // NametextBoxH9
            // 
            this.NametextBoxH9.Location = new System.Drawing.Point(424, 121);
            this.NametextBoxH9.Name = "NametextBoxH9";
            this.NametextBoxH9.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH9.TabIndex = 91;
            // 
            // NamelabelH9
            // 
            this.NamelabelH9.AutoSize = true;
            this.NamelabelH9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH9.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH9.Location = new System.Drawing.Point(316, 110);
            this.NamelabelH9.Name = "NamelabelH9";
            this.NamelabelH9.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH9.TabIndex = 90;
            this.NamelabelH9.Text = "Name";
            this.NamelabelH9.Click += new System.EventHandler(this.NamelabelH9_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHWm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1262, 703);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH9);
            this.Controls.Add(this.AddresstextBoxH9);
            this.Controls.Add(this.AddresslabelH9);
            this.Controls.Add(this.TicketstextBoxH9);
            this.Controls.Add(this.TicketslabelH9);
            this.Controls.Add(this.NotextBoxH9);
            this.Controls.Add(this.NolabelH9);
            this.Controls.Add(this.EmailtextBoxH9);
            this.Controls.Add(this.EmaillabelH9);
            this.Controls.Add(this.GendertextBoxH9);
            this.Controls.Add(this.GenderlabelH9);
            this.Controls.Add(this.NametextBoxH9);
            this.Controls.Add(this.NamelabelH9);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHWm3";
            this.Text = "BHWm3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH9;
        private System.Windows.Forms.TextBox AddresstextBoxH9;
        private System.Windows.Forms.Label AddresslabelH9;
        private System.Windows.Forms.TextBox TicketstextBoxH9;
        private System.Windows.Forms.Label TicketslabelH9;
        private System.Windows.Forms.TextBox NotextBoxH9;
        private System.Windows.Forms.Label NolabelH9;
        private System.Windows.Forms.TextBox EmailtextBoxH9;
        private System.Windows.Forms.Label EmaillabelH9;
        private System.Windows.Forms.TextBox GendertextBoxH9;
        private System.Windows.Forms.Label GenderlabelH9;
        private System.Windows.Forms.TextBox NametextBoxH9;
        private System.Windows.Forms.Label NamelabelH9;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}