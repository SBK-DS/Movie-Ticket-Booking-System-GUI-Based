﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHTHm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHTHm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH10 = new System.Windows.Forms.Button();
            this.AddresstextBoxH10 = new System.Windows.Forms.TextBox();
            this.AddresslabelH10 = new System.Windows.Forms.Label();
            this.TicketstextBoxH10 = new System.Windows.Forms.TextBox();
            this.TicketslabelH10 = new System.Windows.Forms.Label();
            this.NotextBoxH10 = new System.Windows.Forms.TextBox();
            this.NolabelH10 = new System.Windows.Forms.Label();
            this.EmailtextBoxH10 = new System.Windows.Forms.TextBox();
            this.EmaillabelH10 = new System.Windows.Forms.Label();
            this.GendertextBoxH10 = new System.Windows.Forms.TextBox();
            this.GenderlabelH10 = new System.Windows.Forms.Label();
            this.NametextBoxH10 = new System.Windows.Forms.TextBox();
            this.NamelabelH10 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1204, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 118;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH10
            // 
            this.RegisterH10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH10.Location = new System.Drawing.Point(481, 523);
            this.RegisterH10.Name = "RegisterH10";
            this.RegisterH10.Size = new System.Drawing.Size(286, 83);
            this.RegisterH10.TabIndex = 117;
            this.RegisterH10.Text = "Register";
            this.RegisterH10.UseVisualStyleBackColor = true;
            this.RegisterH10.Click += new System.EventHandler(this.RegisterH10_Click);
            // 
            // AddresstextBoxH10
            // 
            this.AddresstextBoxH10.Location = new System.Drawing.Point(422, 394);
            this.AddresstextBoxH10.Multiline = true;
            this.AddresstextBoxH10.Name = "AddresstextBoxH10";
            this.AddresstextBoxH10.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH10.TabIndex = 116;
            // 
            // AddresslabelH10
            // 
            this.AddresslabelH10.AutoSize = true;
            this.AddresslabelH10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH10.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH10.Location = new System.Drawing.Point(314, 382);
            this.AddresslabelH10.Name = "AddresslabelH10";
            this.AddresslabelH10.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH10.TabIndex = 115;
            this.AddresslabelH10.Text = "Add";
            // 
            // TicketstextBoxH10
            // 
            this.TicketstextBoxH10.Location = new System.Drawing.Point(422, 338);
            this.TicketstextBoxH10.Name = "TicketstextBoxH10";
            this.TicketstextBoxH10.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH10.TabIndex = 114;
            // 
            // TicketslabelH10
            // 
            this.TicketslabelH10.AutoSize = true;
            this.TicketslabelH10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH10.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH10.Location = new System.Drawing.Point(314, 327);
            this.TicketslabelH10.Name = "TicketslabelH10";
            this.TicketslabelH10.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH10.TabIndex = 113;
            this.TicketslabelH10.Text = "Tickets";
            // 
            // NotextBoxH10
            // 
            this.NotextBoxH10.Location = new System.Drawing.Point(422, 176);
            this.NotextBoxH10.Name = "NotextBoxH10";
            this.NotextBoxH10.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH10.TabIndex = 112;
            // 
            // NolabelH10
            // 
            this.NolabelH10.AutoSize = true;
            this.NolabelH10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH10.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH10.Location = new System.Drawing.Point(314, 165);
            this.NolabelH10.Name = "NolabelH10";
            this.NolabelH10.Size = new System.Drawing.Size(49, 31);
            this.NolabelH10.TabIndex = 111;
            this.NolabelH10.Text = "No";
            // 
            // EmailtextBoxH10
            // 
            this.EmailtextBoxH10.Location = new System.Drawing.Point(422, 232);
            this.EmailtextBoxH10.Name = "EmailtextBoxH10";
            this.EmailtextBoxH10.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH10.TabIndex = 110;
            // 
            // EmaillabelH10
            // 
            this.EmaillabelH10.AutoSize = true;
            this.EmaillabelH10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH10.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH10.Location = new System.Drawing.Point(314, 221);
            this.EmaillabelH10.Name = "EmaillabelH10";
            this.EmaillabelH10.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH10.TabIndex = 109;
            this.EmaillabelH10.Text = "Email";
            // 
            // GendertextBoxH10
            // 
            this.GendertextBoxH10.Location = new System.Drawing.Point(422, 284);
            this.GendertextBoxH10.Name = "GendertextBoxH10";
            this.GendertextBoxH10.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH10.TabIndex = 108;
            // 
            // GenderlabelH10
            // 
            this.GenderlabelH10.AutoSize = true;
            this.GenderlabelH10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH10.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH10.Location = new System.Drawing.Point(314, 273);
            this.GenderlabelH10.Name = "GenderlabelH10";
            this.GenderlabelH10.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH10.TabIndex = 107;
            this.GenderlabelH10.Text = "Gender";
            // 
            // NametextBoxH10
            // 
            this.NametextBoxH10.Location = new System.Drawing.Point(422, 121);
            this.NametextBoxH10.Name = "NametextBoxH10";
            this.NametextBoxH10.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH10.TabIndex = 106;
            // 
            // NamelabelH10
            // 
            this.NamelabelH10.AutoSize = true;
            this.NamelabelH10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH10.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH10.Location = new System.Drawing.Point(314, 110);
            this.NamelabelH10.Name = "NamelabelH10";
            this.NamelabelH10.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH10.TabIndex = 105;
            this.NamelabelH10.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 104;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHTHm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1260, 703);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH10);
            this.Controls.Add(this.AddresstextBoxH10);
            this.Controls.Add(this.AddresslabelH10);
            this.Controls.Add(this.TicketstextBoxH10);
            this.Controls.Add(this.TicketslabelH10);
            this.Controls.Add(this.NotextBoxH10);
            this.Controls.Add(this.NolabelH10);
            this.Controls.Add(this.EmailtextBoxH10);
            this.Controls.Add(this.EmaillabelH10);
            this.Controls.Add(this.GendertextBoxH10);
            this.Controls.Add(this.GenderlabelH10);
            this.Controls.Add(this.NametextBoxH10);
            this.Controls.Add(this.NamelabelH10);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHTHm1";
            this.Text = "BHTHm1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH10;
        private System.Windows.Forms.TextBox AddresstextBoxH10;
        private System.Windows.Forms.Label AddresslabelH10;
        private System.Windows.Forms.TextBox TicketstextBoxH10;
        private System.Windows.Forms.Label TicketslabelH10;
        private System.Windows.Forms.TextBox NotextBoxH10;
        private System.Windows.Forms.Label NolabelH10;
        private System.Windows.Forms.TextBox EmailtextBoxH10;
        private System.Windows.Forms.Label EmaillabelH10;
        private System.Windows.Forms.TextBox GendertextBoxH10;
        private System.Windows.Forms.Label GenderlabelH10;
        private System.Windows.Forms.TextBox NametextBoxH10;
        private System.Windows.Forms.Label NamelabelH10;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}