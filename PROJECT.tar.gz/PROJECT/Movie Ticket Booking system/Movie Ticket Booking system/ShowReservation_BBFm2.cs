﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBFm2 : Form
    {
        public ShowReservation_BBFm2()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBFm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBFm2.Book_ID.ToString();
            textBox2.Text = BBFm2.name_copy;
            textBox3.Text = BBFm2.No_copy;
            textBox4.Text = BBFm2.email_copy;
            textBox5.Text = BBFm2.gender_copy;
            textBox6.Text = BBFm2.Tickets_copy.ToString();
            textBox7.Text = BBFm2.Day_copy;
            textBox8.Text = BBFm2.Movie_copy;
            textBox9.Text = BBFm2.Amount_copy.ToString();
            textBox10.Text = BBFm2.timing_copy;
            textBox11.Text = BBFm2.address_copy;
            textBox12.Text = BBFm2.DT_copy;
        }
    }
}
