﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBWm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBWm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register8 = new System.Windows.Forms.Button();
            this.AddresstextBox8 = new System.Windows.Forms.TextBox();
            this.Addresslabel8 = new System.Windows.Forms.Label();
            this.TicketstextBox8 = new System.Windows.Forms.TextBox();
            this.Ticketslabel8 = new System.Windows.Forms.Label();
            this.NotextBox8 = new System.Windows.Forms.TextBox();
            this.Nolabel8 = new System.Windows.Forms.Label();
            this.EmailtextBox8 = new System.Windows.Forms.TextBox();
            this.Emaillabel8 = new System.Windows.Forms.Label();
            this.GendertextBox8 = new System.Windows.Forms.TextBox();
            this.Genderlabel8 = new System.Windows.Forms.Label();
            this.NametextBox8 = new System.Windows.Forms.TextBox();
            this.Namelabel8 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1200, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 130;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register8
            // 
            this.Register8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register8.Location = new System.Drawing.Point(479, 523);
            this.Register8.Name = "Register8";
            this.Register8.Size = new System.Drawing.Size(286, 83);
            this.Register8.TabIndex = 129;
            this.Register8.Text = "Register";
            this.Register8.UseVisualStyleBackColor = true;
            this.Register8.Click += new System.EventHandler(this.Register8_Click);
            // 
            // AddresstextBox8
            // 
            this.AddresstextBox8.Location = new System.Drawing.Point(420, 394);
            this.AddresstextBox8.Multiline = true;
            this.AddresstextBox8.Name = "AddresstextBox8";
            this.AddresstextBox8.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox8.TabIndex = 128;
            // 
            // Addresslabel8
            // 
            this.Addresslabel8.AutoSize = true;
            this.Addresslabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel8.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel8.Location = new System.Drawing.Point(312, 382);
            this.Addresslabel8.Name = "Addresslabel8";
            this.Addresslabel8.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel8.TabIndex = 127;
            this.Addresslabel8.Text = "Add";
            // 
            // TicketstextBox8
            // 
            this.TicketstextBox8.Location = new System.Drawing.Point(420, 338);
            this.TicketstextBox8.Name = "TicketstextBox8";
            this.TicketstextBox8.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox8.TabIndex = 126;
            // 
            // Ticketslabel8
            // 
            this.Ticketslabel8.AutoSize = true;
            this.Ticketslabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel8.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel8.Location = new System.Drawing.Point(312, 327);
            this.Ticketslabel8.Name = "Ticketslabel8";
            this.Ticketslabel8.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel8.TabIndex = 125;
            this.Ticketslabel8.Text = "Tickets";
            // 
            // NotextBox8
            // 
            this.NotextBox8.Location = new System.Drawing.Point(420, 176);
            this.NotextBox8.Name = "NotextBox8";
            this.NotextBox8.Size = new System.Drawing.Size(539, 20);
            this.NotextBox8.TabIndex = 124;
            // 
            // Nolabel8
            // 
            this.Nolabel8.AutoSize = true;
            this.Nolabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel8.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel8.Location = new System.Drawing.Point(312, 165);
            this.Nolabel8.Name = "Nolabel8";
            this.Nolabel8.Size = new System.Drawing.Size(49, 31);
            this.Nolabel8.TabIndex = 123;
            this.Nolabel8.Text = "No";
            // 
            // EmailtextBox8
            // 
            this.EmailtextBox8.Location = new System.Drawing.Point(420, 232);
            this.EmailtextBox8.Name = "EmailtextBox8";
            this.EmailtextBox8.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox8.TabIndex = 122;
            // 
            // Emaillabel8
            // 
            this.Emaillabel8.AutoSize = true;
            this.Emaillabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel8.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel8.Location = new System.Drawing.Point(312, 221);
            this.Emaillabel8.Name = "Emaillabel8";
            this.Emaillabel8.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel8.TabIndex = 121;
            this.Emaillabel8.Text = "Email";
            // 
            // GendertextBox8
            // 
            this.GendertextBox8.Location = new System.Drawing.Point(420, 284);
            this.GendertextBox8.Name = "GendertextBox8";
            this.GendertextBox8.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox8.TabIndex = 120;
            // 
            // Genderlabel8
            // 
            this.Genderlabel8.AutoSize = true;
            this.Genderlabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel8.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel8.Location = new System.Drawing.Point(312, 273);
            this.Genderlabel8.Name = "Genderlabel8";
            this.Genderlabel8.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel8.TabIndex = 119;
            this.Genderlabel8.Text = "Gender";
            // 
            // NametextBox8
            // 
            this.NametextBox8.Location = new System.Drawing.Point(420, 121);
            this.NametextBox8.Name = "NametextBox8";
            this.NametextBox8.Size = new System.Drawing.Size(539, 20);
            this.NametextBox8.TabIndex = 118;
            // 
            // Namelabel8
            // 
            this.Namelabel8.AutoSize = true;
            this.Namelabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel8.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel8.Location = new System.Drawing.Point(312, 109);
            this.Namelabel8.Name = "Namelabel8";
            this.Namelabel8.Size = new System.Drawing.Size(86, 31);
            this.Namelabel8.TabIndex = 117;
            this.Namelabel8.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 116;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBWm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1256, 701);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register8);
            this.Controls.Add(this.AddresstextBox8);
            this.Controls.Add(this.Addresslabel8);
            this.Controls.Add(this.TicketstextBox8);
            this.Controls.Add(this.Ticketslabel8);
            this.Controls.Add(this.NotextBox8);
            this.Controls.Add(this.Nolabel8);
            this.Controls.Add(this.EmailtextBox8);
            this.Controls.Add(this.Emaillabel8);
            this.Controls.Add(this.GendertextBox8);
            this.Controls.Add(this.Genderlabel8);
            this.Controls.Add(this.NametextBox8);
            this.Controls.Add(this.Namelabel8);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBWm3";
            this.Text = "BBWm3";
            this.Load += new System.EventHandler(this.BBWm3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register8;
        private System.Windows.Forms.TextBox AddresstextBox8;
        private System.Windows.Forms.Label Addresslabel8;
        private System.Windows.Forms.TextBox TicketstextBox8;
        private System.Windows.Forms.Label Ticketslabel8;
        private System.Windows.Forms.TextBox NotextBox8;
        private System.Windows.Forms.Label Nolabel8;
        private System.Windows.Forms.TextBox EmailtextBox8;
        private System.Windows.Forms.Label Emaillabel8;
        private System.Windows.Forms.TextBox GendertextBox8;
        private System.Windows.Forms.Label Genderlabel8;
        private System.Windows.Forms.TextBox NametextBox8;
        private System.Windows.Forms.Label Namelabel8;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}