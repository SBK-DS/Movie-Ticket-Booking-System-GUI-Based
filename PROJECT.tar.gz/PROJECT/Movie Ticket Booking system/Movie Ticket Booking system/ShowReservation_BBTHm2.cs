﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBTHm2 : Form
    {
        public ShowReservation_BBTHm2()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBTHm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBTHm2.Book_ID.ToString();
            textBox2.Text = BBTHm2.name_copy;
            textBox3.Text = BBTHm2.No_copy;
            textBox4.Text = BBTHm2.email_copy;
            textBox5.Text = BBTHm2.gender_copy;
            textBox6.Text = BBTHm2.Tickets_copy.ToString();
            textBox7.Text = BBTHm2.Day_copy;
            textBox8.Text = BBTHm2.Movie_copy;
            textBox9.Text = BBTHm2.Amount_copy.ToString();
            textBox10.Text = BBTHm2.timing_copy;
            textBox11.Text = BBTHm2.address_copy;
            textBox12.Text = BBTHm2.DT_copy;
        }
    }
}
