﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBSUm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBSUm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register20 = new System.Windows.Forms.Button();
            this.AddresstextBox20 = new System.Windows.Forms.TextBox();
            this.Addresslabel20 = new System.Windows.Forms.Label();
            this.TicketstextBox20 = new System.Windows.Forms.TextBox();
            this.Ticketslabel20 = new System.Windows.Forms.Label();
            this.NotextBox20 = new System.Windows.Forms.TextBox();
            this.Nolabel20 = new System.Windows.Forms.Label();
            this.EmailtextBox20 = new System.Windows.Forms.TextBox();
            this.Emaillabel20 = new System.Windows.Forms.Label();
            this.GendertextBox20 = new System.Windows.Forms.TextBox();
            this.Genderlabel20 = new System.Windows.Forms.Label();
            this.NametextBox20 = new System.Windows.Forms.TextBox();
            this.Namelabel20 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1204, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 205;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register20
            // 
            this.Register20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register20.Location = new System.Drawing.Point(483, 523);
            this.Register20.Name = "Register20";
            this.Register20.Size = new System.Drawing.Size(286, 83);
            this.Register20.TabIndex = 204;
            this.Register20.Text = "Register";
            this.Register20.UseVisualStyleBackColor = true;
            this.Register20.Click += new System.EventHandler(this.Register20_Click);
            // 
            // AddresstextBox20
            // 
            this.AddresstextBox20.Location = new System.Drawing.Point(424, 394);
            this.AddresstextBox20.Multiline = true;
            this.AddresstextBox20.Name = "AddresstextBox20";
            this.AddresstextBox20.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox20.TabIndex = 203;
            // 
            // Addresslabel20
            // 
            this.Addresslabel20.AutoSize = true;
            this.Addresslabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel20.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel20.Location = new System.Drawing.Point(316, 382);
            this.Addresslabel20.Name = "Addresslabel20";
            this.Addresslabel20.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel20.TabIndex = 202;
            this.Addresslabel20.Text = "Add";
            // 
            // TicketstextBox20
            // 
            this.TicketstextBox20.Location = new System.Drawing.Point(424, 338);
            this.TicketstextBox20.Name = "TicketstextBox20";
            this.TicketstextBox20.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox20.TabIndex = 201;
            // 
            // Ticketslabel20
            // 
            this.Ticketslabel20.AutoSize = true;
            this.Ticketslabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel20.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel20.Location = new System.Drawing.Point(316, 327);
            this.Ticketslabel20.Name = "Ticketslabel20";
            this.Ticketslabel20.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel20.TabIndex = 200;
            this.Ticketslabel20.Text = "Tickets";
            // 
            // NotextBox20
            // 
            this.NotextBox20.Location = new System.Drawing.Point(424, 176);
            this.NotextBox20.Name = "NotextBox20";
            this.NotextBox20.Size = new System.Drawing.Size(539, 20);
            this.NotextBox20.TabIndex = 199;
            // 
            // Nolabel20
            // 
            this.Nolabel20.AutoSize = true;
            this.Nolabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel20.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel20.Location = new System.Drawing.Point(316, 165);
            this.Nolabel20.Name = "Nolabel20";
            this.Nolabel20.Size = new System.Drawing.Size(49, 31);
            this.Nolabel20.TabIndex = 198;
            this.Nolabel20.Text = "No";
            // 
            // EmailtextBox20
            // 
            this.EmailtextBox20.Location = new System.Drawing.Point(424, 232);
            this.EmailtextBox20.Name = "EmailtextBox20";
            this.EmailtextBox20.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox20.TabIndex = 197;
            // 
            // Emaillabel20
            // 
            this.Emaillabel20.AutoSize = true;
            this.Emaillabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel20.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel20.Location = new System.Drawing.Point(316, 221);
            this.Emaillabel20.Name = "Emaillabel20";
            this.Emaillabel20.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel20.TabIndex = 196;
            this.Emaillabel20.Text = "Email";
            // 
            // GendertextBox20
            // 
            this.GendertextBox20.Location = new System.Drawing.Point(424, 284);
            this.GendertextBox20.Name = "GendertextBox20";
            this.GendertextBox20.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox20.TabIndex = 195;
            // 
            // Genderlabel20
            // 
            this.Genderlabel20.AutoSize = true;
            this.Genderlabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel20.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel20.Location = new System.Drawing.Point(316, 273);
            this.Genderlabel20.Name = "Genderlabel20";
            this.Genderlabel20.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel20.TabIndex = 194;
            this.Genderlabel20.Text = "Gender";
            // 
            // NametextBox20
            // 
            this.NametextBox20.Location = new System.Drawing.Point(424, 121);
            this.NametextBox20.Name = "NametextBox20";
            this.NametextBox20.Size = new System.Drawing.Size(539, 20);
            this.NametextBox20.TabIndex = 193;
            // 
            // Namelabel20
            // 
            this.Namelabel20.AutoSize = true;
            this.Namelabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel20.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel20.Location = new System.Drawing.Point(316, 109);
            this.Namelabel20.Name = "Namelabel20";
            this.Namelabel20.Size = new System.Drawing.Size(86, 31);
            this.Namelabel20.TabIndex = 192;
            this.Namelabel20.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 191;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBSUm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1260, 708);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register20);
            this.Controls.Add(this.AddresstextBox20);
            this.Controls.Add(this.Addresslabel20);
            this.Controls.Add(this.TicketstextBox20);
            this.Controls.Add(this.Ticketslabel20);
            this.Controls.Add(this.NotextBox20);
            this.Controls.Add(this.Nolabel20);
            this.Controls.Add(this.EmailtextBox20);
            this.Controls.Add(this.Emaillabel20);
            this.Controls.Add(this.GendertextBox20);
            this.Controls.Add(this.Genderlabel20);
            this.Controls.Add(this.NametextBox20);
            this.Controls.Add(this.Namelabel20);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBSUm3";
            this.Text = "BBSUm3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register20;
        private System.Windows.Forms.TextBox AddresstextBox20;
        private System.Windows.Forms.Label Addresslabel20;
        private System.Windows.Forms.TextBox TicketstextBox20;
        private System.Windows.Forms.Label Ticketslabel20;
        private System.Windows.Forms.TextBox NotextBox20;
        private System.Windows.Forms.Label Nolabel20;
        private System.Windows.Forms.TextBox EmailtextBox20;
        private System.Windows.Forms.Label Emaillabel20;
        private System.Windows.Forms.TextBox GendertextBox20;
        private System.Windows.Forms.Label Genderlabel20;
        private System.Windows.Forms.TextBox NametextBox20;
        private System.Windows.Forms.Label Namelabel20;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}