﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBFm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBFm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register12 = new System.Windows.Forms.Button();
            this.AddresstextBox12 = new System.Windows.Forms.TextBox();
            this.Addresslabel12 = new System.Windows.Forms.Label();
            this.TicketstextBox12 = new System.Windows.Forms.TextBox();
            this.Ticketslabel12 = new System.Windows.Forms.Label();
            this.NotextBox12 = new System.Windows.Forms.TextBox();
            this.Nolabel12 = new System.Windows.Forms.Label();
            this.EmailtextBox12 = new System.Windows.Forms.TextBox();
            this.Emaillabel12 = new System.Windows.Forms.Label();
            this.GendertextBox12 = new System.Windows.Forms.TextBox();
            this.Genderlabel12 = new System.Windows.Forms.Label();
            this.NametextBox12 = new System.Windows.Forms.TextBox();
            this.Namelabel12 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1198, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 160;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register12
            // 
            this.Register12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register12.Location = new System.Drawing.Point(477, 523);
            this.Register12.Name = "Register12";
            this.Register12.Size = new System.Drawing.Size(286, 83);
            this.Register12.TabIndex = 159;
            this.Register12.Text = "Register";
            this.Register12.UseVisualStyleBackColor = true;
            this.Register12.Click += new System.EventHandler(this.Register12_Click);
            // 
            // AddresstextBox12
            // 
            this.AddresstextBox12.Location = new System.Drawing.Point(418, 394);
            this.AddresstextBox12.Multiline = true;
            this.AddresstextBox12.Name = "AddresstextBox12";
            this.AddresstextBox12.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox12.TabIndex = 158;
            // 
            // Addresslabel12
            // 
            this.Addresslabel12.AutoSize = true;
            this.Addresslabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel12.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel12.Location = new System.Drawing.Point(310, 382);
            this.Addresslabel12.Name = "Addresslabel12";
            this.Addresslabel12.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel12.TabIndex = 157;
            this.Addresslabel12.Text = "Add";
            // 
            // TicketstextBox12
            // 
            this.TicketstextBox12.Location = new System.Drawing.Point(418, 338);
            this.TicketstextBox12.Name = "TicketstextBox12";
            this.TicketstextBox12.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox12.TabIndex = 156;
            // 
            // Ticketslabel12
            // 
            this.Ticketslabel12.AutoSize = true;
            this.Ticketslabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel12.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel12.Location = new System.Drawing.Point(310, 327);
            this.Ticketslabel12.Name = "Ticketslabel12";
            this.Ticketslabel12.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel12.TabIndex = 155;
            this.Ticketslabel12.Text = "Tickets";
            // 
            // NotextBox12
            // 
            this.NotextBox12.Location = new System.Drawing.Point(418, 176);
            this.NotextBox12.Name = "NotextBox12";
            this.NotextBox12.Size = new System.Drawing.Size(539, 20);
            this.NotextBox12.TabIndex = 154;
            // 
            // Nolabel12
            // 
            this.Nolabel12.AutoSize = true;
            this.Nolabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel12.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel12.Location = new System.Drawing.Point(310, 165);
            this.Nolabel12.Name = "Nolabel12";
            this.Nolabel12.Size = new System.Drawing.Size(49, 31);
            this.Nolabel12.TabIndex = 153;
            this.Nolabel12.Text = "No";
            // 
            // EmailtextBox12
            // 
            this.EmailtextBox12.Location = new System.Drawing.Point(418, 232);
            this.EmailtextBox12.Name = "EmailtextBox12";
            this.EmailtextBox12.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox12.TabIndex = 152;
            // 
            // Emaillabel12
            // 
            this.Emaillabel12.AutoSize = true;
            this.Emaillabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel12.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel12.Location = new System.Drawing.Point(310, 221);
            this.Emaillabel12.Name = "Emaillabel12";
            this.Emaillabel12.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel12.TabIndex = 151;
            this.Emaillabel12.Text = "Email";
            // 
            // GendertextBox12
            // 
            this.GendertextBox12.Location = new System.Drawing.Point(418, 284);
            this.GendertextBox12.Name = "GendertextBox12";
            this.GendertextBox12.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox12.TabIndex = 150;
            // 
            // Genderlabel12
            // 
            this.Genderlabel12.AutoSize = true;
            this.Genderlabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel12.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel12.Location = new System.Drawing.Point(310, 273);
            this.Genderlabel12.Name = "Genderlabel12";
            this.Genderlabel12.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel12.TabIndex = 149;
            this.Genderlabel12.Text = "Gender";
            // 
            // NametextBox12
            // 
            this.NametextBox12.Location = new System.Drawing.Point(418, 121);
            this.NametextBox12.Name = "NametextBox12";
            this.NametextBox12.Size = new System.Drawing.Size(539, 20);
            this.NametextBox12.TabIndex = 148;
            // 
            // Namelabel12
            // 
            this.Namelabel12.AutoSize = true;
            this.Namelabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel12.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel12.Location = new System.Drawing.Point(310, 109);
            this.Namelabel12.Name = "Namelabel12";
            this.Namelabel12.Size = new System.Drawing.Size(86, 31);
            this.Namelabel12.TabIndex = 147;
            this.Namelabel12.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(9, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 146;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBFm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1254, 701);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register12);
            this.Controls.Add(this.AddresstextBox12);
            this.Controls.Add(this.Addresslabel12);
            this.Controls.Add(this.TicketstextBox12);
            this.Controls.Add(this.Ticketslabel12);
            this.Controls.Add(this.NotextBox12);
            this.Controls.Add(this.Nolabel12);
            this.Controls.Add(this.EmailtextBox12);
            this.Controls.Add(this.Emaillabel12);
            this.Controls.Add(this.GendertextBox12);
            this.Controls.Add(this.Genderlabel12);
            this.Controls.Add(this.NametextBox12);
            this.Controls.Add(this.Namelabel12);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBFm1";
            this.Text = "BBFm1";
            this.Load += new System.EventHandler(this.BBFm1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register12;
        private System.Windows.Forms.TextBox AddresstextBox12;
        private System.Windows.Forms.Label Addresslabel12;
        private System.Windows.Forms.TextBox TicketstextBox12;
        private System.Windows.Forms.Label Ticketslabel12;
        private System.Windows.Forms.TextBox NotextBox12;
        private System.Windows.Forms.Label Nolabel12;
        private System.Windows.Forms.TextBox EmailtextBox12;
        private System.Windows.Forms.Label Emaillabel12;
        private System.Windows.Forms.TextBox GendertextBox12;
        private System.Windows.Forms.Label Genderlabel12;
        private System.Windows.Forms.TextBox NametextBox12;
        private System.Windows.Forms.Label Namelabel12;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}