﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHSUm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHSUm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH21 = new System.Windows.Forms.Button();
            this.AddresstextBoxH21 = new System.Windows.Forms.TextBox();
            this.AddresslabelH21 = new System.Windows.Forms.Label();
            this.TicketstextBoxH21 = new System.Windows.Forms.TextBox();
            this.TicketslabelH21 = new System.Windows.Forms.Label();
            this.NotextBoxH21 = new System.Windows.Forms.TextBox();
            this.NolabelH21 = new System.Windows.Forms.Label();
            this.EmailtextBoxH21 = new System.Windows.Forms.TextBox();
            this.EmaillabelH21 = new System.Windows.Forms.Label();
            this.GendertextBoxH21 = new System.Windows.Forms.TextBox();
            this.GenderlabelH21 = new System.Windows.Forms.Label();
            this.NametextBoxH21 = new System.Windows.Forms.TextBox();
            this.NamelabelH21 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1197, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 163;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH21
            // 
            this.RegisterH21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH21.Location = new System.Drawing.Point(474, 523);
            this.RegisterH21.Name = "RegisterH21";
            this.RegisterH21.Size = new System.Drawing.Size(286, 83);
            this.RegisterH21.TabIndex = 162;
            this.RegisterH21.Text = "Register";
            this.RegisterH21.UseVisualStyleBackColor = true;
            this.RegisterH21.Click += new System.EventHandler(this.RegisterH21_Click);
            // 
            // AddresstextBoxH21
            // 
            this.AddresstextBoxH21.Location = new System.Drawing.Point(415, 394);
            this.AddresstextBoxH21.Multiline = true;
            this.AddresstextBoxH21.Name = "AddresstextBoxH21";
            this.AddresstextBoxH21.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH21.TabIndex = 161;
            // 
            // AddresslabelH21
            // 
            this.AddresslabelH21.AutoSize = true;
            this.AddresslabelH21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH21.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH21.Location = new System.Drawing.Point(307, 382);
            this.AddresslabelH21.Name = "AddresslabelH21";
            this.AddresslabelH21.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH21.TabIndex = 160;
            this.AddresslabelH21.Text = "Add";
            // 
            // TicketstextBoxH21
            // 
            this.TicketstextBoxH21.Location = new System.Drawing.Point(415, 338);
            this.TicketstextBoxH21.Name = "TicketstextBoxH21";
            this.TicketstextBoxH21.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH21.TabIndex = 159;
            // 
            // TicketslabelH21
            // 
            this.TicketslabelH21.AutoSize = true;
            this.TicketslabelH21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH21.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH21.Location = new System.Drawing.Point(307, 327);
            this.TicketslabelH21.Name = "TicketslabelH21";
            this.TicketslabelH21.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH21.TabIndex = 158;
            this.TicketslabelH21.Text = "Tickets";
            // 
            // NotextBoxH21
            // 
            this.NotextBoxH21.Location = new System.Drawing.Point(415, 176);
            this.NotextBoxH21.Name = "NotextBoxH21";
            this.NotextBoxH21.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH21.TabIndex = 157;
            // 
            // NolabelH21
            // 
            this.NolabelH21.AutoSize = true;
            this.NolabelH21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH21.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH21.Location = new System.Drawing.Point(307, 165);
            this.NolabelH21.Name = "NolabelH21";
            this.NolabelH21.Size = new System.Drawing.Size(49, 31);
            this.NolabelH21.TabIndex = 156;
            this.NolabelH21.Text = "No";
            // 
            // EmailtextBoxH21
            // 
            this.EmailtextBoxH21.Location = new System.Drawing.Point(415, 232);
            this.EmailtextBoxH21.Name = "EmailtextBoxH21";
            this.EmailtextBoxH21.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH21.TabIndex = 155;
            // 
            // EmaillabelH21
            // 
            this.EmaillabelH21.AutoSize = true;
            this.EmaillabelH21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH21.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH21.Location = new System.Drawing.Point(307, 221);
            this.EmaillabelH21.Name = "EmaillabelH21";
            this.EmaillabelH21.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH21.TabIndex = 154;
            this.EmaillabelH21.Text = "Email";
            // 
            // GendertextBoxH21
            // 
            this.GendertextBoxH21.Location = new System.Drawing.Point(415, 284);
            this.GendertextBoxH21.Name = "GendertextBoxH21";
            this.GendertextBoxH21.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH21.TabIndex = 153;
            // 
            // GenderlabelH21
            // 
            this.GenderlabelH21.AutoSize = true;
            this.GenderlabelH21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH21.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH21.Location = new System.Drawing.Point(307, 273);
            this.GenderlabelH21.Name = "GenderlabelH21";
            this.GenderlabelH21.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH21.TabIndex = 152;
            this.GenderlabelH21.Text = "Gender";
            // 
            // NametextBoxH21
            // 
            this.NametextBoxH21.Location = new System.Drawing.Point(415, 121);
            this.NametextBoxH21.Name = "NametextBoxH21";
            this.NametextBoxH21.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH21.TabIndex = 151;
            // 
            // NamelabelH21
            // 
            this.NamelabelH21.AutoSize = true;
            this.NamelabelH21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH21.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH21.Location = new System.Drawing.Point(307, 110);
            this.NamelabelH21.Name = "NamelabelH21";
            this.NamelabelH21.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH21.TabIndex = 150;
            this.NamelabelH21.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 149;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHSUm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1253, 699);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH21);
            this.Controls.Add(this.AddresstextBoxH21);
            this.Controls.Add(this.AddresslabelH21);
            this.Controls.Add(this.TicketstextBoxH21);
            this.Controls.Add(this.TicketslabelH21);
            this.Controls.Add(this.NotextBoxH21);
            this.Controls.Add(this.NolabelH21);
            this.Controls.Add(this.EmailtextBoxH21);
            this.Controls.Add(this.EmaillabelH21);
            this.Controls.Add(this.GendertextBoxH21);
            this.Controls.Add(this.GenderlabelH21);
            this.Controls.Add(this.NametextBoxH21);
            this.Controls.Add(this.NamelabelH21);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHSUm3";
            this.Text = "BHSUm3";
            this.Load += new System.EventHandler(this.BHSUm3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH21;
        private System.Windows.Forms.TextBox AddresstextBoxH21;
        private System.Windows.Forms.Label AddresslabelH21;
        private System.Windows.Forms.TextBox TicketstextBoxH21;
        private System.Windows.Forms.Label TicketslabelH21;
        private System.Windows.Forms.TextBox NotextBoxH21;
        private System.Windows.Forms.Label NolabelH21;
        private System.Windows.Forms.TextBox EmailtextBoxH21;
        private System.Windows.Forms.Label EmaillabelH21;
        private System.Windows.Forms.TextBox GendertextBoxH21;
        private System.Windows.Forms.Label GenderlabelH21;
        private System.Windows.Forms.TextBox NametextBoxH21;
        private System.Windows.Forms.Label NamelabelH21;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}