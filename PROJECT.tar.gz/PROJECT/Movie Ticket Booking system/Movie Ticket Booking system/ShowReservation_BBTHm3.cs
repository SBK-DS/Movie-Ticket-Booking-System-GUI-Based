﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBTHm3 : Form
    {
        public ShowReservation_BBTHm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBTHm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBTHm3.Book_ID.ToString();
            textBox2.Text = BBTHm3.name_copy;
            textBox3.Text = BBTHm3.No_copy;
            textBox4.Text = BBTHm3.email_copy;
            textBox5.Text = BBTHm3.gender_copy;
            textBox6.Text = BBTHm3.Tickets_copy.ToString();
            textBox7.Text = BBTHm3.Day_copy;
            textBox8.Text = BBTHm3.Movie_copy;
            textBox9.Text = BBTHm3.Amount_copy.ToString();
            textBox10.Text = BBTHm3.timing_copy;
            textBox11.Text = BBTHm3.address_copy;
            textBox12.Text = BBTHm3.DT_copy;
        }
    }
}
