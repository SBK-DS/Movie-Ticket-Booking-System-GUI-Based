﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHSUm3 : Form
    {
        public ShowReservation_BHSUm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHSUm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHSUm3.Book_ID.ToString();
            textBox2.Text = BHSUm3.name_copy;
            textBox3.Text = BHSUm3.No_copy;
            textBox4.Text = BHSUm3.email_copy;
            textBox5.Text = BHSUm3.gender_copy;
            textBox6.Text = BHSUm3.Tickets_copy.ToString();
            textBox7.Text = BHSUm3.Day_copy;
            textBox8.Text = BHSUm3.Movie_copy;
            textBox9.Text = BHSUm3.Amount_copy.ToString();
            textBox10.Text = BHSUm3.timing_copy;
            textBox11.Text = BHSUm3.address_copy;
            textBox12.Text = BHSUm3.DT_copy;
        }
    }
}
