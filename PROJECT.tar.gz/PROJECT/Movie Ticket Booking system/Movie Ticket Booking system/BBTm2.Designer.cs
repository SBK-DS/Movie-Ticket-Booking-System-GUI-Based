﻿namespace Movie_Ticket_Booking_system
{
    partial class BBTm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBTm2));
            this.Register4 = new System.Windows.Forms.Button();
            this.AddresstextBox4 = new System.Windows.Forms.TextBox();
            this.Addresslabel4 = new System.Windows.Forms.Label();
            this.TicketstextBox4 = new System.Windows.Forms.TextBox();
            this.Ticketslabel4 = new System.Windows.Forms.Label();
            this.NotextBox4 = new System.Windows.Forms.TextBox();
            this.Nolabel4 = new System.Windows.Forms.Label();
            this.EmailtextBox4 = new System.Windows.Forms.TextBox();
            this.Emaillabel4 = new System.Windows.Forms.Label();
            this.GendertextBox4 = new System.Windows.Forms.TextBox();
            this.Genderlabel4 = new System.Windows.Forms.Label();
            this.NametextBox4 = new System.Windows.Forms.TextBox();
            this.Namelabel4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Register4
            // 
            this.Register4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register4.Location = new System.Drawing.Point(480, 525);
            this.Register4.Name = "Register4";
            this.Register4.Size = new System.Drawing.Size(286, 83);
            this.Register4.TabIndex = 70;
            this.Register4.Text = "Register";
            this.Register4.UseVisualStyleBackColor = true;
            this.Register4.Click += new System.EventHandler(this.Register4_Click);
            // 
            // AddresstextBox4
            // 
            this.AddresstextBox4.Location = new System.Drawing.Point(421, 396);
            this.AddresstextBox4.Multiline = true;
            this.AddresstextBox4.Name = "AddresstextBox4";
            this.AddresstextBox4.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox4.TabIndex = 69;
            // 
            // Addresslabel4
            // 
            this.Addresslabel4.AutoSize = true;
            this.Addresslabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel4.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel4.Location = new System.Drawing.Point(313, 384);
            this.Addresslabel4.Name = "Addresslabel4";
            this.Addresslabel4.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel4.TabIndex = 68;
            this.Addresslabel4.Text = "Add";
            // 
            // TicketstextBox4
            // 
            this.TicketstextBox4.Location = new System.Drawing.Point(421, 340);
            this.TicketstextBox4.Name = "TicketstextBox4";
            this.TicketstextBox4.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox4.TabIndex = 67;
            // 
            // Ticketslabel4
            // 
            this.Ticketslabel4.AutoSize = true;
            this.Ticketslabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel4.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel4.Location = new System.Drawing.Point(313, 329);
            this.Ticketslabel4.Name = "Ticketslabel4";
            this.Ticketslabel4.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel4.TabIndex = 66;
            this.Ticketslabel4.Text = "Tickets";
            // 
            // NotextBox4
            // 
            this.NotextBox4.Location = new System.Drawing.Point(421, 178);
            this.NotextBox4.Name = "NotextBox4";
            this.NotextBox4.Size = new System.Drawing.Size(539, 20);
            this.NotextBox4.TabIndex = 65;
            // 
            // Nolabel4
            // 
            this.Nolabel4.AutoSize = true;
            this.Nolabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel4.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel4.Location = new System.Drawing.Point(313, 167);
            this.Nolabel4.Name = "Nolabel4";
            this.Nolabel4.Size = new System.Drawing.Size(49, 31);
            this.Nolabel4.TabIndex = 64;
            this.Nolabel4.Text = "No";
            // 
            // EmailtextBox4
            // 
            this.EmailtextBox4.Location = new System.Drawing.Point(421, 234);
            this.EmailtextBox4.Name = "EmailtextBox4";
            this.EmailtextBox4.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox4.TabIndex = 63;
            // 
            // Emaillabel4
            // 
            this.Emaillabel4.AutoSize = true;
            this.Emaillabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel4.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel4.Location = new System.Drawing.Point(313, 223);
            this.Emaillabel4.Name = "Emaillabel4";
            this.Emaillabel4.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel4.TabIndex = 62;
            this.Emaillabel4.Text = "Email";
            // 
            // GendertextBox4
            // 
            this.GendertextBox4.Location = new System.Drawing.Point(421, 286);
            this.GendertextBox4.Name = "GendertextBox4";
            this.GendertextBox4.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox4.TabIndex = 61;
            // 
            // Genderlabel4
            // 
            this.Genderlabel4.AutoSize = true;
            this.Genderlabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel4.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel4.Location = new System.Drawing.Point(313, 275);
            this.Genderlabel4.Name = "Genderlabel4";
            this.Genderlabel4.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel4.TabIndex = 60;
            this.Genderlabel4.Text = "Gender";
            // 
            // NametextBox4
            // 
            this.NametextBox4.Location = new System.Drawing.Point(421, 123);
            this.NametextBox4.Name = "NametextBox4";
            this.NametextBox4.Size = new System.Drawing.Size(539, 20);
            this.NametextBox4.TabIndex = 59;
            // 
            // Namelabel4
            // 
            this.Namelabel4.AutoSize = true;
            this.Namelabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel4.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel4.Location = new System.Drawing.Point(313, 112);
            this.Namelabel4.Name = "Namelabel4";
            this.Namelabel4.Size = new System.Drawing.Size(86, 31);
            this.Namelabel4.TabIndex = 58;
            this.Namelabel4.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 57;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1201, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 71;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // BBTm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1257, 706);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register4);
            this.Controls.Add(this.AddresstextBox4);
            this.Controls.Add(this.Addresslabel4);
            this.Controls.Add(this.TicketstextBox4);
            this.Controls.Add(this.Ticketslabel4);
            this.Controls.Add(this.NotextBox4);
            this.Controls.Add(this.Nolabel4);
            this.Controls.Add(this.EmailtextBox4);
            this.Controls.Add(this.Emaillabel4);
            this.Controls.Add(this.GendertextBox4);
            this.Controls.Add(this.Genderlabel4);
            this.Controls.Add(this.NametextBox4);
            this.Controls.Add(this.Namelabel4);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBTm2";
            this.Text = "BBTm2";
            this.Load += new System.EventHandler(this.BBTm2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Register4;
        private System.Windows.Forms.TextBox AddresstextBox4;
        private System.Windows.Forms.Label Addresslabel4;
        private System.Windows.Forms.TextBox TicketstextBox4;
        private System.Windows.Forms.Label Ticketslabel4;
        private System.Windows.Forms.TextBox NotextBox4;
        private System.Windows.Forms.Label Nolabel4;
        private System.Windows.Forms.TextBox EmailtextBox4;
        private System.Windows.Forms.Label Emaillabel4;
        private System.Windows.Forms.TextBox GendertextBox4;
        private System.Windows.Forms.Label Genderlabel4;
        private System.Windows.Forms.TextBox NametextBox4;
        private System.Windows.Forms.Label Namelabel4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}