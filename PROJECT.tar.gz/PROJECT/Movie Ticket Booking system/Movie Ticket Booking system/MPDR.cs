﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Movie_Ticket_Booking_system
{
    public partial class MPDR : Form
    {
        public MPDR()
        {
            InitializeComponent();
        }


        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-UAV1AAR\SQLEXPRESS;Initial Catalog=OOPDATABASE;Integrated Security=True");


        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Hollywood")
            {
                con.Open();
                SqlDataAdapter cmd = new SqlDataAdapter("SELECT * FROM HollywoodRegisterations", con);
                DataTable DT = new DataTable();
                cmd.Fill(DT);
                dataGridView1.DataSource = DT;
                con.Close();
            }
            if (comboBox1.Text == "Bollywood")
            {
                con.Open();
                SqlDataAdapter cmd = new SqlDataAdapter("SELECT * FROM BollywoodRegisterations", con);
                DataTable DT = new DataTable();
                cmd.Fill(DT);
                dataGridView1.DataSource = DT;
                con.Close();
            }
        }

        private void MPDR_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Hollywood");
            comboBox1.Items.Add("Bollywood");
        }

        private void button2_Click(object sender, EventArgs e)
        {


            if (comboBox1.Text == "Hollywood")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM HollywoodRegisterations", con);
                SqlDataReader S = cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Record has been deleted");
            }
            if (comboBox1.Text == "Bollywood")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM BollywoodRegisterations", con);
                SqlDataReader S = cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Record has been deleted");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Management_portal MP = new Management_portal();
            MP.ShowDialog();
        }
    }
}
