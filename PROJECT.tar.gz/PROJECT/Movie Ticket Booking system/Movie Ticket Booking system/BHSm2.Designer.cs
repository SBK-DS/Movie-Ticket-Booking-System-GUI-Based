﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHSm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHSm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH17 = new System.Windows.Forms.Button();
            this.AddresstextBoxH17 = new System.Windows.Forms.TextBox();
            this.AddresslabelH17 = new System.Windows.Forms.Label();
            this.TicketstextBoxH17 = new System.Windows.Forms.TextBox();
            this.TicketslabelH17 = new System.Windows.Forms.Label();
            this.NotextBoxH17 = new System.Windows.Forms.TextBox();
            this.NolabelH17 = new System.Windows.Forms.Label();
            this.EmailtextBoxH17 = new System.Windows.Forms.TextBox();
            this.EmaillabelH17 = new System.Windows.Forms.Label();
            this.GendertextBoxH17 = new System.Windows.Forms.TextBox();
            this.GenderlabelH17 = new System.Windows.Forms.Label();
            this.NametextBoxH17 = new System.Windows.Forms.TextBox();
            this.NamelabelH17 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1195, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 133;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH17
            // 
            this.RegisterH17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH17.Location = new System.Drawing.Point(472, 523);
            this.RegisterH17.Name = "RegisterH17";
            this.RegisterH17.Size = new System.Drawing.Size(286, 83);
            this.RegisterH17.TabIndex = 132;
            this.RegisterH17.Text = "Register";
            this.RegisterH17.UseVisualStyleBackColor = true;
            this.RegisterH17.Click += new System.EventHandler(this.RegisterH17_Click);
            // 
            // AddresstextBoxH17
            // 
            this.AddresstextBoxH17.Location = new System.Drawing.Point(413, 394);
            this.AddresstextBoxH17.Multiline = true;
            this.AddresstextBoxH17.Name = "AddresstextBoxH17";
            this.AddresstextBoxH17.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH17.TabIndex = 131;
            // 
            // AddresslabelH17
            // 
            this.AddresslabelH17.AutoSize = true;
            this.AddresslabelH17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH17.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH17.Location = new System.Drawing.Point(305, 382);
            this.AddresslabelH17.Name = "AddresslabelH17";
            this.AddresslabelH17.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH17.TabIndex = 130;
            this.AddresslabelH17.Text = "Add";
            // 
            // TicketstextBoxH17
            // 
            this.TicketstextBoxH17.Location = new System.Drawing.Point(413, 338);
            this.TicketstextBoxH17.Name = "TicketstextBoxH17";
            this.TicketstextBoxH17.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH17.TabIndex = 129;
            // 
            // TicketslabelH17
            // 
            this.TicketslabelH17.AutoSize = true;
            this.TicketslabelH17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH17.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH17.Location = new System.Drawing.Point(305, 327);
            this.TicketslabelH17.Name = "TicketslabelH17";
            this.TicketslabelH17.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH17.TabIndex = 128;
            this.TicketslabelH17.Text = "Tickets";
            // 
            // NotextBoxH17
            // 
            this.NotextBoxH17.Location = new System.Drawing.Point(413, 176);
            this.NotextBoxH17.Name = "NotextBoxH17";
            this.NotextBoxH17.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH17.TabIndex = 127;
            // 
            // NolabelH17
            // 
            this.NolabelH17.AutoSize = true;
            this.NolabelH17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH17.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH17.Location = new System.Drawing.Point(305, 165);
            this.NolabelH17.Name = "NolabelH17";
            this.NolabelH17.Size = new System.Drawing.Size(49, 31);
            this.NolabelH17.TabIndex = 126;
            this.NolabelH17.Text = "No";
            // 
            // EmailtextBoxH17
            // 
            this.EmailtextBoxH17.Location = new System.Drawing.Point(413, 232);
            this.EmailtextBoxH17.Name = "EmailtextBoxH17";
            this.EmailtextBoxH17.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH17.TabIndex = 125;
            // 
            // EmaillabelH17
            // 
            this.EmaillabelH17.AutoSize = true;
            this.EmaillabelH17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH17.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH17.Location = new System.Drawing.Point(305, 221);
            this.EmaillabelH17.Name = "EmaillabelH17";
            this.EmaillabelH17.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH17.TabIndex = 124;
            this.EmaillabelH17.Text = "Email";
            // 
            // GendertextBoxH17
            // 
            this.GendertextBoxH17.Location = new System.Drawing.Point(413, 284);
            this.GendertextBoxH17.Name = "GendertextBoxH17";
            this.GendertextBoxH17.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH17.TabIndex = 123;
            // 
            // GenderlabelH17
            // 
            this.GenderlabelH17.AutoSize = true;
            this.GenderlabelH17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH17.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH17.Location = new System.Drawing.Point(305, 273);
            this.GenderlabelH17.Name = "GenderlabelH17";
            this.GenderlabelH17.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH17.TabIndex = 122;
            this.GenderlabelH17.Text = "Gender";
            // 
            // NametextBoxH17
            // 
            this.NametextBoxH17.Location = new System.Drawing.Point(413, 121);
            this.NametextBoxH17.Name = "NametextBoxH17";
            this.NametextBoxH17.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH17.TabIndex = 121;
            // 
            // NamelabelH17
            // 
            this.NamelabelH17.AutoSize = true;
            this.NamelabelH17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH17.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH17.Location = new System.Drawing.Point(305, 110);
            this.NamelabelH17.Name = "NamelabelH17";
            this.NamelabelH17.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH17.TabIndex = 120;
            this.NamelabelH17.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(4, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 119;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHSm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1251, 698);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH17);
            this.Controls.Add(this.AddresstextBoxH17);
            this.Controls.Add(this.AddresslabelH17);
            this.Controls.Add(this.TicketstextBoxH17);
            this.Controls.Add(this.TicketslabelH17);
            this.Controls.Add(this.NotextBoxH17);
            this.Controls.Add(this.NolabelH17);
            this.Controls.Add(this.EmailtextBoxH17);
            this.Controls.Add(this.EmaillabelH17);
            this.Controls.Add(this.GendertextBoxH17);
            this.Controls.Add(this.GenderlabelH17);
            this.Controls.Add(this.NametextBoxH17);
            this.Controls.Add(this.NamelabelH17);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHSm2";
            this.Text = "BHSm2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH17;
        private System.Windows.Forms.TextBox AddresstextBoxH17;
        private System.Windows.Forms.Label AddresslabelH17;
        private System.Windows.Forms.TextBox TicketstextBoxH17;
        private System.Windows.Forms.Label TicketslabelH17;
        private System.Windows.Forms.TextBox NotextBoxH17;
        private System.Windows.Forms.Label NolabelH17;
        private System.Windows.Forms.TextBox EmailtextBoxH17;
        private System.Windows.Forms.Label EmaillabelH17;
        private System.Windows.Forms.TextBox GendertextBoxH17;
        private System.Windows.Forms.Label GenderlabelH17;
        private System.Windows.Forms.TextBox NametextBoxH17;
        private System.Windows.Forms.Label NamelabelH17;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}