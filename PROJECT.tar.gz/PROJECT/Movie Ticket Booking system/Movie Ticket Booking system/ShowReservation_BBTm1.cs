﻿using System;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBTm1 : Form
    {
        public ShowReservation_BBTm1()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBTm1_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBTm1.Book_ID.ToString();
            textBox2.Text = BBTm1.name_copy;
            textBox3.Text = BBTm1.No_copy;
            textBox4.Text = BBTm1.email_copy;
            textBox5.Text = BBTm1.gender_copy;
            textBox6.Text = BBTm1.Tickets_copy.ToString();
            textBox7.Text = BBTm1.Day_copy;
            textBox8.Text = BBTm1.Movie_copy;
            textBox9.Text = BBTm1.Amount_copy.ToString();
            textBox10.Text = BBTm1.timing_copy;
            textBox11.Text = BBTm1.address_copy;
            textBox12.Text = BBTm1.DT_copy;
        }
    }
}
