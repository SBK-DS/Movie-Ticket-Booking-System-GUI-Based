﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHSUm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHSUm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH20 = new System.Windows.Forms.Button();
            this.AddresstextBoxH20 = new System.Windows.Forms.TextBox();
            this.AddresslabelH20 = new System.Windows.Forms.Label();
            this.TicketstextBoxH20 = new System.Windows.Forms.TextBox();
            this.TicketslabelH20 = new System.Windows.Forms.Label();
            this.NotextBoxH20 = new System.Windows.Forms.TextBox();
            this.NolabelH20 = new System.Windows.Forms.Label();
            this.EmailtextBoxH20 = new System.Windows.Forms.TextBox();
            this.EmaillabelH20 = new System.Windows.Forms.Label();
            this.GendertextBoxH20 = new System.Windows.Forms.TextBox();
            this.GenderlabelH20 = new System.Windows.Forms.Label();
            this.NametextBoxH20 = new System.Windows.Forms.TextBox();
            this.NamelabelH20 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1196, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 148;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH20
            // 
            this.RegisterH20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH20.Location = new System.Drawing.Point(473, 523);
            this.RegisterH20.Name = "RegisterH20";
            this.RegisterH20.Size = new System.Drawing.Size(286, 83);
            this.RegisterH20.TabIndex = 147;
            this.RegisterH20.Text = "Register";
            this.RegisterH20.UseVisualStyleBackColor = true;
            this.RegisterH20.Click += new System.EventHandler(this.RegisterH20_Click);
            // 
            // AddresstextBoxH20
            // 
            this.AddresstextBoxH20.Location = new System.Drawing.Point(414, 394);
            this.AddresstextBoxH20.Multiline = true;
            this.AddresstextBoxH20.Name = "AddresstextBoxH20";
            this.AddresstextBoxH20.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH20.TabIndex = 146;
            // 
            // AddresslabelH20
            // 
            this.AddresslabelH20.AutoSize = true;
            this.AddresslabelH20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH20.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH20.Location = new System.Drawing.Point(306, 382);
            this.AddresslabelH20.Name = "AddresslabelH20";
            this.AddresslabelH20.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH20.TabIndex = 145;
            this.AddresslabelH20.Text = "Add";
            // 
            // TicketstextBoxH20
            // 
            this.TicketstextBoxH20.Location = new System.Drawing.Point(414, 338);
            this.TicketstextBoxH20.Name = "TicketstextBoxH20";
            this.TicketstextBoxH20.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH20.TabIndex = 144;
            // 
            // TicketslabelH20
            // 
            this.TicketslabelH20.AutoSize = true;
            this.TicketslabelH20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH20.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH20.Location = new System.Drawing.Point(306, 327);
            this.TicketslabelH20.Name = "TicketslabelH20";
            this.TicketslabelH20.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH20.TabIndex = 143;
            this.TicketslabelH20.Text = "Tickets";
            // 
            // NotextBoxH20
            // 
            this.NotextBoxH20.Location = new System.Drawing.Point(414, 176);
            this.NotextBoxH20.Name = "NotextBoxH20";
            this.NotextBoxH20.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH20.TabIndex = 142;
            // 
            // NolabelH20
            // 
            this.NolabelH20.AutoSize = true;
            this.NolabelH20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH20.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH20.Location = new System.Drawing.Point(306, 165);
            this.NolabelH20.Name = "NolabelH20";
            this.NolabelH20.Size = new System.Drawing.Size(49, 31);
            this.NolabelH20.TabIndex = 141;
            this.NolabelH20.Text = "No";
            // 
            // EmailtextBoxH20
            // 
            this.EmailtextBoxH20.Location = new System.Drawing.Point(414, 232);
            this.EmailtextBoxH20.Name = "EmailtextBoxH20";
            this.EmailtextBoxH20.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH20.TabIndex = 140;
            // 
            // EmaillabelH20
            // 
            this.EmaillabelH20.AutoSize = true;
            this.EmaillabelH20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH20.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH20.Location = new System.Drawing.Point(306, 221);
            this.EmaillabelH20.Name = "EmaillabelH20";
            this.EmaillabelH20.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH20.TabIndex = 139;
            this.EmaillabelH20.Text = "Email";
            // 
            // GendertextBoxH20
            // 
            this.GendertextBoxH20.Location = new System.Drawing.Point(414, 284);
            this.GendertextBoxH20.Name = "GendertextBoxH20";
            this.GendertextBoxH20.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH20.TabIndex = 138;
            // 
            // GenderlabelH20
            // 
            this.GenderlabelH20.AutoSize = true;
            this.GenderlabelH20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH20.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH20.Location = new System.Drawing.Point(306, 273);
            this.GenderlabelH20.Name = "GenderlabelH20";
            this.GenderlabelH20.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH20.TabIndex = 137;
            this.GenderlabelH20.Text = "Gender";
            // 
            // NametextBoxH20
            // 
            this.NametextBoxH20.Location = new System.Drawing.Point(414, 121);
            this.NametextBoxH20.Name = "NametextBoxH20";
            this.NametextBoxH20.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH20.TabIndex = 136;
            // 
            // NamelabelH20
            // 
            this.NamelabelH20.AutoSize = true;
            this.NamelabelH20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH20.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH20.Location = new System.Drawing.Point(306, 110);
            this.NamelabelH20.Name = "NamelabelH20";
            this.NamelabelH20.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH20.TabIndex = 135;
            this.NamelabelH20.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 134;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHSUm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1252, 698);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH20);
            this.Controls.Add(this.AddresstextBoxH20);
            this.Controls.Add(this.AddresslabelH20);
            this.Controls.Add(this.TicketstextBoxH20);
            this.Controls.Add(this.TicketslabelH20);
            this.Controls.Add(this.NotextBoxH20);
            this.Controls.Add(this.NolabelH20);
            this.Controls.Add(this.EmailtextBoxH20);
            this.Controls.Add(this.EmaillabelH20);
            this.Controls.Add(this.GendertextBoxH20);
            this.Controls.Add(this.GenderlabelH20);
            this.Controls.Add(this.NametextBoxH20);
            this.Controls.Add(this.NamelabelH20);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHSUm2";
            this.Text = "BHSUm2";
            this.Load += new System.EventHandler(this.BHSUm2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH20;
        private System.Windows.Forms.TextBox AddresstextBoxH20;
        private System.Windows.Forms.Label AddresslabelH20;
        private System.Windows.Forms.TextBox TicketstextBoxH20;
        private System.Windows.Forms.Label TicketslabelH20;
        private System.Windows.Forms.TextBox NotextBoxH20;
        private System.Windows.Forms.Label NolabelH20;
        private System.Windows.Forms.TextBox EmailtextBoxH20;
        private System.Windows.Forms.Label EmaillabelH20;
        private System.Windows.Forms.TextBox GendertextBoxH20;
        private System.Windows.Forms.Label GenderlabelH20;
        private System.Windows.Forms.TextBox NametextBoxH20;
        private System.Windows.Forms.Label NamelabelH20;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}