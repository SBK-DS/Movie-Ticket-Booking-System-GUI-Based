﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHTm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHTm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH4 = new System.Windows.Forms.Button();
            this.AddresstextBoxH4 = new System.Windows.Forms.TextBox();
            this.AddresslabelH4 = new System.Windows.Forms.Label();
            this.TicketstextBoxH4 = new System.Windows.Forms.TextBox();
            this.TicketslabelH4 = new System.Windows.Forms.Label();
            this.NotextBoxH4 = new System.Windows.Forms.TextBox();
            this.NolabelH4 = new System.Windows.Forms.Label();
            this.EmailtextBoxH4 = new System.Windows.Forms.TextBox();
            this.EmaillabelH4 = new System.Windows.Forms.Label();
            this.GendertextBoxH4 = new System.Windows.Forms.TextBox();
            this.GenderlabelH4 = new System.Windows.Forms.Label();
            this.NametextBoxH4 = new System.Windows.Forms.TextBox();
            this.NamelabelH4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1203, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 103;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH4
            // 
            this.RegisterH4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH4.Location = new System.Drawing.Point(480, 523);
            this.RegisterH4.Name = "RegisterH4";
            this.RegisterH4.Size = new System.Drawing.Size(286, 83);
            this.RegisterH4.TabIndex = 102;
            this.RegisterH4.Text = "Register";
            this.RegisterH4.UseVisualStyleBackColor = true;
            this.RegisterH4.Click += new System.EventHandler(this.RegisterH4_Click);
            // 
            // AddresstextBoxH4
            // 
            this.AddresstextBoxH4.Location = new System.Drawing.Point(421, 394);
            this.AddresstextBoxH4.Multiline = true;
            this.AddresstextBoxH4.Name = "AddresstextBoxH4";
            this.AddresstextBoxH4.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH4.TabIndex = 101;
            // 
            // AddresslabelH4
            // 
            this.AddresslabelH4.AutoSize = true;
            this.AddresslabelH4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH4.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH4.Location = new System.Drawing.Point(313, 382);
            this.AddresslabelH4.Name = "AddresslabelH4";
            this.AddresslabelH4.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH4.TabIndex = 100;
            this.AddresslabelH4.Text = "Add";
            // 
            // TicketstextBoxH4
            // 
            this.TicketstextBoxH4.Location = new System.Drawing.Point(421, 338);
            this.TicketstextBoxH4.Name = "TicketstextBoxH4";
            this.TicketstextBoxH4.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH4.TabIndex = 99;
            // 
            // TicketslabelH4
            // 
            this.TicketslabelH4.AutoSize = true;
            this.TicketslabelH4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH4.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH4.Location = new System.Drawing.Point(313, 327);
            this.TicketslabelH4.Name = "TicketslabelH4";
            this.TicketslabelH4.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH4.TabIndex = 98;
            this.TicketslabelH4.Text = "Tickets";
            // 
            // NotextBoxH4
            // 
            this.NotextBoxH4.Location = new System.Drawing.Point(421, 176);
            this.NotextBoxH4.Name = "NotextBoxH4";
            this.NotextBoxH4.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH4.TabIndex = 97;
            // 
            // NolabelH4
            // 
            this.NolabelH4.AutoSize = true;
            this.NolabelH4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH4.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH4.Location = new System.Drawing.Point(313, 165);
            this.NolabelH4.Name = "NolabelH4";
            this.NolabelH4.Size = new System.Drawing.Size(49, 31);
            this.NolabelH4.TabIndex = 96;
            this.NolabelH4.Text = "No";
            // 
            // EmailtextBoxH4
            // 
            this.EmailtextBoxH4.Location = new System.Drawing.Point(421, 232);
            this.EmailtextBoxH4.Name = "EmailtextBoxH4";
            this.EmailtextBoxH4.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH4.TabIndex = 95;
            // 
            // EmaillabelH4
            // 
            this.EmaillabelH4.AutoSize = true;
            this.EmaillabelH4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH4.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH4.Location = new System.Drawing.Point(313, 221);
            this.EmaillabelH4.Name = "EmaillabelH4";
            this.EmaillabelH4.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH4.TabIndex = 94;
            this.EmaillabelH4.Text = "Email";
            // 
            // GendertextBoxH4
            // 
            this.GendertextBoxH4.Location = new System.Drawing.Point(421, 284);
            this.GendertextBoxH4.Name = "GendertextBoxH4";
            this.GendertextBoxH4.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH4.TabIndex = 93;
            // 
            // GenderlabelH4
            // 
            this.GenderlabelH4.AutoSize = true;
            this.GenderlabelH4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH4.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH4.Location = new System.Drawing.Point(313, 273);
            this.GenderlabelH4.Name = "GenderlabelH4";
            this.GenderlabelH4.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH4.TabIndex = 92;
            this.GenderlabelH4.Text = "Gender";
            // 
            // NametextBoxH4
            // 
            this.NametextBoxH4.Location = new System.Drawing.Point(421, 121);
            this.NametextBoxH4.Name = "NametextBoxH4";
            this.NametextBoxH4.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH4.TabIndex = 91;
            // 
            // NamelabelH4
            // 
            this.NamelabelH4.AutoSize = true;
            this.NamelabelH4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH4.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH4.Location = new System.Drawing.Point(313, 110);
            this.NamelabelH4.Name = "NamelabelH4";
            this.NamelabelH4.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH4.TabIndex = 90;
            this.NamelabelH4.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHTm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1259, 704);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH4);
            this.Controls.Add(this.AddresstextBoxH4);
            this.Controls.Add(this.AddresslabelH4);
            this.Controls.Add(this.TicketstextBoxH4);
            this.Controls.Add(this.TicketslabelH4);
            this.Controls.Add(this.NotextBoxH4);
            this.Controls.Add(this.NolabelH4);
            this.Controls.Add(this.EmailtextBoxH4);
            this.Controls.Add(this.EmaillabelH4);
            this.Controls.Add(this.GendertextBoxH4);
            this.Controls.Add(this.GenderlabelH4);
            this.Controls.Add(this.NametextBoxH4);
            this.Controls.Add(this.NamelabelH4);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHTm1";
            this.Text = "HBTm1";
            this.Load += new System.EventHandler(this.BHTm1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH4;
        private System.Windows.Forms.TextBox AddresstextBoxH4;
        private System.Windows.Forms.Label AddresslabelH4;
        private System.Windows.Forms.TextBox TicketstextBoxH4;
        private System.Windows.Forms.Label TicketslabelH4;
        private System.Windows.Forms.TextBox NotextBoxH4;
        private System.Windows.Forms.Label NolabelH4;
        private System.Windows.Forms.TextBox EmailtextBoxH4;
        private System.Windows.Forms.Label EmaillabelH4;
        private System.Windows.Forms.TextBox GendertextBoxH4;
        private System.Windows.Forms.Label GenderlabelH4;
        private System.Windows.Forms.TextBox NametextBoxH4;
        private System.Windows.Forms.Label NamelabelH4;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}