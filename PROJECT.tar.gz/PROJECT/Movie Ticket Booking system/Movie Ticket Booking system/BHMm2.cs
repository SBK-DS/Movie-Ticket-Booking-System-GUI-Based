﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Movie_Ticket_Booking_system
{
    public partial class BHMm2 : Form
    {


        public static string name_copy;
        public static string No_copy;
        public static string email_copy;
        public static string gender_copy;
        public static int Tickets_copy;
        public static string address_copy;
        public static string Day_copy;
        public static string Movie_copy;
        public static int Amount_copy;
        public static int Total_copy;
        public static string timing_copy;
        public static string DT_copy;
        public static int Book_ID;




        public BHMm2()
        {
            InitializeComponent();
        }



        class Registeration
        {

            private string name;
            private string No;
            private string email;
            private string gender;
            private int Tickets;
            private string address;
            private string Day;
            private string Movie;
            private int Amount;
            private int Total;
            private string timing;
            private string DT;


            public void Set_name(string name)
            {
                this.name = name;
            }
            public void Set_No(string No)
            {
                this.No = No;
            }
            public void Set_Email(string email)
            {
                this.email = email;
            }
            public void Set_Gender(string gender)
            {
                this.gender = gender;
            }
            public void Set_Tickets(int Tickets)
            {
                this.Tickets = Tickets;
            }
            public void Set_Address(string address)
            {
                this.address = address;
            }
            public void Set_Day(string Day)
            {
                this.Day = Day;
            }
            public void Set_Movie(string Movie)
            {
                this.Movie = Movie;
            }
            public void Set_Amount(int Amount)
            {
                this.Amount = Amount;
            }

            public void Set_Total(int Total)
            {
                this.Total = Total;
            }

            public void Set_Time(string time)
            {
                this.timing = time;
            }

            public void Set_DateTime(string Dt)
            {
                this.DT = Dt;
            }

            public string Get_name()
            {
                return name;
            }
            public string Get_No()
            {
                return No;
            }
            public string Get_Email()
            {
                return email;
            }
            public string Get_Gender()
            {
                return gender;
            }
            public int Get_Tickets()
            {
                return Tickets;
            }
            public string Get_Address()
            {
                return address;
            }
            public string Get_Day()
            {
                return Day;
            }
            public string Get_Movie()
            {
                return Movie;
            }
            public int Get_Amount()
            {
                return Amount;
            }
            public int Get_Total()
            {
                return Total;
            }
            public string Get_Time()
            {
                return timing;
            }
            public string Get_DateTime()
            {
                return DT;
            }
        }


        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-UAV1AAR\SQLEXPRESS;Initial Catalog=OOPDATABASE;Integrated Security=True");




        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void RegisterH2_Click(object sender, EventArgs e)
        {
            if (NametextBoxH2.Text == string.Empty)
            {
                MessageBox.Show("error", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (checktickets() == false)
                {
                    MessageBox.Show("Sorry registrations are closed");
                }

                else

                {


                    Registeration Customer = new Registeration();
                    int bill = 0;
                    string Movie_name = null, Day_name = "Monday";
                    Customer.Set_name(NametextBoxH2.Text);
                    Customer.Set_No(NotextBoxH2.Text);
                    Customer.Set_Email(EmailtextBoxH2.Text);
                    Customer.Set_Gender(GendertextBoxH2.Text);
                    Customer.Set_Tickets(int.Parse(TicketstextBoxH2.Text));
                    Customer.Set_Address(AddresstextBoxH2.Text);
                    Customer.Set_Day(Day_name);


                    DateTime Current = DateTime.Now;
                    Customer.Set_DateTime(Current.ToString());

                    con.Open();
                    SqlCommand MN = new SqlCommand("SELECT Name FROM TicketsDetails WHERE Category=2 and Day=1 and Movie=2", con);
                    SqlDataReader da_MN = MN.ExecuteReader();
                    while (da_MN.Read())
                    {
                        Movie_name = da_MN.GetValue(0).ToString();
                    }
                    con.Close();

                    Customer.Set_Movie(Movie_name);
                    con.Open();
                    SqlCommand Tic = new SqlCommand("SELECT Amount FROM TicketsDetails WHERE Category=2 and Day=1 and Movie=2", con);
                    SqlDataReader da = Tic.ExecuteReader();
                    int Am = 0;
                    while (da.Read())
                    {
                        Am = int.Parse(da.GetValue(0).ToString());
                    }
                    con.Close();
                    Customer.Set_Amount(Am);


                    con.Open();
                    SqlCommand time = new SqlCommand("SELECT Timing FROM TicketsDetails WHERE Category=2 and Day=1 and Movie=2", con);
                    SqlDataReader da_time = time.ExecuteReader();
                    string Timing = null;
                    while (da_time.Read())
                    {
                        Timing = da_time.GetValue(0).ToString();
                    }
                    con.Close();
                    Customer.Set_Time(Timing.ToString());

                    MessageBox.Show(Timing);

                    SqlCommand cmd = new SqlCommand("INSERT INTO HollywoodRegisterations (Name, No, Email, Gender,Tickets, Address, Day, Movie, Bill, Time, Date) VALUES (@NamelabelH2, @NolabelH2, @EmaillabelH2, @GenderlabelH2, @TicketslabelH2, @AddresslabelH2, @day, @mov, @amount, @Tim, @date)", con);
                    cmd.CommandType = CommandType.Text;
                    bill += (Customer.Get_Amount()) * (int.Parse(TicketstextBoxH2.Text));
                    Customer.Set_Total(bill);
                    cmd.Parameters.AddWithValue("@NamelabelH2", Customer.Get_name());
                    cmd.Parameters.AddWithValue("@NolabelH2", Customer.Get_No());
                    cmd.Parameters.AddWithValue("@EmaillabelH2", Customer.Get_Email());
                    cmd.Parameters.AddWithValue("@GenderlabelH2", Customer.Get_Gender());
                    cmd.Parameters.AddWithValue("@TicketslabelH2", Customer.Get_Tickets());
                    cmd.Parameters.AddWithValue("@AddresslabelH2", Customer.Get_Address());
                    cmd.Parameters.AddWithValue("@day", Customer.Get_Day());
                    cmd.Parameters.AddWithValue("@mov", Customer.Get_Movie());
                    cmd.Parameters.AddWithValue("@amount", Customer.Get_Total());
                    cmd.Parameters.AddWithValue("@Tim", Customer.Get_Time());
                    cmd.Parameters.AddWithValue("@date", Customer.Get_DateTime());


                    int tickets = int.Parse(TicketstextBoxH2.Text);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    con.Open();
                    SqlCommand cmd1 = new SqlCommand("SELECT Tickets FROM TicketsDetails WHERE Category=2 and Day=1 and Movie=2", con);
                    SqlDataReader DA = cmd1.ExecuteReader();
                    int NewTickets = 0;
                    while (DA.Read())
                    {
                        NewTickets = int.Parse(DA.GetValue(0).ToString());
                    }

                    int enteredTic = int.Parse(TicketstextBoxH2.Text);

                    NewTickets -= enteredTic;
                    MessageBox.Show(NewTickets.ToString());
                    con.Close();

                    con.Open();
                    SqlCommand cmd2 = new SqlCommand("UPDATE TicketsDetails SET Tickets = @NewTickets WHERE Category=2 and Day=1 and Movie=2", con);
                    cmd2.Parameters.AddWithValue("@NewTickets", NewTickets);
                    cmd2.ExecuteNonQuery();
                    con.Close();



                    int booking_id = 0;

                    con.Open();
                    SqlCommand DR = new SqlCommand("SELECT ID FROM HollywoodRegisterations WHERE Name = @na and No = @no and Email = @Em and Gender = @Gen and Tickets = @Tc and Address = @ad and Day = @da and Movie = @mv and Bill = @bl and Time = @tm and Date = @de", con);
                    DR.Parameters.AddWithValue("@na", Customer.Get_name());
                    DR.Parameters.AddWithValue("@no", Customer.Get_No());
                    DR.Parameters.AddWithValue("@Em", Customer.Get_Email());
                    DR.Parameters.AddWithValue("@Gen", Customer.Get_Gender());
                    DR.Parameters.AddWithValue("@Tc", Customer.Get_Tickets());
                    DR.Parameters.AddWithValue("@ad", Customer.Get_Address());
                    DR.Parameters.AddWithValue("@da", Customer.Get_Day());
                    DR.Parameters.AddWithValue("@mv", Customer.Get_Movie());
                    DR.Parameters.AddWithValue("@Bl", Customer.Get_Total());
                    DR.Parameters.AddWithValue("@tm", Customer.Get_Time());
                    DR.Parameters.AddWithValue("@de", Customer.Get_DateTime());
                    SqlDataReader RDR = DR.ExecuteReader();

                    while (RDR.Read())
                    {
                        booking_id = int.Parse(RDR.GetValue(0).ToString());
                    }
                    con.Close();

                    MessageBox.Show(booking_id.ToString());

                    name_copy = Customer.Get_name();
                    No_copy = Customer.Get_No();
                    email_copy = Customer.Get_Email();
                    gender_copy = Customer.Get_Gender();
                    Tickets_copy = Customer.Get_Tickets();
                    address_copy = Customer.Get_Address();
                    Day_copy = Customer.Get_Day();
                    Movie_copy = Customer.Get_Movie();
                    Amount_copy = Customer.Get_Total();
                    timing_copy = Customer.Get_Time();
                    DT_copy = Customer.Get_DateTime();
                    Book_ID = booking_id;


                    ShowReservation_BHMm2 SBHMM2 = new ShowReservation_BHMm2();
                    SBHMM2.ShowDialog();






                }
            }

        }
        private bool checktickets()
        {
            con.Open();
            SqlCommand cmd1 = new SqlCommand("SELECT Tickets FROM TicketsDetails WHERE Category=2 and Day=1 and Movie=2", con);
            SqlDataReader DA = cmd1.ExecuteReader();
            int NewTickets = 0;
            while (DA.Read())
            {
                NewTickets = int.Parse(DA.GetValue(0).ToString());
            }

            int enteredTic = int.Parse(TicketstextBoxH2.Text);

            NewTickets -= enteredTic;
            con.Close();

            if (NewTickets <= 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        private void BHMm2_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booking_Hollywood_Monday B = new Booking_Hollywood_Monday();
            B.ShowDialog();
        }
    }
    }
