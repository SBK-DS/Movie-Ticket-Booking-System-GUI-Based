﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHMm3 : Form
    {
        public ShowReservation_BHMm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHMm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHMm3.Book_ID.ToString();
            textBox2.Text = BHMm3.name_copy;
            textBox3.Text = BHMm3.No_copy;
            textBox4.Text = BHMm3.email_copy;
            textBox5.Text = BHMm3.gender_copy;
            textBox6.Text = BHMm3.Tickets_copy.ToString();
            textBox7.Text = BHMm3.Day_copy;
            textBox8.Text = BHMm3.Movie_copy;
            textBox9.Text = BHMm3.Amount_copy.ToString();
            textBox10.Text = BHMm3.timing_copy;
            textBox11.Text = BHMm3.address_copy;
            textBox12.Text = BHMm3.DT_copy;
        }
    }
}
