﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHTHm3 : Form
    {
        public ShowReservation_BHTHm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHTHm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHTHm3.Book_ID.ToString();
            textBox2.Text = BHTHm3.name_copy;
            textBox3.Text = BHTHm3.No_copy;
            textBox4.Text = BHTHm3.email_copy;
            textBox5.Text = BHTHm3.gender_copy;
            textBox6.Text = BHTHm3.Tickets_copy.ToString();
            textBox7.Text = BHTHm3.Day_copy;
            textBox8.Text = BHTHm3.Movie_copy;
            textBox9.Text = BHTHm3.Amount_copy.ToString();
            textBox10.Text = BHTHm3.timing_copy;
            textBox11.Text = BHTHm3.address_copy;
            textBox12.Text = BHTHm3.DT_copy;
        }
    }
}
