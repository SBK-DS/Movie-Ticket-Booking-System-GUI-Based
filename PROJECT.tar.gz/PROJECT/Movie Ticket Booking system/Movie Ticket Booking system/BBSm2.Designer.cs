﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBSm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBSm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register16 = new System.Windows.Forms.Button();
            this.AddresstextBox16 = new System.Windows.Forms.TextBox();
            this.Addresslabel16 = new System.Windows.Forms.Label();
            this.TicketstextBox16 = new System.Windows.Forms.TextBox();
            this.Ticketslabel16 = new System.Windows.Forms.Label();
            this.NotextBox16 = new System.Windows.Forms.TextBox();
            this.Nolabel16 = new System.Windows.Forms.Label();
            this.EmailtextBox16 = new System.Windows.Forms.TextBox();
            this.Emaillabel16 = new System.Windows.Forms.Label();
            this.GendertextBox16 = new System.Windows.Forms.TextBox();
            this.Genderlabel16 = new System.Windows.Forms.Label();
            this.NametextBox16 = new System.Windows.Forms.TextBox();
            this.Namelabel16 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1203, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 205;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register16
            // 
            this.Register16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register16.Location = new System.Drawing.Point(482, 523);
            this.Register16.Name = "Register16";
            this.Register16.Size = new System.Drawing.Size(286, 83);
            this.Register16.TabIndex = 204;
            this.Register16.Text = "Register";
            this.Register16.UseVisualStyleBackColor = true;
            this.Register16.Click += new System.EventHandler(this.Register16_Click);
            // 
            // AddresstextBox16
            // 
            this.AddresstextBox16.Location = new System.Drawing.Point(423, 394);
            this.AddresstextBox16.Multiline = true;
            this.AddresstextBox16.Name = "AddresstextBox16";
            this.AddresstextBox16.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox16.TabIndex = 203;
            // 
            // Addresslabel16
            // 
            this.Addresslabel16.AutoSize = true;
            this.Addresslabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel16.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel16.Location = new System.Drawing.Point(315, 382);
            this.Addresslabel16.Name = "Addresslabel16";
            this.Addresslabel16.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel16.TabIndex = 202;
            this.Addresslabel16.Text = "Add";
            // 
            // TicketstextBox16
            // 
            this.TicketstextBox16.Location = new System.Drawing.Point(423, 338);
            this.TicketstextBox16.Name = "TicketstextBox16";
            this.TicketstextBox16.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox16.TabIndex = 201;
            // 
            // Ticketslabel16
            // 
            this.Ticketslabel16.AutoSize = true;
            this.Ticketslabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel16.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel16.Location = new System.Drawing.Point(315, 327);
            this.Ticketslabel16.Name = "Ticketslabel16";
            this.Ticketslabel16.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel16.TabIndex = 200;
            this.Ticketslabel16.Text = "Tickets";
            // 
            // NotextBox16
            // 
            this.NotextBox16.Location = new System.Drawing.Point(423, 176);
            this.NotextBox16.Name = "NotextBox16";
            this.NotextBox16.Size = new System.Drawing.Size(539, 20);
            this.NotextBox16.TabIndex = 199;
            // 
            // Nolabel16
            // 
            this.Nolabel16.AutoSize = true;
            this.Nolabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel16.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel16.Location = new System.Drawing.Point(315, 165);
            this.Nolabel16.Name = "Nolabel16";
            this.Nolabel16.Size = new System.Drawing.Size(49, 31);
            this.Nolabel16.TabIndex = 198;
            this.Nolabel16.Text = "No";
            // 
            // EmailtextBox16
            // 
            this.EmailtextBox16.Location = new System.Drawing.Point(423, 232);
            this.EmailtextBox16.Name = "EmailtextBox16";
            this.EmailtextBox16.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox16.TabIndex = 197;
            // 
            // Emaillabel16
            // 
            this.Emaillabel16.AutoSize = true;
            this.Emaillabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel16.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel16.Location = new System.Drawing.Point(315, 221);
            this.Emaillabel16.Name = "Emaillabel16";
            this.Emaillabel16.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel16.TabIndex = 196;
            this.Emaillabel16.Text = "Email";
            // 
            // GendertextBox16
            // 
            this.GendertextBox16.Location = new System.Drawing.Point(423, 284);
            this.GendertextBox16.Name = "GendertextBox16";
            this.GendertextBox16.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox16.TabIndex = 195;
            // 
            // Genderlabel16
            // 
            this.Genderlabel16.AutoSize = true;
            this.Genderlabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel16.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel16.Location = new System.Drawing.Point(315, 273);
            this.Genderlabel16.Name = "Genderlabel16";
            this.Genderlabel16.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel16.TabIndex = 194;
            this.Genderlabel16.Text = "Gender";
            // 
            // NametextBox16
            // 
            this.NametextBox16.Location = new System.Drawing.Point(423, 121);
            this.NametextBox16.Name = "NametextBox16";
            this.NametextBox16.Size = new System.Drawing.Size(539, 20);
            this.NametextBox16.TabIndex = 193;
            // 
            // Namelabel16
            // 
            this.Namelabel16.AutoSize = true;
            this.Namelabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel16.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel16.Location = new System.Drawing.Point(315, 109);
            this.Namelabel16.Name = "Namelabel16";
            this.Namelabel16.Size = new System.Drawing.Size(86, 31);
            this.Namelabel16.TabIndex = 192;
            this.Namelabel16.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 191;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBSm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1259, 703);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register16);
            this.Controls.Add(this.AddresstextBox16);
            this.Controls.Add(this.Addresslabel16);
            this.Controls.Add(this.TicketstextBox16);
            this.Controls.Add(this.Ticketslabel16);
            this.Controls.Add(this.NotextBox16);
            this.Controls.Add(this.Nolabel16);
            this.Controls.Add(this.EmailtextBox16);
            this.Controls.Add(this.Emaillabel16);
            this.Controls.Add(this.GendertextBox16);
            this.Controls.Add(this.Genderlabel16);
            this.Controls.Add(this.NametextBox16);
            this.Controls.Add(this.Namelabel16);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBSm2";
            this.Text = "BBSm2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register16;
        private System.Windows.Forms.TextBox AddresstextBox16;
        private System.Windows.Forms.Label Addresslabel16;
        private System.Windows.Forms.TextBox TicketstextBox16;
        private System.Windows.Forms.Label Ticketslabel16;
        private System.Windows.Forms.TextBox NotextBox16;
        private System.Windows.Forms.Label Nolabel16;
        private System.Windows.Forms.TextBox EmailtextBox16;
        private System.Windows.Forms.Label Emaillabel16;
        private System.Windows.Forms.TextBox GendertextBox16;
        private System.Windows.Forms.Label Genderlabel16;
        private System.Windows.Forms.TextBox NametextBox16;
        private System.Windows.Forms.Label Namelabel16;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}