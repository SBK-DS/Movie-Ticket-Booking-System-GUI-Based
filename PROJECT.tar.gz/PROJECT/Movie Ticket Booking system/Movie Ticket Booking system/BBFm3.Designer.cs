﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBFm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBFm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register14 = new System.Windows.Forms.Button();
            this.AddresstextBox14 = new System.Windows.Forms.TextBox();
            this.Addresslabel14 = new System.Windows.Forms.Label();
            this.TicketstextBox14 = new System.Windows.Forms.TextBox();
            this.Ticketslabel14 = new System.Windows.Forms.Label();
            this.NotextBox14 = new System.Windows.Forms.TextBox();
            this.Nolabel14 = new System.Windows.Forms.Label();
            this.EmailtextBox14 = new System.Windows.Forms.TextBox();
            this.Emaillabel14 = new System.Windows.Forms.Label();
            this.GendertextBox14 = new System.Windows.Forms.TextBox();
            this.Genderlabel14 = new System.Windows.Forms.Label();
            this.NametextBox14 = new System.Windows.Forms.TextBox();
            this.Namelabel14 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1200, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 190;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register14
            // 
            this.Register14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register14.Location = new System.Drawing.Point(479, 523);
            this.Register14.Name = "Register14";
            this.Register14.Size = new System.Drawing.Size(286, 83);
            this.Register14.TabIndex = 189;
            this.Register14.Text = "Register";
            this.Register14.UseVisualStyleBackColor = true;
            this.Register14.Click += new System.EventHandler(this.Register14_Click);
            // 
            // AddresstextBox14
            // 
            this.AddresstextBox14.Location = new System.Drawing.Point(420, 394);
            this.AddresstextBox14.Multiline = true;
            this.AddresstextBox14.Name = "AddresstextBox14";
            this.AddresstextBox14.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox14.TabIndex = 188;
            // 
            // Addresslabel14
            // 
            this.Addresslabel14.AutoSize = true;
            this.Addresslabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel14.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel14.Location = new System.Drawing.Point(312, 382);
            this.Addresslabel14.Name = "Addresslabel14";
            this.Addresslabel14.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel14.TabIndex = 187;
            this.Addresslabel14.Text = "Add";
            // 
            // TicketstextBox14
            // 
            this.TicketstextBox14.Location = new System.Drawing.Point(420, 338);
            this.TicketstextBox14.Name = "TicketstextBox14";
            this.TicketstextBox14.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox14.TabIndex = 186;
            // 
            // Ticketslabel14
            // 
            this.Ticketslabel14.AutoSize = true;
            this.Ticketslabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel14.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel14.Location = new System.Drawing.Point(312, 327);
            this.Ticketslabel14.Name = "Ticketslabel14";
            this.Ticketslabel14.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel14.TabIndex = 185;
            this.Ticketslabel14.Text = "Tickets";
            // 
            // NotextBox14
            // 
            this.NotextBox14.Location = new System.Drawing.Point(420, 176);
            this.NotextBox14.Name = "NotextBox14";
            this.NotextBox14.Size = new System.Drawing.Size(539, 20);
            this.NotextBox14.TabIndex = 184;
            // 
            // Nolabel14
            // 
            this.Nolabel14.AutoSize = true;
            this.Nolabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel14.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel14.Location = new System.Drawing.Point(312, 165);
            this.Nolabel14.Name = "Nolabel14";
            this.Nolabel14.Size = new System.Drawing.Size(49, 31);
            this.Nolabel14.TabIndex = 183;
            this.Nolabel14.Text = "No";
            // 
            // EmailtextBox14
            // 
            this.EmailtextBox14.Location = new System.Drawing.Point(420, 232);
            this.EmailtextBox14.Name = "EmailtextBox14";
            this.EmailtextBox14.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox14.TabIndex = 182;
            // 
            // Emaillabel14
            // 
            this.Emaillabel14.AutoSize = true;
            this.Emaillabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel14.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel14.Location = new System.Drawing.Point(312, 221);
            this.Emaillabel14.Name = "Emaillabel14";
            this.Emaillabel14.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel14.TabIndex = 181;
            this.Emaillabel14.Text = "Email";
            // 
            // GendertextBox14
            // 
            this.GendertextBox14.Location = new System.Drawing.Point(420, 284);
            this.GendertextBox14.Name = "GendertextBox14";
            this.GendertextBox14.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox14.TabIndex = 180;
            // 
            // Genderlabel14
            // 
            this.Genderlabel14.AutoSize = true;
            this.Genderlabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel14.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel14.Location = new System.Drawing.Point(312, 273);
            this.Genderlabel14.Name = "Genderlabel14";
            this.Genderlabel14.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel14.TabIndex = 179;
            this.Genderlabel14.Text = "Gender";
            // 
            // NametextBox14
            // 
            this.NametextBox14.Location = new System.Drawing.Point(420, 121);
            this.NametextBox14.Name = "NametextBox14";
            this.NametextBox14.Size = new System.Drawing.Size(539, 20);
            this.NametextBox14.TabIndex = 178;
            // 
            // Namelabel14
            // 
            this.Namelabel14.AutoSize = true;
            this.Namelabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel14.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel14.Location = new System.Drawing.Point(312, 109);
            this.Namelabel14.Name = "Namelabel14";
            this.Namelabel14.Size = new System.Drawing.Size(86, 31);
            this.Namelabel14.TabIndex = 177;
            this.Namelabel14.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 176;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBFm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1256, 701);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register14);
            this.Controls.Add(this.AddresstextBox14);
            this.Controls.Add(this.Addresslabel14);
            this.Controls.Add(this.TicketstextBox14);
            this.Controls.Add(this.Ticketslabel14);
            this.Controls.Add(this.NotextBox14);
            this.Controls.Add(this.Nolabel14);
            this.Controls.Add(this.EmailtextBox14);
            this.Controls.Add(this.Emaillabel14);
            this.Controls.Add(this.GendertextBox14);
            this.Controls.Add(this.Genderlabel14);
            this.Controls.Add(this.NametextBox14);
            this.Controls.Add(this.Namelabel14);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBFm3";
            this.Text = "BBFm3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register14;
        private System.Windows.Forms.TextBox AddresstextBox14;
        private System.Windows.Forms.Label Addresslabel14;
        private System.Windows.Forms.TextBox TicketstextBox14;
        private System.Windows.Forms.Label Ticketslabel14;
        private System.Windows.Forms.TextBox NotextBox14;
        private System.Windows.Forms.Label Nolabel14;
        private System.Windows.Forms.TextBox EmailtextBox14;
        private System.Windows.Forms.Label Emaillabel14;
        private System.Windows.Forms.TextBox GendertextBox14;
        private System.Windows.Forms.Label Genderlabel14;
        private System.Windows.Forms.TextBox NametextBox14;
        private System.Windows.Forms.Label Namelabel14;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}