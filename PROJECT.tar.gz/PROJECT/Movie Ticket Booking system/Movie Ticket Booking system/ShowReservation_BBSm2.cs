﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBSm2 : Form
    {
        public ShowReservation_BBSm2()
        {
            InitializeComponent();
        }

        private void ShowReservatio_BBSm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBSm2.Book_ID.ToString();
            textBox2.Text = BBSm2.name_copy;
            textBox3.Text = BBSm2.No_copy;
            textBox4.Text = BBSm2.email_copy;
            textBox5.Text = BBSm2.gender_copy;
            textBox6.Text = BBSm2.Tickets_copy.ToString();
            textBox7.Text = BBSm2.Day_copy;
            textBox8.Text = BBSm2.Movie_copy;
            textBox9.Text = BBSm2.Amount_copy.ToString();
            textBox10.Text = BBSm2.timing_copy;
            textBox11.Text = BBSm2.address_copy;
            textBox12.Text = BBSm2.DT_copy;
        }
    }
}
