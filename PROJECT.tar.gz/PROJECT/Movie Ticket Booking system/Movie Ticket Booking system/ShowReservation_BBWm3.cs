﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBWm3 : Form
    {
        public ShowReservation_BBWm3()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBWm3_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBWm3.Book_ID.ToString();
            textBox2.Text = BBWm3.name_copy;
            textBox3.Text = BBWm3.No_copy;
            textBox4.Text = BBWm3.email_copy;
            textBox5.Text = BBWm3.gender_copy;
            textBox6.Text = BBWm3.Tickets_copy.ToString();
            textBox7.Text = BBWm3.Day_copy;
            textBox8.Text = BBWm3.Movie_copy;
            textBox9.Text = BBWm3.Amount_copy.ToString();
            textBox10.Text = BBWm3.timing_copy;
            textBox11.Text = BBWm3.address_copy;
            textBox12.Text = BBWm3.DT_copy;
        }
    }
}
