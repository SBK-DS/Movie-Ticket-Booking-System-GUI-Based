﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BHTHm2 : Form
    {
        public ShowReservation_BHTHm2()
        {
            InitializeComponent();
        }

        private void ShowReservation_BHTHm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BHTHm2.Book_ID.ToString();
            textBox2.Text = BHTHm2.name_copy;
            textBox3.Text = BHTHm2.No_copy;
            textBox4.Text = BHTHm2.email_copy;
            textBox5.Text = BHTHm2.gender_copy;
            textBox6.Text = BHTHm2.Tickets_copy.ToString();
            textBox7.Text = BHTHm2.Day_copy;
            textBox8.Text = BHTHm2.Movie_copy;
            textBox9.Text = BHTHm2.Amount_copy.ToString();
            textBox10.Text = BHTHm2.timing_copy;
            textBox11.Text = BHTHm2.address_copy;
            textBox12.Text = BHTHm2.DT_copy;
        }
    }
}
