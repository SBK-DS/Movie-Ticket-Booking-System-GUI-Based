﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBFm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBFm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register13 = new System.Windows.Forms.Button();
            this.AddresstextBox13 = new System.Windows.Forms.TextBox();
            this.Addresslabel13 = new System.Windows.Forms.Label();
            this.TicketstextBox13 = new System.Windows.Forms.TextBox();
            this.Ticketslabel13 = new System.Windows.Forms.Label();
            this.NotextBox13 = new System.Windows.Forms.TextBox();
            this.Nolabel13 = new System.Windows.Forms.Label();
            this.EmailtextBox13 = new System.Windows.Forms.TextBox();
            this.Emaillabel13 = new System.Windows.Forms.Label();
            this.GendertextBox13 = new System.Windows.Forms.TextBox();
            this.Genderlabel13 = new System.Windows.Forms.Label();
            this.NametextBox13 = new System.Windows.Forms.TextBox();
            this.Namelabel13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1199, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 175;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register13
            // 
            this.Register13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register13.Location = new System.Drawing.Point(478, 523);
            this.Register13.Name = "Register13";
            this.Register13.Size = new System.Drawing.Size(286, 83);
            this.Register13.TabIndex = 174;
            this.Register13.Text = "Register";
            this.Register13.UseVisualStyleBackColor = true;
            this.Register13.Click += new System.EventHandler(this.Register13_Click);
            // 
            // AddresstextBox13
            // 
            this.AddresstextBox13.Location = new System.Drawing.Point(419, 394);
            this.AddresstextBox13.Multiline = true;
            this.AddresstextBox13.Name = "AddresstextBox13";
            this.AddresstextBox13.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox13.TabIndex = 173;
            // 
            // Addresslabel13
            // 
            this.Addresslabel13.AutoSize = true;
            this.Addresslabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel13.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel13.Location = new System.Drawing.Point(311, 382);
            this.Addresslabel13.Name = "Addresslabel13";
            this.Addresslabel13.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel13.TabIndex = 172;
            this.Addresslabel13.Text = "Add";
            // 
            // TicketstextBox13
            // 
            this.TicketstextBox13.Location = new System.Drawing.Point(419, 338);
            this.TicketstextBox13.Name = "TicketstextBox13";
            this.TicketstextBox13.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox13.TabIndex = 171;
            // 
            // Ticketslabel13
            // 
            this.Ticketslabel13.AutoSize = true;
            this.Ticketslabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel13.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel13.Location = new System.Drawing.Point(311, 327);
            this.Ticketslabel13.Name = "Ticketslabel13";
            this.Ticketslabel13.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel13.TabIndex = 170;
            this.Ticketslabel13.Text = "Tickets";
            // 
            // NotextBox13
            // 
            this.NotextBox13.Location = new System.Drawing.Point(419, 176);
            this.NotextBox13.Name = "NotextBox13";
            this.NotextBox13.Size = new System.Drawing.Size(539, 20);
            this.NotextBox13.TabIndex = 169;
            // 
            // Nolabel13
            // 
            this.Nolabel13.AutoSize = true;
            this.Nolabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel13.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel13.Location = new System.Drawing.Point(311, 165);
            this.Nolabel13.Name = "Nolabel13";
            this.Nolabel13.Size = new System.Drawing.Size(49, 31);
            this.Nolabel13.TabIndex = 168;
            this.Nolabel13.Text = "No";
            // 
            // EmailtextBox13
            // 
            this.EmailtextBox13.Location = new System.Drawing.Point(419, 232);
            this.EmailtextBox13.Name = "EmailtextBox13";
            this.EmailtextBox13.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox13.TabIndex = 167;
            // 
            // Emaillabel13
            // 
            this.Emaillabel13.AutoSize = true;
            this.Emaillabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel13.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel13.Location = new System.Drawing.Point(311, 221);
            this.Emaillabel13.Name = "Emaillabel13";
            this.Emaillabel13.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel13.TabIndex = 166;
            this.Emaillabel13.Text = "Email";
            // 
            // GendertextBox13
            // 
            this.GendertextBox13.Location = new System.Drawing.Point(419, 284);
            this.GendertextBox13.Name = "GendertextBox13";
            this.GendertextBox13.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox13.TabIndex = 165;
            // 
            // Genderlabel13
            // 
            this.Genderlabel13.AutoSize = true;
            this.Genderlabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel13.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel13.Location = new System.Drawing.Point(311, 273);
            this.Genderlabel13.Name = "Genderlabel13";
            this.Genderlabel13.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel13.TabIndex = 164;
            this.Genderlabel13.Text = "Gender";
            // 
            // NametextBox13
            // 
            this.NametextBox13.Location = new System.Drawing.Point(419, 121);
            this.NametextBox13.Name = "NametextBox13";
            this.NametextBox13.Size = new System.Drawing.Size(539, 20);
            this.NametextBox13.TabIndex = 163;
            // 
            // Namelabel13
            // 
            this.Namelabel13.AutoSize = true;
            this.Namelabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel13.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel13.Location = new System.Drawing.Point(311, 109);
            this.Namelabel13.Name = "Namelabel13";
            this.Namelabel13.Size = new System.Drawing.Size(86, 31);
            this.Namelabel13.TabIndex = 162;
            this.Namelabel13.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 161;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBFm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1255, 701);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register13);
            this.Controls.Add(this.AddresstextBox13);
            this.Controls.Add(this.Addresslabel13);
            this.Controls.Add(this.TicketstextBox13);
            this.Controls.Add(this.Ticketslabel13);
            this.Controls.Add(this.NotextBox13);
            this.Controls.Add(this.Nolabel13);
            this.Controls.Add(this.EmailtextBox13);
            this.Controls.Add(this.Emaillabel13);
            this.Controls.Add(this.GendertextBox13);
            this.Controls.Add(this.Genderlabel13);
            this.Controls.Add(this.NametextBox13);
            this.Controls.Add(this.Namelabel13);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBFm2";
            this.Text = "BBFm2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register13;
        private System.Windows.Forms.TextBox AddresstextBox13;
        private System.Windows.Forms.Label Addresslabel13;
        private System.Windows.Forms.TextBox TicketstextBox13;
        private System.Windows.Forms.Label Ticketslabel13;
        private System.Windows.Forms.TextBox NotextBox13;
        private System.Windows.Forms.Label Nolabel13;
        private System.Windows.Forms.TextBox EmailtextBox13;
        private System.Windows.Forms.Label Emaillabel13;
        private System.Windows.Forms.TextBox GendertextBox13;
        private System.Windows.Forms.Label Genderlabel13;
        private System.Windows.Forms.TextBox NametextBox13;
        private System.Windows.Forms.Label Namelabel13;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}