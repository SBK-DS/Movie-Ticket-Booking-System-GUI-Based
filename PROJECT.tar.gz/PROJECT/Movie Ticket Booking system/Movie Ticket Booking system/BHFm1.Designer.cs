﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHFm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHFm1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH13 = new System.Windows.Forms.Button();
            this.AddresstextBoxH13 = new System.Windows.Forms.TextBox();
            this.AddresslabelH13 = new System.Windows.Forms.Label();
            this.TicketstextBoxH13 = new System.Windows.Forms.TextBox();
            this.TicketslabelH13 = new System.Windows.Forms.Label();
            this.NotextBoxH13 = new System.Windows.Forms.TextBox();
            this.NolabelH13 = new System.Windows.Forms.Label();
            this.EmailtextBoxH13 = new System.Windows.Forms.TextBox();
            this.EmaillabelH13 = new System.Windows.Forms.Label();
            this.GendertextBoxH13 = new System.Windows.Forms.TextBox();
            this.GenderlabelH13 = new System.Windows.Forms.Label();
            this.NametextBoxH13 = new System.Windows.Forms.TextBox();
            this.NamelabelH13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1202, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 133;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH13
            // 
            this.RegisterH13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH13.Location = new System.Drawing.Point(479, 523);
            this.RegisterH13.Name = "RegisterH13";
            this.RegisterH13.Size = new System.Drawing.Size(286, 83);
            this.RegisterH13.TabIndex = 132;
            this.RegisterH13.Text = "Register";
            this.RegisterH13.UseVisualStyleBackColor = true;
            this.RegisterH13.Click += new System.EventHandler(this.RegisterH13_Click);
            // 
            // AddresstextBoxH13
            // 
            this.AddresstextBoxH13.Location = new System.Drawing.Point(420, 394);
            this.AddresstextBoxH13.Multiline = true;
            this.AddresstextBoxH13.Name = "AddresstextBoxH13";
            this.AddresstextBoxH13.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH13.TabIndex = 131;
            // 
            // AddresslabelH13
            // 
            this.AddresslabelH13.AutoSize = true;
            this.AddresslabelH13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH13.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH13.Location = new System.Drawing.Point(312, 382);
            this.AddresslabelH13.Name = "AddresslabelH13";
            this.AddresslabelH13.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH13.TabIndex = 130;
            this.AddresslabelH13.Text = "Add";
            // 
            // TicketstextBoxH13
            // 
            this.TicketstextBoxH13.Location = new System.Drawing.Point(420, 338);
            this.TicketstextBoxH13.Name = "TicketstextBoxH13";
            this.TicketstextBoxH13.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH13.TabIndex = 129;
            // 
            // TicketslabelH13
            // 
            this.TicketslabelH13.AutoSize = true;
            this.TicketslabelH13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH13.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH13.Location = new System.Drawing.Point(312, 327);
            this.TicketslabelH13.Name = "TicketslabelH13";
            this.TicketslabelH13.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH13.TabIndex = 128;
            this.TicketslabelH13.Text = "Tickets";
            // 
            // NotextBoxH13
            // 
            this.NotextBoxH13.Location = new System.Drawing.Point(420, 176);
            this.NotextBoxH13.Name = "NotextBoxH13";
            this.NotextBoxH13.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH13.TabIndex = 127;
            // 
            // NolabelH13
            // 
            this.NolabelH13.AutoSize = true;
            this.NolabelH13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH13.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH13.Location = new System.Drawing.Point(312, 165);
            this.NolabelH13.Name = "NolabelH13";
            this.NolabelH13.Size = new System.Drawing.Size(49, 31);
            this.NolabelH13.TabIndex = 126;
            this.NolabelH13.Text = "No";
            // 
            // EmailtextBoxH13
            // 
            this.EmailtextBoxH13.Location = new System.Drawing.Point(420, 232);
            this.EmailtextBoxH13.Name = "EmailtextBoxH13";
            this.EmailtextBoxH13.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH13.TabIndex = 125;
            // 
            // EmaillabelH13
            // 
            this.EmaillabelH13.AutoSize = true;
            this.EmaillabelH13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH13.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH13.Location = new System.Drawing.Point(312, 221);
            this.EmaillabelH13.Name = "EmaillabelH13";
            this.EmaillabelH13.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH13.TabIndex = 124;
            this.EmaillabelH13.Text = "Email";
            // 
            // GendertextBoxH13
            // 
            this.GendertextBoxH13.Location = new System.Drawing.Point(420, 284);
            this.GendertextBoxH13.Name = "GendertextBoxH13";
            this.GendertextBoxH13.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH13.TabIndex = 123;
            // 
            // GenderlabelH13
            // 
            this.GenderlabelH13.AutoSize = true;
            this.GenderlabelH13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH13.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH13.Location = new System.Drawing.Point(312, 273);
            this.GenderlabelH13.Name = "GenderlabelH13";
            this.GenderlabelH13.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH13.TabIndex = 122;
            this.GenderlabelH13.Text = "Gender";
            // 
            // NametextBoxH13
            // 
            this.NametextBoxH13.Location = new System.Drawing.Point(420, 121);
            this.NametextBoxH13.Name = "NametextBoxH13";
            this.NametextBoxH13.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH13.TabIndex = 121;
            // 
            // NamelabelH13
            // 
            this.NamelabelH13.AutoSize = true;
            this.NamelabelH13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH13.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH13.Location = new System.Drawing.Point(312, 110);
            this.NamelabelH13.Name = "NamelabelH13";
            this.NamelabelH13.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH13.TabIndex = 120;
            this.NamelabelH13.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 119;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHFm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1258, 699);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH13);
            this.Controls.Add(this.AddresstextBoxH13);
            this.Controls.Add(this.AddresslabelH13);
            this.Controls.Add(this.TicketstextBoxH13);
            this.Controls.Add(this.TicketslabelH13);
            this.Controls.Add(this.NotextBoxH13);
            this.Controls.Add(this.NolabelH13);
            this.Controls.Add(this.EmailtextBoxH13);
            this.Controls.Add(this.EmaillabelH13);
            this.Controls.Add(this.GendertextBoxH13);
            this.Controls.Add(this.GenderlabelH13);
            this.Controls.Add(this.NametextBoxH13);
            this.Controls.Add(this.NamelabelH13);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHFm1";
            this.Text = "BHFm1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH13;
        private System.Windows.Forms.TextBox AddresstextBoxH13;
        private System.Windows.Forms.Label AddresslabelH13;
        private System.Windows.Forms.TextBox TicketstextBoxH13;
        private System.Windows.Forms.Label TicketslabelH13;
        private System.Windows.Forms.TextBox NotextBoxH13;
        private System.Windows.Forms.Label NolabelH13;
        private System.Windows.Forms.TextBox EmailtextBoxH13;
        private System.Windows.Forms.Label EmaillabelH13;
        private System.Windows.Forms.TextBox GendertextBoxH13;
        private System.Windows.Forms.Label GenderlabelH13;
        private System.Windows.Forms.TextBox NametextBoxH13;
        private System.Windows.Forms.Label NamelabelH13;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}