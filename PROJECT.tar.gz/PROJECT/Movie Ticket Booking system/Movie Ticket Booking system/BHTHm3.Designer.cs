﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHTHm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHTHm3));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH12 = new System.Windows.Forms.Button();
            this.AddresstextBoxH12 = new System.Windows.Forms.TextBox();
            this.AddresslabelH12 = new System.Windows.Forms.Label();
            this.TicketstextBoxH12 = new System.Windows.Forms.TextBox();
            this.TicketslabelH12 = new System.Windows.Forms.Label();
            this.NotextBoxH12 = new System.Windows.Forms.TextBox();
            this.NolabelH12 = new System.Windows.Forms.Label();
            this.EmailtextBoxH12 = new System.Windows.Forms.TextBox();
            this.EmaillabelH12 = new System.Windows.Forms.Label();
            this.GendertextBoxH12 = new System.Windows.Forms.TextBox();
            this.GenderlabelH12 = new System.Windows.Forms.Label();
            this.NametextBoxH12 = new System.Windows.Forms.TextBox();
            this.NamelabelH12 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1202, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 118;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH12
            // 
            this.RegisterH12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH12.Location = new System.Drawing.Point(479, 523);
            this.RegisterH12.Name = "RegisterH12";
            this.RegisterH12.Size = new System.Drawing.Size(286, 83);
            this.RegisterH12.TabIndex = 117;
            this.RegisterH12.Text = "Register";
            this.RegisterH12.UseVisualStyleBackColor = true;
            this.RegisterH12.Click += new System.EventHandler(this.RegisterH12_Click);
            // 
            // AddresstextBoxH12
            // 
            this.AddresstextBoxH12.Location = new System.Drawing.Point(420, 394);
            this.AddresstextBoxH12.Multiline = true;
            this.AddresstextBoxH12.Name = "AddresstextBoxH12";
            this.AddresstextBoxH12.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH12.TabIndex = 116;
            // 
            // AddresslabelH12
            // 
            this.AddresslabelH12.AutoSize = true;
            this.AddresslabelH12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH12.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH12.Location = new System.Drawing.Point(312, 382);
            this.AddresslabelH12.Name = "AddresslabelH12";
            this.AddresslabelH12.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH12.TabIndex = 115;
            this.AddresslabelH12.Text = "Add";
            // 
            // TicketstextBoxH12
            // 
            this.TicketstextBoxH12.Location = new System.Drawing.Point(420, 338);
            this.TicketstextBoxH12.Name = "TicketstextBoxH12";
            this.TicketstextBoxH12.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH12.TabIndex = 114;
            // 
            // TicketslabelH12
            // 
            this.TicketslabelH12.AutoSize = true;
            this.TicketslabelH12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH12.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH12.Location = new System.Drawing.Point(312, 327);
            this.TicketslabelH12.Name = "TicketslabelH12";
            this.TicketslabelH12.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH12.TabIndex = 113;
            this.TicketslabelH12.Text = "Tickets";
            // 
            // NotextBoxH12
            // 
            this.NotextBoxH12.Location = new System.Drawing.Point(420, 176);
            this.NotextBoxH12.Name = "NotextBoxH12";
            this.NotextBoxH12.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH12.TabIndex = 112;
            // 
            // NolabelH12
            // 
            this.NolabelH12.AutoSize = true;
            this.NolabelH12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH12.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH12.Location = new System.Drawing.Point(312, 165);
            this.NolabelH12.Name = "NolabelH12";
            this.NolabelH12.Size = new System.Drawing.Size(49, 31);
            this.NolabelH12.TabIndex = 111;
            this.NolabelH12.Text = "No";
            // 
            // EmailtextBoxH12
            // 
            this.EmailtextBoxH12.Location = new System.Drawing.Point(420, 232);
            this.EmailtextBoxH12.Name = "EmailtextBoxH12";
            this.EmailtextBoxH12.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH12.TabIndex = 110;
            // 
            // EmaillabelH12
            // 
            this.EmaillabelH12.AutoSize = true;
            this.EmaillabelH12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH12.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH12.Location = new System.Drawing.Point(312, 221);
            this.EmaillabelH12.Name = "EmaillabelH12";
            this.EmaillabelH12.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH12.TabIndex = 109;
            this.EmaillabelH12.Text = "Email";
            // 
            // GendertextBoxH12
            // 
            this.GendertextBoxH12.Location = new System.Drawing.Point(420, 284);
            this.GendertextBoxH12.Name = "GendertextBoxH12";
            this.GendertextBoxH12.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH12.TabIndex = 108;
            // 
            // GenderlabelH12
            // 
            this.GenderlabelH12.AutoSize = true;
            this.GenderlabelH12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH12.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH12.Location = new System.Drawing.Point(312, 273);
            this.GenderlabelH12.Name = "GenderlabelH12";
            this.GenderlabelH12.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH12.TabIndex = 107;
            this.GenderlabelH12.Text = "Gender";
            // 
            // NametextBoxH12
            // 
            this.NametextBoxH12.Location = new System.Drawing.Point(420, 121);
            this.NametextBoxH12.Name = "NametextBoxH12";
            this.NametextBoxH12.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH12.TabIndex = 106;
            // 
            // NamelabelH12
            // 
            this.NamelabelH12.AutoSize = true;
            this.NamelabelH12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH12.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH12.Location = new System.Drawing.Point(312, 110);
            this.NamelabelH12.Name = "NamelabelH12";
            this.NamelabelH12.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH12.TabIndex = 105;
            this.NamelabelH12.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 104;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHTHm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1258, 701);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH12);
            this.Controls.Add(this.AddresstextBoxH12);
            this.Controls.Add(this.AddresslabelH12);
            this.Controls.Add(this.TicketstextBoxH12);
            this.Controls.Add(this.TicketslabelH12);
            this.Controls.Add(this.NotextBoxH12);
            this.Controls.Add(this.NolabelH12);
            this.Controls.Add(this.EmailtextBoxH12);
            this.Controls.Add(this.EmaillabelH12);
            this.Controls.Add(this.GendertextBoxH12);
            this.Controls.Add(this.GenderlabelH12);
            this.Controls.Add(this.NametextBoxH12);
            this.Controls.Add(this.NamelabelH12);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHTHm3";
            this.Text = "BHTHm3";
            this.Load += new System.EventHandler(this.BHTHm3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH12;
        private System.Windows.Forms.TextBox AddresstextBoxH12;
        private System.Windows.Forms.Label AddresslabelH12;
        private System.Windows.Forms.TextBox TicketstextBoxH12;
        private System.Windows.Forms.Label TicketslabelH12;
        private System.Windows.Forms.TextBox NotextBoxH12;
        private System.Windows.Forms.Label NolabelH12;
        private System.Windows.Forms.TextBox EmailtextBoxH12;
        private System.Windows.Forms.Label EmaillabelH12;
        private System.Windows.Forms.TextBox GendertextBoxH12;
        private System.Windows.Forms.Label GenderlabelH12;
        private System.Windows.Forms.TextBox NametextBoxH12;
        private System.Windows.Forms.Label NamelabelH12;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}