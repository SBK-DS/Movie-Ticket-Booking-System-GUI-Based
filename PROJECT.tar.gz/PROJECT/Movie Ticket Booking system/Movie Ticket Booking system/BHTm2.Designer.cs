﻿
namespace Movie_Ticket_Booking_system
{
    partial class BHTm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BHTm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RegisterH5 = new System.Windows.Forms.Button();
            this.AddresstextBoxH5 = new System.Windows.Forms.TextBox();
            this.AddresslabelH5 = new System.Windows.Forms.Label();
            this.TicketstextBoxH5 = new System.Windows.Forms.TextBox();
            this.TicketslabelH5 = new System.Windows.Forms.Label();
            this.NotextBoxH5 = new System.Windows.Forms.TextBox();
            this.NolabelH5 = new System.Windows.Forms.Label();
            this.EmailtextBoxH5 = new System.Windows.Forms.TextBox();
            this.EmaillabelH5 = new System.Windows.Forms.Label();
            this.GendertextBoxH5 = new System.Windows.Forms.TextBox();
            this.GenderlabelH5 = new System.Windows.Forms.Label();
            this.NametextBoxH5 = new System.Windows.Forms.TextBox();
            this.NamelabelH5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1203, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 103;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // RegisterH5
            // 
            this.RegisterH5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RegisterH5.Location = new System.Drawing.Point(480, 523);
            this.RegisterH5.Name = "RegisterH5";
            this.RegisterH5.Size = new System.Drawing.Size(286, 83);
            this.RegisterH5.TabIndex = 102;
            this.RegisterH5.Text = "Register";
            this.RegisterH5.UseVisualStyleBackColor = true;
            this.RegisterH5.Click += new System.EventHandler(this.RegisterH5_Click);
            // 
            // AddresstextBoxH5
            // 
            this.AddresstextBoxH5.Location = new System.Drawing.Point(421, 394);
            this.AddresstextBoxH5.Multiline = true;
            this.AddresstextBoxH5.Name = "AddresstextBoxH5";
            this.AddresstextBoxH5.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBoxH5.TabIndex = 101;
            // 
            // AddresslabelH5
            // 
            this.AddresslabelH5.AutoSize = true;
            this.AddresslabelH5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresslabelH5.ForeColor = System.Drawing.Color.Yellow;
            this.AddresslabelH5.Location = new System.Drawing.Point(313, 382);
            this.AddresslabelH5.Name = "AddresslabelH5";
            this.AddresslabelH5.Size = new System.Drawing.Size(62, 31);
            this.AddresslabelH5.TabIndex = 100;
            this.AddresslabelH5.Text = "Add";
            // 
            // TicketstextBoxH5
            // 
            this.TicketstextBoxH5.Location = new System.Drawing.Point(421, 338);
            this.TicketstextBoxH5.Name = "TicketstextBoxH5";
            this.TicketstextBoxH5.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBoxH5.TabIndex = 99;
            // 
            // TicketslabelH5
            // 
            this.TicketslabelH5.AutoSize = true;
            this.TicketslabelH5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketslabelH5.ForeColor = System.Drawing.Color.Yellow;
            this.TicketslabelH5.Location = new System.Drawing.Point(313, 327);
            this.TicketslabelH5.Name = "TicketslabelH5";
            this.TicketslabelH5.Size = new System.Drawing.Size(102, 31);
            this.TicketslabelH5.TabIndex = 98;
            this.TicketslabelH5.Text = "Tickets";
            // 
            // NotextBoxH5
            // 
            this.NotextBoxH5.Location = new System.Drawing.Point(421, 176);
            this.NotextBoxH5.Name = "NotextBoxH5";
            this.NotextBoxH5.Size = new System.Drawing.Size(539, 20);
            this.NotextBoxH5.TabIndex = 97;
            // 
            // NolabelH5
            // 
            this.NolabelH5.AutoSize = true;
            this.NolabelH5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NolabelH5.ForeColor = System.Drawing.Color.Yellow;
            this.NolabelH5.Location = new System.Drawing.Point(313, 165);
            this.NolabelH5.Name = "NolabelH5";
            this.NolabelH5.Size = new System.Drawing.Size(49, 31);
            this.NolabelH5.TabIndex = 96;
            this.NolabelH5.Text = "No";
            // 
            // EmailtextBoxH5
            // 
            this.EmailtextBoxH5.Location = new System.Drawing.Point(421, 232);
            this.EmailtextBoxH5.Name = "EmailtextBoxH5";
            this.EmailtextBoxH5.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBoxH5.TabIndex = 95;
            // 
            // EmaillabelH5
            // 
            this.EmaillabelH5.AutoSize = true;
            this.EmaillabelH5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmaillabelH5.ForeColor = System.Drawing.Color.Yellow;
            this.EmaillabelH5.Location = new System.Drawing.Point(313, 221);
            this.EmaillabelH5.Name = "EmaillabelH5";
            this.EmaillabelH5.Size = new System.Drawing.Size(81, 31);
            this.EmaillabelH5.TabIndex = 94;
            this.EmaillabelH5.Text = "Email";
            // 
            // GendertextBoxH5
            // 
            this.GendertextBoxH5.Location = new System.Drawing.Point(421, 284);
            this.GendertextBoxH5.Name = "GendertextBoxH5";
            this.GendertextBoxH5.Size = new System.Drawing.Size(539, 20);
            this.GendertextBoxH5.TabIndex = 93;
            // 
            // GenderlabelH5
            // 
            this.GenderlabelH5.AutoSize = true;
            this.GenderlabelH5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderlabelH5.ForeColor = System.Drawing.Color.Yellow;
            this.GenderlabelH5.Location = new System.Drawing.Point(313, 273);
            this.GenderlabelH5.Name = "GenderlabelH5";
            this.GenderlabelH5.Size = new System.Drawing.Size(104, 31);
            this.GenderlabelH5.TabIndex = 92;
            this.GenderlabelH5.Text = "Gender";
            // 
            // NametextBoxH5
            // 
            this.NametextBoxH5.Location = new System.Drawing.Point(421, 121);
            this.NametextBoxH5.Name = "NametextBoxH5";
            this.NametextBoxH5.Size = new System.Drawing.Size(539, 20);
            this.NametextBoxH5.TabIndex = 91;
            // 
            // NamelabelH5
            // 
            this.NamelabelH5.AutoSize = true;
            this.NamelabelH5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamelabelH5.ForeColor = System.Drawing.Color.Yellow;
            this.NamelabelH5.Location = new System.Drawing.Point(313, 110);
            this.NamelabelH5.Name = "NamelabelH5";
            this.NamelabelH5.Size = new System.Drawing.Size(86, 31);
            this.NamelabelH5.TabIndex = 90;
            this.NamelabelH5.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BHTm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1259, 701);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RegisterH5);
            this.Controls.Add(this.AddresstextBoxH5);
            this.Controls.Add(this.AddresslabelH5);
            this.Controls.Add(this.TicketstextBoxH5);
            this.Controls.Add(this.TicketslabelH5);
            this.Controls.Add(this.NotextBoxH5);
            this.Controls.Add(this.NolabelH5);
            this.Controls.Add(this.EmailtextBoxH5);
            this.Controls.Add(this.EmaillabelH5);
            this.Controls.Add(this.GendertextBoxH5);
            this.Controls.Add(this.GenderlabelH5);
            this.Controls.Add(this.NametextBoxH5);
            this.Controls.Add(this.NamelabelH5);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BHTm2";
            this.Text = "HBTm2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RegisterH5;
        private System.Windows.Forms.TextBox AddresstextBoxH5;
        private System.Windows.Forms.Label AddresslabelH5;
        private System.Windows.Forms.TextBox TicketstextBoxH5;
        private System.Windows.Forms.Label TicketslabelH5;
        private System.Windows.Forms.TextBox NotextBoxH5;
        private System.Windows.Forms.Label NolabelH5;
        private System.Windows.Forms.TextBox EmailtextBoxH5;
        private System.Windows.Forms.Label EmaillabelH5;
        private System.Windows.Forms.TextBox GendertextBoxH5;
        private System.Windows.Forms.Label GenderlabelH5;
        private System.Windows.Forms.TextBox NametextBoxH5;
        private System.Windows.Forms.Label NamelabelH5;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}