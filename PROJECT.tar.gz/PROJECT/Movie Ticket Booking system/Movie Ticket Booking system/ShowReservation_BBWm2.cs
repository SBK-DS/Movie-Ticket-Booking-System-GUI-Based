﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBWm2 : Form
    {
        public ShowReservation_BBWm2()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBWm2_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBWm2.Book_ID.ToString();
            textBox2.Text = BBWm2.name_copy;
            textBox3.Text = BBWm2.No_copy;
            textBox4.Text = BBWm2.email_copy;
            textBox5.Text = BBWm2.gender_copy;
            textBox6.Text = BBWm2.Tickets_copy.ToString();
            textBox7.Text = BBWm2.Day_copy;
            textBox8.Text = BBWm2.Movie_copy;
            textBox9.Text = BBWm2.Amount_copy.ToString();
            textBox10.Text = BBWm2.timing_copy;
            textBox11.Text = BBWm2.address_copy;
            textBox12.Text = BBWm2.DT_copy;
        }
    }
}
