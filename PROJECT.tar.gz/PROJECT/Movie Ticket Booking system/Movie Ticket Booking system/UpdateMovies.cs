﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Movie_Ticket_Booking_system
{
    public partial class UpdateMovies : Form
    {
        public UpdateMovies()
        {
            InitializeComponent();
        }


        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-UAV1AAR\SQLEXPRESS;Initial Catalog=OOPDATABASE;Integrated Security=True");



        private void Update_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE TicketsDetails SET Tickets = @NewTickets, Amount = @amount, Timing = @time, Name = @name WHERE Category = @cat and Day = @day and Movie = @mov ", con);
            cmd.Parameters.AddWithValue("@NewTickets", textBox1.Text);
            cmd.Parameters.AddWithValue("@amount", textBox2.Text);
            cmd.Parameters.AddWithValue("@time", textBox3.Text);
            cmd.Parameters.AddWithValue("@name", textBox4.Text);
            cmd.Parameters.AddWithValue("@cat", comboBox1.Text);
            cmd.Parameters.AddWithValue("@day", comboBox2.Text);
            cmd.Parameters.AddWithValue("@mov", comboBox3.Text);
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Record Has been Updated");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Management_portal MP = new Management_portal();
            MP.ShowDialog();
        }
    }
}
