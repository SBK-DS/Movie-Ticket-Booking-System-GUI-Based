﻿
namespace Movie_Ticket_Booking_system
{
    partial class BBTHm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BBTHm2));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Register10 = new System.Windows.Forms.Button();
            this.AddresstextBox10 = new System.Windows.Forms.TextBox();
            this.Addresslabel10 = new System.Windows.Forms.Label();
            this.TicketstextBox10 = new System.Windows.Forms.TextBox();
            this.Ticketslabel10 = new System.Windows.Forms.Label();
            this.NotextBox10 = new System.Windows.Forms.TextBox();
            this.Nolabel10 = new System.Windows.Forms.Label();
            this.EmailtextBox10 = new System.Windows.Forms.TextBox();
            this.Emaillabel10 = new System.Windows.Forms.Label();
            this.GendertextBox10 = new System.Windows.Forms.TextBox();
            this.Genderlabel10 = new System.Windows.Forms.Label();
            this.NametextBox10 = new System.Windows.Forms.TextBox();
            this.Namelabel10 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1198, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 160;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Register10
            // 
            this.Register10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Register10.Location = new System.Drawing.Point(477, 523);
            this.Register10.Name = "Register10";
            this.Register10.Size = new System.Drawing.Size(286, 83);
            this.Register10.TabIndex = 159;
            this.Register10.Text = "Register";
            this.Register10.UseVisualStyleBackColor = true;
            this.Register10.Click += new System.EventHandler(this.Register10_Click);
            // 
            // AddresstextBox10
            // 
            this.AddresstextBox10.Location = new System.Drawing.Point(418, 394);
            this.AddresstextBox10.Multiline = true;
            this.AddresstextBox10.Name = "AddresstextBox10";
            this.AddresstextBox10.Size = new System.Drawing.Size(539, 89);
            this.AddresstextBox10.TabIndex = 158;
            // 
            // Addresslabel10
            // 
            this.Addresslabel10.AutoSize = true;
            this.Addresslabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel10.ForeColor = System.Drawing.Color.Yellow;
            this.Addresslabel10.Location = new System.Drawing.Point(310, 382);
            this.Addresslabel10.Name = "Addresslabel10";
            this.Addresslabel10.Size = new System.Drawing.Size(62, 31);
            this.Addresslabel10.TabIndex = 157;
            this.Addresslabel10.Text = "Add";
            // 
            // TicketstextBox10
            // 
            this.TicketstextBox10.Location = new System.Drawing.Point(418, 338);
            this.TicketstextBox10.Name = "TicketstextBox10";
            this.TicketstextBox10.Size = new System.Drawing.Size(539, 20);
            this.TicketstextBox10.TabIndex = 156;
            // 
            // Ticketslabel10
            // 
            this.Ticketslabel10.AutoSize = true;
            this.Ticketslabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ticketslabel10.ForeColor = System.Drawing.Color.Yellow;
            this.Ticketslabel10.Location = new System.Drawing.Point(310, 327);
            this.Ticketslabel10.Name = "Ticketslabel10";
            this.Ticketslabel10.Size = new System.Drawing.Size(102, 31);
            this.Ticketslabel10.TabIndex = 155;
            this.Ticketslabel10.Text = "Tickets";
            // 
            // NotextBox10
            // 
            this.NotextBox10.Location = new System.Drawing.Point(418, 176);
            this.NotextBox10.Name = "NotextBox10";
            this.NotextBox10.Size = new System.Drawing.Size(539, 20);
            this.NotextBox10.TabIndex = 154;
            // 
            // Nolabel10
            // 
            this.Nolabel10.AutoSize = true;
            this.Nolabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nolabel10.ForeColor = System.Drawing.Color.Yellow;
            this.Nolabel10.Location = new System.Drawing.Point(310, 165);
            this.Nolabel10.Name = "Nolabel10";
            this.Nolabel10.Size = new System.Drawing.Size(49, 31);
            this.Nolabel10.TabIndex = 153;
            this.Nolabel10.Text = "No";
            // 
            // EmailtextBox10
            // 
            this.EmailtextBox10.Location = new System.Drawing.Point(418, 232);
            this.EmailtextBox10.Name = "EmailtextBox10";
            this.EmailtextBox10.Size = new System.Drawing.Size(539, 20);
            this.EmailtextBox10.TabIndex = 152;
            // 
            // Emaillabel10
            // 
            this.Emaillabel10.AutoSize = true;
            this.Emaillabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel10.ForeColor = System.Drawing.Color.Yellow;
            this.Emaillabel10.Location = new System.Drawing.Point(310, 221);
            this.Emaillabel10.Name = "Emaillabel10";
            this.Emaillabel10.Size = new System.Drawing.Size(81, 31);
            this.Emaillabel10.TabIndex = 151;
            this.Emaillabel10.Text = "Email";
            // 
            // GendertextBox10
            // 
            this.GendertextBox10.Location = new System.Drawing.Point(418, 284);
            this.GendertextBox10.Name = "GendertextBox10";
            this.GendertextBox10.Size = new System.Drawing.Size(539, 20);
            this.GendertextBox10.TabIndex = 150;
            // 
            // Genderlabel10
            // 
            this.Genderlabel10.AutoSize = true;
            this.Genderlabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel10.ForeColor = System.Drawing.Color.Yellow;
            this.Genderlabel10.Location = new System.Drawing.Point(310, 273);
            this.Genderlabel10.Name = "Genderlabel10";
            this.Genderlabel10.Size = new System.Drawing.Size(104, 31);
            this.Genderlabel10.TabIndex = 149;
            this.Genderlabel10.Text = "Gender";
            // 
            // NametextBox10
            // 
            this.NametextBox10.Location = new System.Drawing.Point(418, 121);
            this.NametextBox10.Name = "NametextBox10";
            this.NametextBox10.Size = new System.Drawing.Size(539, 20);
            this.NametextBox10.TabIndex = 148;
            // 
            // Namelabel10
            // 
            this.Namelabel10.AutoSize = true;
            this.Namelabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel10.ForeColor = System.Drawing.Color.Yellow;
            this.Namelabel10.Location = new System.Drawing.Point(310, 109);
            this.Namelabel10.Name = "Namelabel10";
            this.Namelabel10.Size = new System.Drawing.Size(86, 31);
            this.Namelabel10.TabIndex = 147;
            this.Namelabel10.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(9, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 146;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BBTHm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1254, 701);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Register10);
            this.Controls.Add(this.AddresstextBox10);
            this.Controls.Add(this.Addresslabel10);
            this.Controls.Add(this.TicketstextBox10);
            this.Controls.Add(this.Ticketslabel10);
            this.Controls.Add(this.NotextBox10);
            this.Controls.Add(this.Nolabel10);
            this.Controls.Add(this.EmailtextBox10);
            this.Controls.Add(this.Emaillabel10);
            this.Controls.Add(this.GendertextBox10);
            this.Controls.Add(this.Genderlabel10);
            this.Controls.Add(this.NametextBox10);
            this.Controls.Add(this.Namelabel10);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BBTHm2";
            this.Text = "BBTHm2";
            this.Load += new System.EventHandler(this.BBTHm2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Register10;
        private System.Windows.Forms.TextBox AddresstextBox10;
        private System.Windows.Forms.Label Addresslabel10;
        private System.Windows.Forms.TextBox TicketstextBox10;
        private System.Windows.Forms.Label Ticketslabel10;
        private System.Windows.Forms.TextBox NotextBox10;
        private System.Windows.Forms.Label Nolabel10;
        private System.Windows.Forms.TextBox EmailtextBox10;
        private System.Windows.Forms.Label Emaillabel10;
        private System.Windows.Forms.TextBox GendertextBox10;
        private System.Windows.Forms.Label Genderlabel10;
        private System.Windows.Forms.TextBox NametextBox10;
        private System.Windows.Forms.Label Namelabel10;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}