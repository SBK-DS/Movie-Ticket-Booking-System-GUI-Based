﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Ticket_Booking_system
{
    public partial class ShowReservation_BBFm1 : Form
    {
        public ShowReservation_BBFm1()
        {
            InitializeComponent();
        }

        private void ShowReservation_BBFm1_Load(object sender, EventArgs e)
        {
            textBox1.Text = BBFm1.Book_ID.ToString();
            textBox2.Text = BBFm1.name_copy;
            textBox3.Text = BBFm1.No_copy;
            textBox4.Text = BBFm1.email_copy;
            textBox5.Text = BBFm1.gender_copy;
            textBox6.Text = BBFm1.Tickets_copy.ToString();
            textBox7.Text = BBFm1.Day_copy;
            textBox8.Text = BBFm1.Movie_copy;
            textBox9.Text = BBFm1.Amount_copy.ToString();
            textBox10.Text = BBFm1.timing_copy;
            textBox11.Text = BBFm1.address_copy;
            textBox12.Text = BBFm1.DT_copy;
        }
    }
}
